package swimmingPool;
import Resource.BasketPool;
import Resource.ClubiclePool;
import action.*;



public class SwimmingPool {
	public static void main(String[] args) throws ActionFinishedException,SchedulerStardedException{
		BasketPool baskets = new BasketPool(6);
		ClubiclePool cubicles = new ClubiclePool(3);
		FairScheduler s = new FairScheduler();
		
		s.addAction(new User("Camille", baskets, cubicles, 6, 4, 8));
		s.addAction(new User("Loıs", baskets, cubicles, 2, 10, 4));
		s.addAction(new User("Mae", baskets, cubicles, 10, 18, 10));
		s.addAction(new User("Ange", baskets, cubicles, 3, 7, 5));
		s.addAction(new User("Louison", baskets, cubicles, 18, 3, 3));
		s.addAction(new User("Charlie", baskets, cubicles, 3, 6, 10));
		s.addAction(new User("Alexis", baskets, cubicles, 6, 5, 7));
		
		System.out.println("Welcome in the swimming pool !");
		System.out.println();
		System.out.println("Camille, Lois, Mae, Ange, Louison, Charlie and Alexis want to swim In this swimmingPool, there is 6 baskets and 3 cubicles.");
		System.out.println();
		int nbSteps = 0;
	    
		while (!s.isFinished()){
		nbSteps++;
		s.doStep();
		}
		
		System.out.println("Finished in " + nbSteps + " steps");
		}
}
