package Resource;


public class BasketPool extends ResourcePool<Basket>{

	/**
	 * a constructor of BasketPool class
	 * @param size
	 */
	public BasketPool(int size){
		super(size);
	}

	/**
	 * to create a resource
	 * @return Basket
	 */
	public Basket creatResource() {
		
		return  new Basket();
	}
	
	
	public String description(){
		return "Pool Basket";
	}

}
