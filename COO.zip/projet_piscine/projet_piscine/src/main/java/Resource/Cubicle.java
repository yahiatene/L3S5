package Resource;

public class Cubicle implements Resource{
public String description(){
	return "this is cubicle";
}
}
