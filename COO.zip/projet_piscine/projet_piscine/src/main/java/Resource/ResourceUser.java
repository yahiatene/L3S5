package Resource;

public class ResourceUser <R extends Resource>{
	protected R resource;
	/**
	 * a getter for resource
	 * @return R resource
	 */
	public R getResource() {
	return resource;
	}
	
	/**
	 * to set a resource
	 * @param resource
	 */
	public void setResource(R resource) {
	this.resource = resource;
	}
	
	/**
	 * to reset resource
	 */
	public void resetResource() {
	this.resource=null;
}
}