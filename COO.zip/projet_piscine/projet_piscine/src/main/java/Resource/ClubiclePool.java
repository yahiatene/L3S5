package Resource;



public class ClubiclePool extends ResourcePool<Cubicle> {
	/**
	 * construcor
	 * @param size
	 */
	public ClubiclePool(int size){
		super(size);
	}

/**
 *this method create resource 
 *@return object of cubicle
 */
public Cubicle creatResource() {
	
	return  new Cubicle();
}
public String description(){
	return "Pool Cubicle";
}

}
