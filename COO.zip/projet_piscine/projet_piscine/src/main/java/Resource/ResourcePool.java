package Resource;

import java.util.*;


public abstract class  ResourcePool<R extends Resource> {


private ArrayList<R> freeResource;
private ArrayList<R> busyresource;
/**
 * constructor
 * @param size
 */
public ResourcePool(int size){
	
	this.freeResource=new ArrayList<R>();
	this.busyresource=new ArrayList<R>();
	int i;
	for (i=0;i<size;i++){
		this.freeResource.add(creatResource());
	}
	

}

/**
 * a getter for FreeResource
 * @return ArrayList<R>
 */
public ArrayList<R> getFreeResource(){
	return this.freeResource;
}

/**
 * a getter for BusyResource
 * @return ArrayList<R>
 */
public ArrayList<R> getBusyResource(){
	return this.busyresource;
}


public abstract R creatResource();


/**
 * to provide a resource
 * @return R a resource
 * @throws NoSuchElementException
 */
public R provideResource() throws NoSuchElementException{
	if (!this.freeResource.isEmpty()){
		R r=this.freeResource.remove(0);
		this.busyresource.add(r);
		return r;
	}
	else{
		throw new NoSuchElementException();
	}
	
}
public abstract String description();

/**
 * to recover a resource
 * @throws NoSuchElementException
 */
public void recoverResource() throws NoSuchElementException{
	
	if (!this.busyresource.isEmpty()){
		this.freeResource.add(this.busyresource.get(0));
	    this.busyresource.remove(this.busyresource.get(0));
		
	}
	else{
		throw new NoSuchElementException();
	}
}

}

