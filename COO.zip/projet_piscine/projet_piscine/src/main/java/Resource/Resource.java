package Resource;

public interface Resource {
public String description();
}
