package Resource;

public class Basket implements Resource{
	public String description(){
		return "this is basket";
	}
}
