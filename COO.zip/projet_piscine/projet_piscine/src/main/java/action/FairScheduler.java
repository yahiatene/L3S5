package action;
public class FairScheduler extends Scheduler {

	/**
	 * constructor of FairSceduler class
	 */
	public FairScheduler(){
		super();
	}
	
	/**
	 * have the next action
	 */
	protected Action nextAction(){
		int index = this.currentIndex;
		return this.actions.get(currentIndexUser).getListActionToDo().get(index);
	}
	
	public String description(){
		return "";
	}
	
}
