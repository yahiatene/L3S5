package action;

@SuppressWarnings("serial")
public class ActionFinishedException extends Exception {
	
	public ActionFinishedException(){
		System.out.print("ActionFinishedException");
	}
}
