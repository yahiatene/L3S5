package action;

import java.util.NoSuchElementException;

import Resource.Resource;
import Resource.ResourcePool;


public class FreeResourceAction <R extends Resource>extends Action {
	private ResourcePool<R> resourcePool;

	/**
	 * constructor of FreeResourceAction class
	 * @param resourcePool
	 */
	public FreeResourceAction(ResourcePool<R> resourcePool) {	
		this.resourcePool=resourcePool;    
	}

	
	/**
	 * to do really the action
	 */
	public void realStep(){
		try{
		
			this.resourcePool.recoverResource();
			this.state=ActionState.FINISHED;			
			
		}
		catch(NoSuchElementException e){
			this.state=ActionState.IN_PROGRESS;
			
		}
	}

	
	/**
	 * to know if the action is finished or not
	 * @return boolean
	 */
	protected boolean stopCondition() {
	
		return this.state==ActionState.FINISHED;
	}
	
	public String description(){
		return "freeing resource from "+this.resourcePool.description();
	}

}
