package action;

import java.util.NoSuchElementException;

import Resource.Resource;
import Resource.ResourcePool;

	public class TakeResourceAction <R extends Resource> extends Action{
    private ResourcePool<R> resourcePool;
   
    
    /**
     * a constructor of TakeResourceAction class
     * @param resourcePool
     */
	public TakeResourceAction(ResourcePool<R> resourcePool) {
		
		this.resourcePool=resourcePool;
		
		
	}
	
	/**
	 * to really do an action
	 */
	public void realStep() {
		try{
			this.resourcePool.provideResource();
			this.state=ActionState.FINISHED;
		}
		catch(NoSuchElementException e){
			this.state=ActionState.IN_PROGRESS;
			
		}
	}
	
	
	protected boolean stopCondition() {
		return this.state==ActionState.FINISHED;
	}
	
	public String description(){
		if(this.state==ActionState.FINISHED){
		return "trying to take resource from "+this.resourcePool.description()+"...succed";}
		else{
			return "trying to take resource from "+this.resourcePool.description()+"...failed";
		}
	}
}
