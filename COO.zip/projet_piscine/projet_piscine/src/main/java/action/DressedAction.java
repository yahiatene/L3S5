package action;

public class DressedAction extends ForeseeableAction{

	/**
	 * constructor of DressedAction class
	 * @param waiting
	 */
	public DressedAction(int waiting) {
		super(waiting);
		
	}
	public String description(){
		return "dressing "+super.description();
	}

}
