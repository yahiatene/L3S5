package action;

import java.util.ArrayList;

import Resource.*;


public class LIstActions {
	private ArrayList<Action> actions;
	
	/**
	 * the constructor of LIstActions class
	 * @param clubiclePool
	 * @param basketPool
	 * @param timeToUnderLess
	 * @param durationToBath
	 * @param durationToDress
	 */
	public LIstActions(ClubiclePool clubiclePool,BasketPool basketPool,int timeToUnderLess,int durationToBath ,int durationToDress){
	this.actions=new ArrayList<Action>();
	Action frac=new FreeResourceAction<Cubicle>(clubiclePool);
	Action frac1=new FreeResourceAction<Cubicle>(clubiclePool);
	Action fra1=new FreeResourceAction<Basket>(basketPool);
	Action tra=new TakeResourceAction<Basket> (basketPool);
	Action tra1=new TakeResourceAction<Cubicle> (clubiclePool);
	Action tra2=new TakeResourceAction<Cubicle> (clubiclePool);
	Action underLess=new UndressedAction(timeToUnderLess);
	Action bath=new BathAction(durationToBath);
	Action dress=new DressedAction(durationToDress);
	this.actions.add(0,tra);
	this.actions.add(1,tra1);
	this.actions.add(2,underLess);
	this.actions.add(3,frac);
	this.actions.add(4,bath);
	this.actions.add(5,tra2);
	this.actions.add(6,dress);
	this.actions.add(7,frac1);
	this.actions.add(8,fra1);
	}
	
	
	/**
	 * a getter for actions
	 * @return ArrayList<Action>
	 */
	public ArrayList<Action> getListActionToDo(){
		return this.actions;
	}
}
