package action;

public class UndressedAction extends ForeseeableAction{

	/**
	 * a constructor of UndressedAction class
	 * @param waiting
	 */
	public UndressedAction(int waiting) {
		super(waiting);
		
	}
	public String description(){
		return "undressing "+super.description();
	}
}
