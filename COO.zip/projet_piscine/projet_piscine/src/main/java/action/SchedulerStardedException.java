package action;
@SuppressWarnings("serial")
public class SchedulerStardedException extends Exception {}