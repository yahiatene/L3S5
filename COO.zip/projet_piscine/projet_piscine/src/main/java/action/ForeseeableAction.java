package action;

public abstract class ForeseeableAction extends Action {

	protected int waitingTime;
	protected int timeShouldWait;
	
	/**
	 * constructor of ForeseeableAction class
	 * @param waiting
	 */
	public ForeseeableAction(int waiting) {
		this.waitingTime = waiting;
		this.timeShouldWait=waiting;
	}
	
	public void realStep() {
		this.waitingTime-- ;
		}
    public int getTimeShouldWait(){
    	return this.timeShouldWait;
    }
    public int getWaitingTime(){
    	return this.waitingTime;
    }
    protected boolean stopCondition() {
        return this.waitingTime == 0;
    }	
    public String description(){
		return "("+(this.timeShouldWait-this.waitingTime)+"/"+this.timeShouldWait+")";
	}
}
