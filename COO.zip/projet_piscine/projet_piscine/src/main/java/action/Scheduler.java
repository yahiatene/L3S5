package action;
import java.util.ArrayList;



public abstract class Scheduler extends Action {

	protected ArrayList<LIstActions> actions;
	protected ArrayList<User> listActions;
	protected int currentIndexUser;
	protected int currentIndex;
	
	/**
	 * a constructor of Scheduler class
	 */
	public Scheduler() {
		this.actions = new ArrayList<LIstActions>();
		this.listActions=new ArrayList<User>();
		this.currentIndexUser=0;
	
	}
    
	
	/**
	 * to do an action
	 */
	protected void realStep()  {		
		System.out.println(this.listActions.get(currentIndexUser).description()+"'s turn");
		Action action = this.nextAction();
		try {
			action.doStep();
			
			System.out.println("  "+this.listActions.get(currentIndexUser).description()+" "+action.description());
			
		} catch (ActionFinishedException e) {
		}
		if (action.isFinished()){ 
			this.actions.get(this.currentIndexUser).getListActionToDo().remove(action);
		}
		if(this.checkIfUserFinishedAllAction(this.currentIndexUser)){
			this.listActions.remove(currentIndexUser);
			this.actions.remove(currentIndexUser);
			currentIndexUser--;
		}
		this.nextUser();
		
	}
	
	/**
	 * to have the next user
	 */
	public void nextUser(){
		
		this.currentIndexUser ++ ;
		if (this.currentIndexUser  == this.actions.size()) this.currentIndexUser  = 0 ;
		
	}
	protected abstract Action nextAction();
	
	/**
	 * to know if the user has finished the action or not
	 * @param currentIndexUser
	 * @return boolean
	 */
	public boolean checkIfUserFinishedAllAction(int currentIndexUser){
		
			for(int j=0;j<this.actions.get(currentIndexUser).getListActionToDo().size();j++){
				if(!this.actions.get(currentIndexUser).getListActionToDo().get(j).isFinished()){
					return false;
				}
			
		}
		return true;
	}
	
	/**
	 * to add an action to listActions
	 * @param user
	 * @throws ActionFinishedException
	 * @throws SchedulerStardedException
	 */
	public void addAction(User user) throws ActionFinishedException, SchedulerStardedException {
		LIstActions la=new LIstActions(user.getClubiclePool(),user.getBasketPool(),user.getDurationToUnderLess(),user.getDurationToBath() ,user.getDurationToDress());
		this.actions.add(la);
		if (this.getState() != ActionState.READY) throw new SchedulerStardedException() ;
		
		this.listActions.add(user);
		
	}
    

	protected boolean stopCondition() {
		return this.actions.isEmpty();
	}
	
	/**
	 * if listActions is empty return true else return false
	 * @return boolean
	 */
	protected boolean stoppingConditionUser(){
		return this.listActions.isEmpty();
	}
	
	/**
	 * a getter for CurrentIndexUser
	 * @return int
	 */
	public int getCurrentIndexUser(){
		return this.currentIndexUser;
	}
}
