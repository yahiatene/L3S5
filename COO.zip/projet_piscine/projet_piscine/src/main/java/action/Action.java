package action;
public abstract class Action {

    protected ActionState state=ActionState.READY;
    
    /**
     * the role of this method is to do an action
     * @throws ActionFinishedException
     */
    public void doStep() throws ActionFinishedException{
        if (this.isFinished()) throw new ActionFinishedException();
        this.state = ActionState.IN_PROGRESS ;
        
        this.realStep();
       
        if (this.stopCondition()) this.state = ActionState.FINISHED;
        
    }
    protected abstract String description();
    protected abstract void realStep();
    
    protected abstract boolean stopCondition();
    
    public boolean isFinished() {return this.state == ActionState.FINISHED ;}

    public ActionState getState() {return this.state ;}
}
