package action;

import Resource.BasketPool;
import Resource.ClubiclePool;


public class User{
private String name;
private BasketPool basketPool;
private ClubiclePool clubiclePool;
private int timeToUnderLess;
private int durationToBath;
private int durationToDress;

/**
 * a constructor of User class
 * @param name
 * @param basketPool
 * @param clubiclePool
 * @param timeToUnderLess
 * @param durationToBath
 * @param durationToDress
 */
public User(String name,BasketPool basketPool,ClubiclePool clubiclePool,int timeToUnderLess,int durationToBath,int durationToDress){
this.name=name;
this.basketPool=basketPool;
this.clubiclePool=clubiclePool;
this.timeToUnderLess=timeToUnderLess;
this.durationToBath=durationToBath;
this.durationToDress=durationToDress;
}

/**
 * a getter for ClubiclePool
 * @return ClubiclePool
 */
public ClubiclePool getClubiclePool(){
	return this.clubiclePool;
}

/**
 * a getter for DurationToBath
 * @return int
 */
public int getDurationToBath(){
	return this.durationToBath;
}

/**
 * a getter for BasketPool
 * @return BasketPool
 */
public BasketPool getBasketPool(){
	return this.basketPool;
}

/**
 * a getter for DurationToUnderLess
 * @return int
 */
public int getDurationToUnderLess(){
	return this.timeToUnderLess;
}

/**
 * a getter for DurationToDress
 * @return int
 */
public int getDurationToDress(){
	return this.durationToDress;
}


public String description(){
	return this.name;
}

}