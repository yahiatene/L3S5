package action;

public enum ActionState {
	READY, IN_PROGRESS, FINISHED;
}
