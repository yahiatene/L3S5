package action;

public class BathAction extends ForeseeableAction{

	/**
	 * constructor of BathAction class
	 * @param waiting
	 */
	public BathAction(int waiting) {
		super(waiting);
	}
	

	public String description(){
		return "swimming "+super.description();
	}

}
