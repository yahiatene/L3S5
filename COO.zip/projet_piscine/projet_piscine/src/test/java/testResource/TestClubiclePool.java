package testResource;

import Resource.ClubiclePool;
import Resource.Cubicle;
import Resource.ResourcePool;

public class TestClubiclePool extends TestResourcePool<Cubicle>{

	

	
	public ResourcePool<Cubicle> creatPool() {
		
		return new ClubiclePool(2);
	}

}
