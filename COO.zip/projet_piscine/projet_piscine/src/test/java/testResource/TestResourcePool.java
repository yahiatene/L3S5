package testResource;

import static org.junit.Assert.*;

import Resource.Resource;
import Resource.ResourcePool;

import org.junit.Test;

public abstract class TestResourcePool<R extends Resource>{

	
	protected abstract ResourcePool<R> creatPool();
	@Test
	public void testProvideResource() {
		ResourcePool<R> rp=this.creatPool();
		R fr = rp.getFreeResource().get(0);
		rp.provideResource();
		assertTrue(rp.getFreeResource().get(0)!=fr);
		assertEquals(rp.getBusyResource().get(0),fr);
	}
	@Test
	public void testRecoverResource(){
		ResourcePool<R> rp=this.creatPool();
		rp.provideResource();
		rp.recoverResource();
		assertEquals(rp.getBusyResource().size(),0 );
		
	}

	
}
