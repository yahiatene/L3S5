package testResource;

import Resource.Basket;
import Resource.BasketPool;

import Resource.ResourcePool;


public class TestBasketPool extends TestResourcePool<Basket>{
public ResourcePool<Basket> creatPool() {
		
		return new BasketPool(2);
	}
	

}
