package testAction;

import static org.junit.Assert.*;

import Resource.BasketPool;
import Resource.ClubiclePool;
import action.*;

import org.junit.Test;

public class TestFairScheduler extends TestAction{
	 public FairScheduler creatFairScheduler(){
		 return new FairScheduler();
	 }
	@Test
	public void testNextUser() throws ActionFinishedException, SchedulerStardedException {
		BasketPool baskets = new BasketPool(6);
		ClubiclePool cubicles = new ClubiclePool(3);
		FairScheduler fs=creatFairScheduler();
		fs.addAction(new User("Camille", baskets, cubicles, 6, 4, 8));
		fs.addAction(new User("Loıs", baskets, cubicles, 2, 10, 4));
		fs.nextUser();
		assertEquals(fs.getCurrentIndexUser(),1);
	}
	


}
