package testAction;

import action.ForeseeableAction;
import action.UndressedAction;

 
public class TestUndressedAction extends TestForeseeableAction{

	
	protected ForeseeableAction creatActionForeseeable() {
	
		return new UndressedAction(12);
	}

}
