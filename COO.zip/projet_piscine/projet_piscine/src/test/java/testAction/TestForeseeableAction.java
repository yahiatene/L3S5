package testAction;

import static org.junit.Assert.*;

import action.ForeseeableAction;

import org.junit.Test;

public abstract class TestForeseeableAction {
	protected abstract ForeseeableAction creatActionForeseeable();
	@Test
	public void testrealStep() {
		ForeseeableAction fa=this.creatActionForeseeable();
		int timeStar=fa.getTimeShouldWait();
		fa.realStep();
		fa.realStep();
		assertEquals(fa.getWaitingTime(),timeStar-2);
		
		
	}

}
