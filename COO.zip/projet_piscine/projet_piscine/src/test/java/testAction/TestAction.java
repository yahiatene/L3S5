package testAction;

import static org.junit.Assert.*;

import Resource.BasketPool;
import Resource.ClubiclePool;
import action.ActionFinishedException;
import action.FairScheduler;
import action.SchedulerStardedException;
import action.User;

import org.junit.Test;

public abstract  class TestAction  {
	abstract public FairScheduler creatFairScheduler();
	@Test
	public void testIsFinished() throws ActionFinishedException, SchedulerStardedException{
		
		FairScheduler fs=creatFairScheduler();
		BasketPool baskets = new BasketPool(6);
		ClubiclePool cubicles = new ClubiclePool(3);
		fs.addAction(new User("Camille", baskets, cubicles, 6, 4, 8));
		for(int i=0;i<24;i++){
			fs.doStep();
		}
		assertTrue(fs.isFinished());
	}
	
	
	

}
