package testAction;

import action.BathAction;
import action.ForeseeableAction;

public class TestBathAction extends TestForeseeableAction{

	
	protected ForeseeableAction creatActionForeseeable() {
		
		return new BathAction(7);
	}

}
