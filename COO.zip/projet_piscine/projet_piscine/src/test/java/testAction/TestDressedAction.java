package testAction;

import action.DressedAction;
import action.ForeseeableAction;




public class TestDressedAction extends TestForeseeableAction {

	
	protected ForeseeableAction creatActionForeseeable() {
	
		return new DressedAction(9);
	}

}
