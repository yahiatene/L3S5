# PROJET PISCINE
## YAHIATENE Mohamed
## BENKHIDER Zinedine
### DATE:25/10/2017
### UNIV LILLE1

#### Rapide introduction sur le sujet du projet:
Le sujet est à propos du problème de la piscine,donc on doit mettre en place un gestionnaire de resources qui fournit les resources nécessaires à l'utilisation de la piscine à travers diverses actions qu'on peut manipuler **prendre**,**utiliser** et **liberer**.

#### Rubrique HOWTO:

* récupération du dépôt : git clone ou git pull
* commande génération de la documentation : mvn javadoc:javadoc (générée dans target/docs)
* commande de génération du projet : mvn package
* commande d'exécution de l'archive générée : java -jar target/projet_piscine-1.0-SNAPSHOT.jar

#### Présentation d'éléments de code saillant :
La mise en place des différentes classes abstraites pour faciliter la responsabilité de chaque classe et méthode selon les principes de conception **(KISS-YAGNI-DRY)** ansi que pour les methodes de test **(TDD)**.
