package introihm;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

import java.awt.event.*;

public class EssaiGraphic {

	public void AfficheFenetre(){
		JFrame f = new JFrame("Questionnaire");
		f.addWindowListener(new CloseWindowEvent());
		f.setSize(400, 500);
		f.setLocation(900, 100);
		f.add(new JButton("j'ai fini"), BorderLayout.SOUTH);
		
		JPanel panel1 = new JPanel();
		panel1.setLayout(new FlowLayout());
		f.add(new JLabel("question1"), BorderLayout.NORTH);
		
		JPanel panel2 = new JPanel();
		panel2.setLayout(new FlowLayout());
		f.add(new JLabel("question2"), BorderLayout.CENTER);
		
		JPanel panel3 = new JPanel();
		panel3.setLayout(new FlowLayout());
		f.add(new JLabel("question3"), BorderLayout.EAST);
		
		f.setVisible(true);
		

		
	}
	
	public static void main(String[] args) {
		EssaiGraphic t = new EssaiGraphic();
		t.AfficheFenetre();

	}
	
	
	
	
	
	// ----------------------------------------------------------------------
	// CLASSE INTERNE, revue au point 2.5 du sujet de TP
	// pour gérer la fermeture de l'application lorsuq'on ferme une fenêtre
	// ----------------------------------------------------------------------
	private class CloseWindowEvent extends WindowAdapter {
		public void windowClosing(java.awt.event.WindowEvent e) {
			System.exit(0);
		}
	}

}
