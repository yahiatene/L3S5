package answer;

import java.util.ArrayList;
import javax.swing.JPanel;
import graphique.GraphicFactory;

public class YesNoAnswer extends Answer<Boolean>{

	public YesNoAnswer(boolean answer){
		super(answer);
	}


	public String getGoodType() {
		return "(oui/non)";
	}

	public boolean hasGoodType(String answer) {
		if("oui".equalsIgnoreCase(answer)||"non".equalsIgnoreCase(answer)){

			return true;
		}
		return false;
	}


	public String toString(){
		if (this.goodAnswer==true){
			return "oui";
		}
		return "non";
	}


	public void creatView(GraphicFactory gf, JPanel top, ArrayList<?> jt) {
		gf.creatYesNoAnswerGraphic().answerView(top, jt);

	}


}
