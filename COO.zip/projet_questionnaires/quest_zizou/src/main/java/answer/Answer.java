package answer;

import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import graphique.GraphicFactory;


public abstract class Answer<T>{
	protected T goodAnswer;
	public Answer(T goodAnswer){
		this.goodAnswer=goodAnswer;
	}

	public abstract void creatView(GraphicFactory gf,JPanel top,ArrayList<?> jt);
	public abstract String getGoodType();
	public abstract boolean hasGoodType(String answer);
	public boolean isCorrect(String answer){
		answer=answer.toLowerCase();

		if( this.toString().toLowerCase().equals(answer)){
			return true;
		}
		return false;
	}
	public T getGoodAnswer(){
		return this.goodAnswer;
	}
	public String toString(){
		return ""+this.getGoodAnswer();
	}
	public  static ArrayList<String> fromString(String answer,String sep){

		int i=0;
		ArrayList<String> list=new ArrayList<String>();
		String res="";
		while(i<answer.length()){
		if (answer.substring(i,i+1).equals(" ")&& answer.substring(i+1,i+2).equals(sep)){
				list.add(res);

				i=i+3;
				res="";
			}
		res=res+answer.substring(i,i+1);
		i=i+1;
		}
		list.add(res);
		return list;

	}
}
