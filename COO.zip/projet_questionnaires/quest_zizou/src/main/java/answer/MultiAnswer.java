package answer;

import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import graphique.GraphicFactory;

public class MultiAnswer extends Answer<ArrayList<String>>{

	public MultiAnswer(ArrayList<String> listAnswer){
		super(listAnswer);

	}


	public String getGoodType(){
		return "("+this.goodAnswer.size()+" possibilites)";
	}

	public boolean hasGoodType(String answer) {
		try{Integer.parseInt(answer);
		return false;
		}
		catch(NumberFormatException e){
		return true;
		}
	}
	public boolean isCorrect(String answer){
		if(this.goodAnswer.contains(answer)){
			return true;
		}
		return false;
	}

	public String toString(){
		String res="";
		for (int i=0;i<this.goodAnswer.size()-1;i++){
			res=res+this.goodAnswer.get(i)+" ou ";
		}
		return res+this.goodAnswer.get(this.goodAnswer.size()-1);
	}



	public void creatView(GraphicFactory gf, JPanel top, ArrayList<?> jt) {
		gf.creatMultiAnswerGraphic().answerView(top, jt);

	}









}
