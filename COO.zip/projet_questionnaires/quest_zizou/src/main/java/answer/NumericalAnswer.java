package answer;

import java.awt.Dimension;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import graphique.GraphicFactory;

public class NumericalAnswer extends Answer<Integer>{


	public NumericalAnswer(int answer){
		super(answer);


	}

	public static int fromString(String answer){
		return Integer.parseInt(answer);
	}

	public String getGoodType() {

		return "(numeric)";
	}


	public boolean hasGoodType(String answer) {
		try{Integer.parseInt(answer);
		return true;
		}
		catch(NumberFormatException e){
		return false;}
}


	public void creatView(GraphicFactory gf, JPanel top, ArrayList<?> jt) {
		gf.creatNumericalAnswerGraphic().answerView(top, jt);


	}}
