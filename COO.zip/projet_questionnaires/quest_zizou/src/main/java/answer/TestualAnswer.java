package answer;

import java.util.ArrayList;
import javax.swing.JPanel;
import graphique.GraphicFactory;

public class TestualAnswer extends Answer<String> {
	public TestualAnswer(String answer){
		super(answer);
	}


	public String getGoodType() {

		return "(textuel)";
	}


	public boolean hasGoodType(String answer) {

		try{Integer.parseInt(answer);
		return false;
		}
		catch(NumberFormatException e){
		return true;
		}
	}






	public void creatView(GraphicFactory gf, JPanel top, ArrayList<?> jt) {
		gf.creatTextualAnswerGraphic().answerView(top,jt );

	}







}
