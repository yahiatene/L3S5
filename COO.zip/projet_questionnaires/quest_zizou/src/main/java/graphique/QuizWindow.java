package graphique;

import javax.swing.ButtonGroup; 
import javax.swing.JLabel;
import javax.swing.JTextArea;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.Border;
import answer.NumericalAnswer;
import answer.YesNoAnswer;
import quiz.QuestionnaireFactory;
import quiz.Quiz;




public class QuizWindow extends JFrame {
	  private Box box;
	  private GraphicFactory gf;
	  
	  public QuizWindow(){
		  this.setTitle("Quiz");
		   this.setSize(800, 700);
		  this.box= Box.createVerticalBox();
		  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  this.gf=new GraphicFactory();
	  }
	  //ouvrire la fenetre qui contient le quiz
	public void quizOpenWindow(Quiz q) {
		   
		    Button jr1 = new Button("j'ai finis");
		    jr1.setBackground(Color.LIGHT_GRAY);
		    ArrayList<JTextArea> jt=new ArrayList<JTextArea>();
		    ArrayList<JSpinner> jsp=new ArrayList<JSpinner>();
		    ArrayList<ButtonGroup> bg=new ArrayList<ButtonGroup>();
		    Border blackline = BorderFactory.createLineBorder(Color.black);
		    for (int i=0;i<q.getQuestion().size();i++){
		    	JPanel p=new JPanel();
		    	this.setLabelToPanel( p, q.getQuestion().get(i).getStatement()+q.getQuestion().get(i).getAnswer().getGoodType());
		    	p.setBorder(blackline);
		    	
		    	if (q.getQuestion().get(i).getAnswer() instanceof YesNoAnswer){
		    		q.getQuestion().get(i).getAnswer().creatView(this.gf, p, bg);
		    	}
		    	else if(q.getQuestion().get(i).getAnswer() instanceof NumericalAnswer){
		    		q.getQuestion().get(i).getAnswer().creatView(this.gf, p, jsp);
		    	}
		    	else{
		    		q.getQuestion().get(i).getAnswer().creatView(this.gf, p, jt);
		    	}
		    	this.box.add(p);
		    	p.setLayout(new FlowLayout(FlowLayout.LEFT));
		    }
		    this.box.add(jr1);
		    jr1.addActionListener(new StateListenerValider(jt,bg,jsp,q.getQuestion(), this.makeScor()));
		    this.setContentPane(this.box);
		    this.setVisible(true);   
	}
	//crier un label a partire d une chhaine de charactere et le mettre dans un panel donné
public void setLabelToPanel(JPanel p,String label )	{
	JLabel jlabel = new JLabel(label);
	p.add(jlabel);
}
//rajouter un champ pour afficher le score dans cette fenetre
 public JTextArea makeScor(){
	   JLabel scor = new JLabel("Score: ");
	   JPanel j=new JPanel();
	   j.add(scor);
	   JTextArea scorAffiche = new JTextArea(3, 5);
	   scorAffiche.setBackground(Color.LIGHT_GRAY);
	   scorAffiche.setText("      "+0);
	  
	   j.add(scorAffiche);
	   this.box.add(j);
	   return scorAffiche;
 }
	
	public static void main(String[] args) throws IOException {
		QuestionnaireFactory s=new QuestionnaireFactory();
		Quiz q=s.createQuestionnaire("file.txt");
		QuizWindow t = new QuizWindow();
        
		t.quizOpenWindow(q);
		

	
	}
	
	
	

	

}
