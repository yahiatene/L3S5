package graphique;



import javax.swing.JTextArea;


public class MultiAnswerGraphic extends TextualAnswerGraphic{
	
	public MultiAnswerGraphic(JTextArea m){
		super(m);
		
	}

	


}
