package graphique;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.JPanel;
import javax.swing.JSpinner;





public class NumericalAnswerGraphic extends AnswerGraphic<JSpinner>{
	
	public NumericalAnswerGraphic(JSpinner m){
		super(m);
		
	}

	
	public void answerView(JPanel p, ArrayList<?> a) {
		
		ArrayList<JSpinner> c=(ArrayList<JSpinner>) a;
		JSpinner spinner = this.champSaisie;
		JSpinner.NumberEditor spinnerEditor = new JSpinner.NumberEditor(spinner);
		spinner.setEditor(spinnerEditor);
		spinner.setPreferredSize(new Dimension(80,25));
		p.add(spinner);
		c.add( spinner);
	}


	

	}
