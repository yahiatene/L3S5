package graphique;
import java.util.ArrayList;

import javax.swing.JPanel;

import javax.swing.JTextArea;




public class TextualAnswerGraphic extends AnswerGraphic<JTextArea>{
	
	public TextualAnswerGraphic(JTextArea m){
		super(m);
		
	}

	
	
	public void answerView(JPanel p,ArrayList<?> jt){
		ArrayList<JTextArea> c=(ArrayList<JTextArea>) jt;
			JTextArea textPane  = new JTextArea(5,15);
			textPane.setLineWrap(true);
			textPane.setWrapStyleWord(false);
			c.add(textPane);
			p.add(textPane);	
			
				
			}
		
	}
