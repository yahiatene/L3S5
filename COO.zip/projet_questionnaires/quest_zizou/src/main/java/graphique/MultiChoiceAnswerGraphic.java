package graphique;

import java.awt.Panel;

import javax.swing.JTextArea;

import answer.MultiChoiceAnswer;

public class MultiChoiceAnswerGraphic extends TextualAnswerGraphic{
	
	public MultiChoiceAnswerGraphic(JTextArea m){
		super(m);
		
	}

	
}
