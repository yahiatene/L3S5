package graphique;

import javax.swing.ButtonGroup;
import javax.swing.JSpinner;
import javax.swing.JTextArea;



public class GraphicFactory{
	public AnswerGraphic<ButtonGroup>  creatYesNoAnswerGraphic(){
		return new YesNoAnswerGraphic(new ButtonGroup());
		
	}
	
	public AnswerGraphic<JTextArea>  creatMultiAnswerGraphic(){
		return new MultiAnswerGraphic(new JTextArea(5, 15));
		
		
	}
	public AnswerGraphic<JSpinner>  creatNumericalAnswerGraphic(){
		return new NumericalAnswerGraphic(new JSpinner()) ;
		
		
	}
	public AnswerGraphic<JTextArea>  creatMultiChoiceAnswerGraphic(){
		return new MultiChoiceAnswerGraphic(new JTextArea(5, 15));
		
		
	}
	public AnswerGraphic<JTextArea>  creatTextualAnswerGraphic(){
		return new TextualAnswerGraphic(new JTextArea(5, 15));
		
		
	}
	
	
}
