package graphique;


import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;



public class YesNoAnswerGraphic extends AnswerGraphic<ButtonGroup>{
	
	public YesNoAnswerGraphic (ButtonGroup  m){
		super(m);
		
	}

	
	public void answerView(JPanel p, ArrayList<?> a) {
		ArrayList<ButtonGroup> c=(ArrayList<ButtonGroup>) a;
		JRadioButton jr1 = new JRadioButton("oui");
		jr1.setMnemonic(1); 
		JRadioButton jr2= new JRadioButton("non");
		jr2.setMnemonic(2);
		ButtonGroup bg = this.champSaisie;
		bg.add(jr1);
		bg.add(jr2);
		p.add(jr1);
		p.add(jr2);
		c.add(bg);
	
		
		
	}

	
}
