package quiz;

import javax.swing.JLabel;

import answer.Answer;

public class Question {
private String statement;
private Answer<?> answer;
private int points;
public Question(String statement , Answer<?> answer, int points){
	this.statement=statement;
	this.answer=answer;
	this.points=points;
	
}
public int getPoints(){
	return this.points;
}
public Answer<?> getAnswer(){
	return this.answer;
}
public String getStatement(){
	return this.statement;
}
public JLabel statementToGraphic(){
	return new JLabel(this.statement);
}

}
