package quiz;


import answer.*;

public class AnswerFactory {
	

public static Answer<?> buildAnswer(String answer){
	try{
	Integer.parseInt(answer);

	return new NumericalAnswer(Integer.parseInt(answer));}
	catch(NumberFormatException e){
		if(answer.equals("oui")){
			return new YesNoAnswer(true);
		}
		else if(answer.equals("non")){
			return new YesNoAnswer(false);
		}
		else if(isMultiChoiceAnswer(answer)){
			return new MultiChoiceAnswer(Answer.fromString(answer,"|"),Answer.fromString(answer,"|").get(0));
		}
		else if(isMultiAnswer(answer)){
			return new MultiAnswer(Answer.fromString(answer,";"));
		}
		else{
			return new TestualAnswer(answer);
		}
	
	}
}


public static boolean isMultiAnswer(String answer){
	if (answer.indexOf(";")!=-1){
		return true;
	}
	return false;
}
public static boolean isMultiChoiceAnswer(String answer){
	if (answer.indexOf("|")!=-1){
		return true;
	}
	return false;
}

}
