package quiz;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import answer.Answer;
import display.Display;

public class Quiz{
	private ArrayList<Question> questions;
	private Scanner sc;
	public Quiz(){
		this.questions=new ArrayList<Question>();
	}
	public void addQuestion(Question question){
		this.questions.add(question);
	}
	private int ask (Question question){
		int nbPoints=0;
		this.sc = new Scanner(System.in);
		String str;
		Answer<?> answer = question.getAnswer() ;
	
		Display.displayStatement(question.getStatement());
		Display.displayGoodType(answer.getGoodType());
		str =this.sc.nextLine();
		
		while(!answer.hasGoodType(str)){
			Display.displayStatement(question.getStatement());
			Display.displayGoodType(answer.getGoodType());
			str = this.sc.nextLine();
			
		}
		if (answer.isCorrect(str)){
			nbPoints=question.getPoints();
			Display.displayItCorrect(question.getPoints());
			return nbPoints;
		}
		else{
			Display.displayItNotCorrect(question.getAnswer().toString());
			return 0;
		}
	}
	public void askAll(){
		int nbPoints = 0 ;
		for (Question question : this.questions) {
			nbPoints += this.ask(question) ;
		}
		Display.displayLeaveLines();
		Display.displayResultat(nbPoints);
	}
	public ArrayList<Question> getQuestion(){
		return this.questions;
	}
	public static void main (String[] args) throws IOException{
		QuestionnaireFactory s=new QuestionnaireFactory();
		Quiz q=s.createQuestionnaire("file.txt");
		q.askAll();
	}
}
