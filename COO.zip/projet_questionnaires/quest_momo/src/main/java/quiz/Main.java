package quiz;
import java.io.*;

public class Main {

	public static void main (String[] args) throws IOException{
		QuestionFactory s=new QuestionFactory();
		Quiz q=s.createQuestionnaire("question_tolkien.txt");
		q.askAll();
	}
}