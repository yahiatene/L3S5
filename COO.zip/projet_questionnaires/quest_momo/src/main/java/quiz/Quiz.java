package quiz;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.util.LinkedList;
import java.util.List;
import quiz.answers.Answer; ;

public class Quiz {
	
	private List<Question> questions ;
	
	private BufferedReader in ;
	private PrintStream out ;
	
	/**
	 * constructor of this class with parameters
	 * @param in
	 * @param out
	 */
	public Quiz(Reader in , PrintStream out) {
		this.questions = new LinkedList<Question>() ;
		this.in = new BufferedReader(in) ;
		this.out = out ;
		}
	
	
	/**
	 * constructor of this class without parameters
	 */
	public Quiz() {
		this(new InputStreamReader(System.in) , System.out) ;
	}

	public void add(Question question) {questions.add(question) ;}
	
	
	/**
	 * to ask a question and display the good type of the answer
	 * and allows to the user to interact with the question
	 * @param question
	 */
	private int ask(Question question) {
		Answer<?> answer = question.getAnswer() ;	
		out.println(question.getStatement()) ;
		String userAnswer = null;
		do {
			out.print("(" + answer.getGoodType() + ")") ;
			
			try {
				userAnswer = in.readLine() ;
			} catch (IOException e) {
				e.printStackTrace();
			}
		} while (! answer.hasGoodType(userAnswer)) ;
		if (answer.isCorrect(userAnswer)) {
			int points = question.getPoints() ;
			out.println("correct (" + format(points) + ")") ;
			return points ;
		} else {
			out.println("incorrect, la bonne réponse était " + answer.toString()) ;
			return 0 ;
		}
	}
	
	
	/**
	 * converts the points to String format to display it easily 
	 * @param points
	 * @return String
	 */
	private static String format(int points) {
		return "" + points + " point" + (points > 1?"s":"") ;
	}
	
	
	/**
	 * to display the result of points of all questions
	 */
	public void askAll() {
		int result = 0 ;
		for (Question question : this.questions) {
			result += this.ask(question) ;
		}
		out.println("Vous avez obtenu " + format(result)) ;
	}

}
