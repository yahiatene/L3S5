package quiz;
import quiz.answers.*;

public class Question {
	private Answer<?> answer;
	private String statement;
	private int points;
	
	/**
	 * the constructor of this class
	 * @param answer
	 * @param statement
	 * @param points
	 */
	public Question(Answer<?> answer,String statement, int points) {
		this.answer=answer;
		this.points=points;
		this.statement=statement;
		
	}
	
	/**
	 * the getter for an answer
	 * @return Answer
	 */
	public Answer<?> getAnswer(){
		return this.answer;
	}
	
	
	/**
	 * the getter for a statement
	 * @return statement
	 */
	public String getStatement() {
		return this.statement;
	}
	
	/**
	 * the getter for points 
	 * @return points
	 */
	public int getPoints() {
		return this.points;
	}

	
}
