package quiz.answers;

public abstract class Answer<T> {
	
	public T goodAnswer;
	
	
	/**
	 * the constructor of this class
	 * @param answer
	 */
	public Answer(T answer) {
		goodAnswer=answer;
	}
	
	
	public abstract String getGoodType();
	public abstract boolean hasGoodType(String statement);
	
	
	/**
	 * to check if the answer is correct or not
	 * @param statement
	 * @return boolean
	 */
	public boolean isCorrect(String answer){
			answer=answer.toLowerCase();
		
			if( this.toString().toLowerCase().equals(answer)){
				return true;
			}
			return false;
	}
	
	
	/**
	 * a getter for a good answer
	 * @return T goodAnswer
	 */
	public T getGoodAnswer() {
		return goodAnswer;
	}
	
	
	/**
	 * a description of a answer
	 */
	public String toString() {
		return ""+this.getGoodAnswer();
	}

}
