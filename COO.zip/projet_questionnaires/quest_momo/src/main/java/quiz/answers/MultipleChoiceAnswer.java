package quiz.answers;
import java.util.*;

public class MultipleChoiceAnswer extends TextualAnswer {

	private List<String> choice=new ArrayList<>();
	
	/**
	 * the constructor of this class with List<String>
	 * @param List<String>
	 */
	public MultipleChoiceAnswer(List<String> answer) {
		super(String.join(",", answer));
		this.setChoice(answer);		
	}
	
		
	
	/**
	 * a getter for good type
	 * @return String
	 */
	public String getGoodType() {
		return "multiple choice answer";

	}
	
	
	/**
	 * a getter for choice
	 * @return List<String>
	 */
	public List<String> getChoice() {
		return choice;
	}



	/**
	 * a setter for choice
	 * @param choice
	 */
	public void setChoice(List<String> choice) {
		this.choice = choice;
	}

	
	/**
	 * to know if MultipleChoiceAnswer has a good type or not
	 * @param answer
	 * @return boolean
	 */
	public boolean hasGoodType(String answer) {
		return answer.toString()==answer;
	}
	
		
	/**
	 * convert a String to List<String>
	 * @param answer
	 * @return List<String>
	 */
	public static List<String> fromString(String answer){
		return Arrays.asList(answer);
		
	}
	
	/**
	 * the constructor of this class with String
	 * @param String
	 */
	public MultipleChoiceAnswer(String answer) {
		super(answer);
		this.setChoice(fromString(answer));
		
	}
	
}
