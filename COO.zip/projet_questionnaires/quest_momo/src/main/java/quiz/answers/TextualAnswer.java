package quiz.answers;

public class TextualAnswer extends Answer<String> {
	
	
	/**
	 * the constructor of this class
	 * @param answer
	 */
	public TextualAnswer(String answer) {
		super(answer);
	}
	
	
	/**
	 * to check if it's a good type or not
	 * @param String
	 * @return boolean
	 */
	public boolean hasGoodType(String answer) {
		try{Integer.parseInt(answer);
		return false;
		}
		catch(NumberFormatException e){
		return true;
		}
	}
	
	
	
	/**
	 * a getter for good type
	 * @return String
	 */
	public String getGoodType() {
		return "textual answer";

	}

}
