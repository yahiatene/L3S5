package quiz.answers;

public class YesNoAnswer extends Answer<Boolean>{
	
	
	/**
	 * the constructor of this class
	 * @param bool
	 */
	public YesNoAnswer(boolean bool) {
		super(bool);
	}
	
	
	/**
	 * a getter for a good type
	 * @return String
	 */
	public String getGoodType() {
		return "oui/non";	
	}
	
		
	/**
	 * to check if it's a good type or not
	 * @param String
	 * @return boolean
	 */
	public boolean hasGoodType(String answer) {
		if("oui".equalsIgnoreCase(answer) || "non".equalsIgnoreCase(answer)) {
			return true;
		}else {
			return false;
		}
	}
	
	
	/**
	 * convert a string to a boolean
	 * @param answer
	 * @return boolean
	 */
	private static boolean fromString(String answer){
		if("oui".equalsIgnoreCase(answer)) {
			return true;
			}else {
				return false;
			}
		
	}
	
	
	/**
	 * the constructor of this class
	 * @param String
	 */
	public YesNoAnswer(String answer) {
		super(fromString(answer));
	}
	
	
	/**
	 * description of Yes/No Answer
	 */
	public String toString() {
		if(goodAnswer==true) {
			return "oui";
		}else {
			return "non";
		}
	}

}
