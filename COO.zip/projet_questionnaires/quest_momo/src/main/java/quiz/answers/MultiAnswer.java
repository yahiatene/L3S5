package quiz.answers;
import java.util.*;


public class MultiAnswer extends Answer<List<String>> {
	
	/**
	 * constructor of this class with List<String>
	 * @param List<String>
	 */
	public MultiAnswer(List<String> list) {
		super(list);
	}

	/**
	 * constructor of this class with String[]
	 * @param String[]
	 */
	public MultiAnswer(String[] list) {
		super(Arrays.asList(list));
	}
	
	

	/**
	 * to know if MultiAnswer has a good type or not
	 * @param answer
	 * @return boolean
	 */
	public boolean hasGoodType(String answer) {
		return answer.toString()==answer;
	}
	
	
	/**
	 * a getter for good type
	 * @return String
	 */
	public String getGoodType() {
		return "multi answer";

	}
	
	/**
	 * to know if the answer is correct or not
	 * @param answer
	 * @return boolean
	 */
	public boolean isCorrect(String answer) {
		return this.getGoodType().equals(answer);
	}
	
	
	/**
	 * convert a String to List<String>
	 * @param answer
	 * @return List<String>
	 */
	private static List<String> fromString(String answer){
		return Arrays.asList(answer);
		
	}
	
	
	/**
	 * constructor of this class with String
	 * @param String
	 */
	public MultiAnswer(String answer) {
		super(fromString(answer));
	}
	
}
