package quiz.answers;


public class NumericalAnswer extends Answer<Integer> {
	
	
	/**
	 * constructor of this class with integer
	 * @param integer
	 */
	public NumericalAnswer(int number) {
		super(number);
	}
	
	/**
	 * to know if NumericalAnswer has a good type or not
	 * @param answer
	 * @return boolean
	 */
	public boolean hasGoodType(String answer) {
		return answer != null && answer.matches("[-+]?\\d*\\.?\\d+");
	}
	
	/**
	 * a getter for good type
	 * @return String
	 */
	public String getGoodType() {
		return "numeric";

	}
	
	
	/**
	 * convert a String to integer
	 * @param String
	 * @return integer
	 */
	private static int fromString(String answer){
		return Integer.parseInt(answer);
		
	}
	
	
	/**
	 * constructor of this class with String
	 * @param String
	 */
	public NumericalAnswer(String answer) {
		super(fromString(answer));
	}

}
