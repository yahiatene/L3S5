# PROJET QUESTIONNAIRES
## YAHIATENE Mohamed
## BENKHIDER Zinedine
### DATE:22/11/2017
### UNIV LILLE1

#### Rapide introduction sur le sujet du projet:
Un questionnaire est défini par un ensemble de questions. Chaque question est caractérisée par un texte (la question elle-meme), la réponse-solution et un nombre de points. Les réponses aux questions peuvent etre de différentes natures : *numériques*, *textuelles* ou de type *oui/non* (l’utilisateur ne peut répondre que "oui" ou "non").
On représente les questionnaires pour qu'ils s'executent ainsi:

* 1. afficher le texte de la question et la nature de la solution.

* 2. attendre la réponse de l’utilisateur en n’acceptant la saisie que lorsqu’elle est conforme à la nature de la solution(par exemple un nombre si la solution est numérique).

* 3. on a alors deux situations : si la réponse donnée est correcte,l’indiquer et augmenter le score de l’utilisateur,si cette réponse n’est pas correcte, afficher la solution.

* 4. passer à la question suivante si il en reste, sinon annoncer le score global.

#### Rubrique HOWTO:

## Version Graphique:

* récupération du dépôt : **git clone** ou **git pull**
* commande génération de la documentation : **mvn javadoc:javadoc** (générée dans target/docs)
* commande de génération du projet : **mvn package**
* commande d'exécution de l'archive générée : **java -jar target/questionnaires-1.0-SNAPSHOT.jar**

## Version Text:

* changer le contenu de **mainClass** dans le *pom.xml* par **quiz.Quiz**
* récupération du dépôt : **git clone** ou **git pull**
* commande génération de la documentation : **mvn javadoc:javadoc** (générée dans target/docs)
* commande de génération du projet : **mvn package**
* commande d'exécution de l'archive générée : **java -jar target/questionnaires-1.0-SNAPSHOT.jar**

#### Présentation d'éléments de code saillant :
La mise en place des différentes classes abstraites pour faciliter la responsabilité de chaque classe et méthode selon les principes de conception **(KISS-YAGNI-DRY)** ansi que pour les methodes de test **(TDD)**.Mise en place d'un nouveau package pour la version graphique comme vu dans le td casse briques pour faciliter l'abonnement aux evenement et leur execution.

* on a reussit à faire les tests que pour le package answer.
