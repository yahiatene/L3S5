package answer;

import static org.junit.Assert.*;

import answer.Answer;
import answer.NumericalAnswer;


import org.junit.Test;

public class NumericalAnswerTest extends AnswerTest{

	public Answer<?> creatAnswer() {
		return new NumericalAnswer(2);
	}
	@Test
	public void testHasGoodType() {
		Answer<?> a=creatAnswer();
	    String s="3";
		assertTrue(a.hasGoodType(s));
		s="peace";
		assertFalse(a.hasGoodType(s));
		
		
	}

}
