package answer;

import static org.junit.Assert.*;

import answer.Answer;

import org.junit.Test;

public abstract class AnswerTest {
    public abstract Answer<?> creatAnswer();
	@Test
	public void testIsCorrect() {
		Answer<?> a=creatAnswer();
	 
		assertTrue(a.isCorrect(a.getGoodAnswer().toString()));
	}
	

}
