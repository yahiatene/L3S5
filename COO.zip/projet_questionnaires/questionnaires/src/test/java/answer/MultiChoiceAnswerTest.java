package answer;

import static org.junit.Assert.*;

import java.util.ArrayList;

import answer.Answer;
import answer.MultiChoiceAnswer;


import org.junit.Test;

public class MultiChoiceAnswerTest  extends AnswerTest{

	public Answer<?> creatAnswer() {
		ArrayList<String> answer=new ArrayList<String>();
		answer.add("been");
		answer.add("smith");
		
		return new MultiChoiceAnswer(answer,"been");
	}
	@Test
	public void testHasGoodType() {
		Answer<?> a=creatAnswer();
	    String s="been";
		assertTrue(a.hasGoodType(s));
		s="peace";
		assertFalse(a.hasGoodType(s));
		
	}
	@Test
	public void testIsCorrect() {
		Answer<?> a=creatAnswer();
	 
		assertTrue(a.isCorrect("been"));
		assertFalse(a.isCorrect("smith"));
	}

}
