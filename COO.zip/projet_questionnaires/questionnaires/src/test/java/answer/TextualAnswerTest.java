package answer;

import static org.junit.Assert.*;

import answer.Answer;
import answer.TestualAnswer;

import org.junit.Test;

public class TextualAnswerTest extends AnswerTest{

	

	
	public Answer<?> creatAnswer() {
		return new TestualAnswer("good");
	}
	@Test
	public void testHasGoodType() {
		Answer<?> a=creatAnswer();
	    String s="peace";
		assertTrue(a.hasGoodType(s));
		s="2";
		assertFalse(a.hasGoodType(s));
		
		
	}
}
