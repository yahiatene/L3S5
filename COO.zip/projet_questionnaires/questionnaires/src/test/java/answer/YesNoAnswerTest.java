package answer;

import static org.junit.Assert.*;
import answer.Answer;
import answer.YesNoAnswer;
import org.junit.Test;

public class YesNoAnswerTest extends AnswerTest {


	public Answer<?> creatAnswer() {
		return new YesNoAnswer(true);
	}
	@Test
	public void testHasGoodType() {
		Answer<?> a=creatAnswer();
	    String s="oui";
		assertTrue(a.hasGoodType(s));
		s="non";
		assertTrue(a.hasGoodType(s));
		s="peace";
		assertFalse(a.hasGoodType(s));
		
	}
	@Test
	public void testIsCorrect() {
		Answer<?> a=creatAnswer();
	 
		assertTrue(a.isCorrect("oui"));
		assertFalse(a.isCorrect("non"));
	}

}
