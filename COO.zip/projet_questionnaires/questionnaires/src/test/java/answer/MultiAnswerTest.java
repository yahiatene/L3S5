package answer;

import static org.junit.Assert.*;

import java.util.ArrayList;

import answer.Answer;
import answer.MultiAnswer;


import org.junit.Test;

public class MultiAnswerTest extends AnswerTest {

	public Answer<?> creatAnswer() {
		ArrayList<String> answer=new ArrayList<String>();
		answer.add("been");
		answer.add("smith");
		
		return new MultiAnswer(answer);
	}
	@Test
	public void testHasGoodType() {
		Answer<?> a=creatAnswer();
	    String s="been";
		assertTrue(a.hasGoodType(s));
		s="hello";
		assertTrue(a.hasGoodType(s));
		s="2";
		assertFalse(a.hasGoodType(s));
		
	}
	@Test
	public void testIsCorrect() {
		Answer<?> a=creatAnswer();
	 
		assertTrue(a.isCorrect("been"));
		assertTrue(a.isCorrect("smith"));
		assertFalse(a.isCorrect("holla"));
	}

}
