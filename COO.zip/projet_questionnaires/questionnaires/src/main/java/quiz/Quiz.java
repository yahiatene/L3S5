package quiz;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import answer.Answer;
import display.Display;

public class Quiz{
	private ArrayList<Question> questions;
	private Scanner sc;
	
	/**
	 * constructor of this class
	 */
	public Quiz(){
		this.questions=new ArrayList<Question>();
	}
	
	/**
	 * to add a question
	 * @param question
	 */
	public void addQuestion(Question question){
		this.questions.add(question);
	}
	
	/**
	 * to ask a question
	 * @param question
	 * @return integer
	 */
	private int ask (Question question){
		int nbPoints=0;
		this.sc = new Scanner(System.in);
		String str;
		Answer<?> answer = question.getAnswer() ;
	
		Display.displayStatement(question.getStatement());
		Display.displayGoodType(answer.getGoodType());
		str =this.sc.nextLine();
		
		while(!answer.hasGoodType(str)){
			Display.displayStatement(question.getStatement());
			Display.displayGoodType(answer.getGoodType());
			str = this.sc.nextLine();
			
		}
		if (answer.isCorrect(str)){
			nbPoints=question.getPoints();
			Display.displayItCorrect(question.getPoints());
			return nbPoints;
		}
		else{
			Display.displayItNotCorrect(question.getAnswer().toString());
			return 0;
		}
	}
	
	/**
	 * to ask all questions
	 */
	public void askAll(){
		int nbPoints = 0 ;
		for (Question question : this.questions) {
			nbPoints += this.ask(question) ;
		}
		Display.displayLeaveLines();
		Display.displayResultat(nbPoints);
	}
	
	/**
	 * a getter for a question
	 * @return array list
	 */
	public ArrayList<Question> getQuestion(){
		return this.questions;
	}
	
	/**
	 * the main method 
	 * @param args
	 * @throws IOException
	 */
	public static void main (String[] args) throws IOException{
		QuestionnaireFactory s=new QuestionnaireFactory();
		Quiz q=s.createQuestionnaire("file.txt");
		q.askAll();
	}
}
