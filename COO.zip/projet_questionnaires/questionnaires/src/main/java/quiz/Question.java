package quiz;

import javax.swing.JLabel;

import answer.Answer;

public class Question {
	private String statement;
	private Answer<?> answer;
	private int points;
	
	/**
	 * constructor of this class
	 * @param statement
	 * @param answer
	 * @param points
	 */
	public Question(String statement , Answer<?> answer, int points){
		this.statement=statement;
		this.answer=answer;
		this.points=points;
		
	}
	
	/**
	 * a getter for a number of points
	 * @return integer
	 */
	public int getPoints(){
		return this.points;
	}
	
	/**
	 * a getter for an answer
	 * @return answer
	 */
	public Answer<?> getAnswer(){
		return this.answer;
	}
	
	/**
	 * a getter for statement
	 * @return statement
	 */
	public String getStatement(){
		return this.statement;
	}
	
	/**
	 * to put a statement into a graphic 
	 * @return JLabel
	 */
	public JLabel statementToGraphic(){
		return new JLabel(this.statement);
	}

}
