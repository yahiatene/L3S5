package answer;

import java.util.ArrayList;
import java.util.Collections;

public class  MultiChoiceAnswer extends TestualAnswer{
	private ArrayList<String> choice;

	public  MultiChoiceAnswer(ArrayList<String> answer,String goodAnswer){
		super(goodAnswer);
		this.choice=answer;
	
	}
	public String getGoodType() {
		
		return listToString(this.choice);
	}
	public boolean hasGoodType(String answer) {
		if (this.choice.contains(answer)){
		return true;}
		return false;}
	private static String listToString(ArrayList<String> list){
		Collections.shuffle(list);
		String res="";
		for(int i=0;i<list.size()-1;i++){
			res=res+list.get(i)+" | ";
		}
		return res+list.get(list.size()-1);
	}
	
	public String toString(){
		return this.goodAnswer;
	}
	
	
}
