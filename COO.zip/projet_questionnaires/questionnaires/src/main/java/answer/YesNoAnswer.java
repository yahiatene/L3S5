package answer;

import java.util.ArrayList;
import javax.swing.JPanel;
import graphique.GraphicFactory;

public class YesNoAnswer extends Answer<Boolean>{

	/**
	 * constructor of this class
	 * @param answer
	 */
	public YesNoAnswer(boolean answer){
		super(answer);
	}


	public String getGoodType() {
		return "(oui/non)";
	}

	/**
	 * to check if the answer has a good type
	 * @param answer
	 * @return boolean
	 */
	public boolean hasGoodType(String answer) {
		if("oui".equalsIgnoreCase(answer)||"non".equalsIgnoreCase(answer)){

			return true;
		}
		return false;
	}


	public String toString(){
		if (this.goodAnswer==true){
			return "oui";
		}
		return "non";
	}

	/**
	 * to create a graphic view for this answer
	 */
	public void creatView(GraphicFactory gf, JPanel top, ArrayList<?> jt) {
		gf.creatYesNoAnswerGraphic().answerView(top, jt);

	}


}
