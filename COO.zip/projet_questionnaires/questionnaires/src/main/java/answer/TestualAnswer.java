package answer;

import java.util.ArrayList;
import javax.swing.JPanel;
import graphique.GraphicFactory;

public class TestualAnswer extends Answer<String> {
	
	/**
	 * constructor of this class
	 * @param answer
	 */
	public TestualAnswer(String answer){
		super(answer);
	}


	public String getGoodType() {
		return "(textuel)";
	}


	/**
	 * to check if the answer has a good type
	 * @param answer
	 * @return boolean
	 */
	public boolean hasGoodType(String answer) {
		try{Integer.parseInt(answer);
		return false;
		}
		catch(NumberFormatException e){
		return true;
		}
	}


	/**
	 * to create a graphic view for this answer
	 */
	public void creatView(GraphicFactory gf, JPanel top, ArrayList<?> jt) {
		gf.creatTextualAnswerGraphic().answerView(top,jt );

	}







}
