package answer;


import java.util.ArrayList;
import javax.swing.JPanel;

import graphique.GraphicFactory;

public class NumericalAnswer extends Answer<Integer>{


	/**
	 * the constructor of this class
	 * @param answer
	 */
	public NumericalAnswer(int answer){
		super(answer);

	}

	/**
	 * to get integer from string
	 * @param answer
	 * @return integer
	 */
	public static int fromString(String answer){
		return Integer.parseInt(answer);
	}

	
	public String getGoodType() {
		return "(numeric)";
	}

	/**
	 * to check if the answer has a good type
	 * @param answer
	 * @return boolean
	 */
	public boolean hasGoodType(String answer) {
		try{Integer.parseInt(answer);
		return true;
		}
		catch(NumberFormatException e){
		return false;}
}

	/**
	 * to create a graphic view for this answer
	 */
	public void creatView(GraphicFactory gf, JPanel top, ArrayList<?> jt) {
		gf.creatNumericalAnswerGraphic().answerView(top, jt);


	}}
