package answer;

import java.util.ArrayList;
import javax.swing.JPanel;

import graphique.GraphicFactory;

public class MultiAnswer extends Answer<ArrayList<String>>{

	/**
	 * constructor of this class
	 * @param listAnswer
	 */
	public MultiAnswer(ArrayList<String> listAnswer){
		super(listAnswer);

	}


	/**
	 * to get a good type of answer
	 * @return string
	 */
	public String getGoodType(){
		return "("+this.goodAnswer.size()+" possibilites)";
	}


	/**
	 * to check if the answer has a good type
	 * @param answer
	 * @return boolean
	 */
	public boolean hasGoodType(String answer) {
		try{Integer.parseInt(answer);
		return false;
		}
		catch(NumberFormatException e){
		return true;
		}
	}
	
	/**
	 * to check if the answer is correct
	 * @param answer
	 * @return boolean
	 */
	public boolean isCorrect(String answer){
		if(this.goodAnswer.contains(answer)){
			return true;
		}
		return false;
	}

	public String toString(){
		String res="";
		for (int i=0;i<this.goodAnswer.size()-1;i++){
			res=res+this.goodAnswer.get(i)+" ou ";
		}
		return res+this.goodAnswer.get(this.goodAnswer.size()-1);
	}



	/**
	 * to create a graphic view for this answer
	 */
	public void creatView(GraphicFactory gf, JPanel top, ArrayList<?> jt) {
		gf.creatMultiAnswerGraphic().answerView(top, jt);

	}









}
