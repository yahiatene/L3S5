package display;

public class Display{
	public static void displayItCorrect(int nbPoint){
		System.out.println("correct (" +nbPoint+" point(s))");
	}
	public static void displayItNotCorrect(String goodAnswer){
		System.out.println( "incorrect ,la bonne reponse est: "+goodAnswer);
	}
	public static void displayResultat(int nbPoint){
		System.out.println("vous avez "+nbPoint+" points.");
	}
	public static void displayStatement(String statement){
		System.out.println(statement);
	}
	public static void displayGoodType(String goodType){
		System.out.print(goodType);
	}
	public static void displayLeaveLines(){
		System.out.println();
	}
}
