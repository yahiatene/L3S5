package graphique;

import javax.swing.JTextArea;

public class MultiChoiceAnswerGraphic extends TextualAnswerGraphic{
	
	/**
	 * constructor of this class
	 * @param m
	 */
	public MultiChoiceAnswerGraphic(JTextArea m){
		super(m);
		
	}

	
}
