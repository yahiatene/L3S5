package graphique;

import javax.swing.ButtonGroup;
import javax.swing.JSpinner;
import javax.swing.JTextArea;



public class GraphicFactory{
	
	/**
	 * to create yes/no answer in a graphic
	 * @return button
	 */
	public AnswerGraphic<ButtonGroup>  creatYesNoAnswerGraphic(){
		return new YesNoAnswerGraphic(new ButtonGroup());
		
	}
	
	/**
	 * to create multiple answer in a graphic
	 * @return text area
	 */
	public AnswerGraphic<JTextArea>  creatMultiAnswerGraphic(){
		return new MultiAnswerGraphic(new JTextArea(5, 15));	
	}
	
	/**
	 * to create numerical answer in a graphic
	 * @return spinner
	 */
	public AnswerGraphic<JSpinner>  creatNumericalAnswerGraphic(){
		return new NumericalAnswerGraphic(new JSpinner()) ;
		
	}
	
	/**
	 * to create multiple choice answer in a graphic
	 * @return text area
	 */
	public AnswerGraphic<JTextArea>  creatMultiChoiceAnswerGraphic(){
		return new MultiChoiceAnswerGraphic(new JTextArea(5, 15));	
	}
	
	/**
	 * to create textual answer in a graphic
	 * @return text area
	 */
	public AnswerGraphic<JTextArea>  creatTextualAnswerGraphic(){
		return new TextualAnswerGraphic(new JTextArea(5, 15));
		
		
	}
	
	
}
