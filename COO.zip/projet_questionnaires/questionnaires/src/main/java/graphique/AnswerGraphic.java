package graphique;

import java.util.ArrayList;

import javax.swing.JPanel;


public abstract class AnswerGraphic<T>{
	protected T champSaisie;
	
	/**
	 * the constructor of this class
	 * @param champSaisie
	 */
	public AnswerGraphic(T champSaisie){
		this.champSaisie=champSaisie;
	}
	public abstract void answerView(JPanel p,ArrayList<?> jt);
	
}
