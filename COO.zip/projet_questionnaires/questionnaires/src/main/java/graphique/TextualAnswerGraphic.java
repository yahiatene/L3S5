package graphique;
import java.util.ArrayList;

import javax.swing.JPanel;

import javax.swing.JTextArea;

public class TextualAnswerGraphic extends AnswerGraphic<JTextArea>{
	
	/**
	 * constructor of this class
	 * @param m
	 */
	public TextualAnswerGraphic(JTextArea m){
		super(m);
		
	}

	
	/**
	 * a graphic view of the answer
	 * @param p
	 * @param jt
	 */
	public void answerView(JPanel p,ArrayList<?> jt){
		
		@SuppressWarnings("unchecked")
		ArrayList<JTextArea> c=(ArrayList<JTextArea>) jt;
			JTextArea textPane  = new JTextArea(5,15);
			textPane.setLineWrap(true);
			textPane.setWrapStyleWord(false);
			c.add(textPane);
			p.add(textPane);	
			
				
			}
		
	}
