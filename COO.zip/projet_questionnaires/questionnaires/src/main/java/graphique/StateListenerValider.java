package graphique;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import answer.NumericalAnswer;
import answer.YesNoAnswer;
import quiz.Question;

public class StateListenerValider implements ActionListener {
	private ArrayList<Question> a;
	private  ArrayList<JTextArea> jt;
	private ArrayList<ButtonGroup> bg;
	private ArrayList<JSpinner> jsp;
	private JTextArea scorAffiche;
	
	public StateListenerValider(ArrayList<JTextArea> jt,ArrayList<ButtonGroup> bg,ArrayList<JSpinner> jsp,ArrayList<Question> a,JTextArea scorAffiche){
		this.a=a;
		this.jt=jt;
		this.bg=bg;
		this.jsp=jsp;
		this.scorAffiche=scorAffiche;
	}
	//on garde que les questions qui ont la reponse oui ou non
   public ArrayList<Question> listOfYesNoQuestion(ArrayList<Question> a){
	   ArrayList<Question> res=new ArrayList<Question>();
	   for(int i=0;i<this.a.size();i++){
	   if((a.get(i).getAnswer() instanceof YesNoAnswer)){
		   res.add(a.get(i));
	   }  
   }
	   return res;
	   }
 //on garde que les questions qui ont la reponse numeric
   public ArrayList<Question> listOfNumericalQuestion(ArrayList<Question> a){
	   ArrayList<Question> res=new ArrayList<Question>();
	   for(int i=0;i<this.a.size();i++){
	   if((a.get(i).getAnswer() instanceof NumericalAnswer)){
		   res.add(a.get(i));
	   }
   }
	   return res;
	   }
 //on garde que les questions qui ont la reponse textuel (textuel answer ,multichoice answer multi answer)
   public ArrayList<Question> listOfTextualQuestion(ArrayList<Question> a){
	   ArrayList<Question> res=new ArrayList<Question>();
	   for(int i=0;i<this.a.size();i++){
	   if(!(a.get(i).getAnswer() instanceof NumericalAnswer)&& !(a.get(i).getAnswer() instanceof YesNoAnswer)){
		   res.add(a.get(i));
	   }
   }
	   return res;
	   }
   //verefier si les reponses numeric sont juste et retourner le nombre de points obtenue 
   	public int checkNumericalAnswers(){
   		int res=0;
   		ArrayList<Question> l1=this.listOfNumericalQuestion(this.a);
		for(int i=0;i<l1.size();i++){
		    	if(l1.get(i).getAnswer().isCorrect(this.jsp.get(i).getValue().toString())){
	        res=res+l1.get(i).getPoints();}
		    }
		return res;
   	}
  //verefier si les reponses par oui ou non sont juste et retourner le nombre de points obtenue 
   	public int checkYesNoAnswers(){
   		int res=0;
   		ArrayList<Question> l2=this.listOfYesNoQuestion(this.a);
		for(int i=0;i<l2.size();i++){
			try{
			if(this.bg.get(i).getSelection().getMnemonic()==1){
				if(l2.get(i).getAnswer().isCorrect("oui")){
					 res=res+l2.get(i).getPoints();}}
			else{
				if(l2.get(i).getAnswer().isCorrect("non")){
					 res=res+l2.get(i).getPoints();
				}}}
			catch(java.lang.NullPointerException e){
			} }
		return res;
   	}
  //verefier si les reponses textuals sont juste ,et retourner le nombre de points obtenue 
 	public int checkTextualAnswers(){
 		int res=0;
 		ArrayList<Question> l=this.listOfTextualQuestion(this.a);
		for(int i=0;i<l.size();i++){
			  if(l.get(i).getAnswer().isCorrect(this.jt.get(i).getText())){
    	        res=res+l.get(i).getPoints();}
			    }
		return res;
 	}
 	//l'action a faire quand on appel cet evenement c'est de verefier tout les champs saisie par l utilisateur si ils sont vraie 
 	//si c'est vraie on augmente le nombre le score avec le nombre de point que elle contient la question
	public void actionPerformed(ActionEvent arg0) {
		int res=checkTextualAnswers()+checkYesNoAnswers()+checkNumericalAnswers();
		
		this.scorAffiche.setText("      "+res);
    	    }
	  

	

}
