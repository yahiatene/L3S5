#BENKHIDER Zinedine
#YAHIATENE Mohamed



Le code et les tests sont fait comme demandé,sauf que dans la classe Collector un objet  Collector de type carrot ne peut pas donner un objet carrot pour collector de type vegetable,alors que ça devrait compiler.

//carrotCollector1.giveTo(vegetableCollector); 
