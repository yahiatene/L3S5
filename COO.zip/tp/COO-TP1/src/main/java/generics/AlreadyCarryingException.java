package generics;

public class AlreadyCarryingException extends Exception {
	public AlreadyCarryingException(){
		
	}
}