package generics;
import java.util.*;

/** define collectors able to collect (and carry) one specific type T of objects
 * only one T object can be carried at a time
 */

public class Collector<T> {
	/*The constructor of the class Collector*/
    public Collector(String name) {
	this.name = name;
    }

    private String name;

	private List<T>  carriedObject= new ArrayList<T>();
	
    /*
     * This role of this method is to take or pick an object
     * which is passed in parameter provided that no object is token
     * else an exception is thrown.
     * @param : obj Object
     * @exception : AlreadyCarryingException 
     */
	public void take ( T obj) throws AlreadyCarryingException{
		if (this.carriedObject.isEmpty()==true){
			this.carriedObject.add(obj);
		}
		else{
			throw new AlreadyCarryingException (); 
		}}
		
	/*
	*to drop the object, nothing happens if the picker
	*does not carry any object, the method returns the object dropped,
 	*null if none
 	*@return : Object
 	**/
	public T drop(){
		if(this.carriedObject.isEmpty()==true){
			return null;
		}else{
			T objet=this.carriedObject.get(0);
			this.carriedObject.remove(0);
			return objet;
		}
	}
	
	
	
	/*
	 * returns the carried object or null if this collector is empty 
	 * @return : Object
	*/
	public T getCarriedObject(){
		if(this.carriedObject.isEmpty()==true){
			return null;
		}else{
		
			return this.carriedObject.get(0);
			
		}
	}
	
	/*
	*to give the object to another picker, which must be of a compatible type,
	*nothing happens if it does not carry an object and an exception AlreadyCarryingException
	*is lifted if the recipient already carries an object.
	*@param : colector Object
	*/
	public void giveTo(Collector< T>  col) throws AlreadyCarryingException{	
			if (col.carriedObject.isEmpty()==true){
			col.carriedObject.add(this.carriedObject.get(0));
			this.carriedObject.remove(0);
		}
		else{
			throw new AlreadyCarryingException (); 
		}
	}
	
	
	
	
    public String toString() {
	return this.name;
    }
    public String description() {
	return this.name + " carries " + this.carriedObject;
    }
    // METHODES a DEFINIR
    // take : pour prendre un objet de type T (si aucun de "tenu")
    // getCarriedObject : pour connaitre l'objet "porte" (null si saucun)
    // giveTo : donne l'objet porte a un autre ramasseur compatible 
    // drop : depose l'objet "tenu"

    public static void main(String[] args) throws AlreadyCarryingException {
	
		//Carrot c1 = new Carrot(1);
		Carrot c2 = new Carrot(2);
		Carrot c3 = new Carrot(3);
		Apple p1 = new Apple(1);
		Apple p2 = new Apple(2);

		Collector<Carrot> carrotCollector1 = new Collector<Carrot>("carrot-collector-1");
		Collector<Carrot> carrotCollector2 = new Collector<Carrot>("carrot-collector-2");
		Collector<Apple> appleCollector1 = new Collector<Apple>("apple-collector-1");
		
		// attention ici le type d'objets ramasses est Legume :
		//Collector<Vegetable> vegetableCollector = new Collector<Vegetable>("vegetable-collector");

		carrotCollector1.take(c3);
		System.out.println(carrotCollector1.description());
		// NE COMPILE PAS
		//carrotCollector2.take(p1);

		// NE COMPILE PAS
		// carrotCollector1.giveTo(appleCollector1);

		// COMPILE :
		//carrotCollector1.giveTo(vegetableCollector);

		// NE COMPILE PAS
		// vegetableCollector.giveTo(carrotCollector1);
		// NE COMPILE PAS
		// appleCollector1.giveTo(vegetableCollector);

		//carrotCollector1.take(c1);
		carrotCollector1.giveTo(carrotCollector2);
		System.out.println(carrotCollector1.description());
		System.out.println(carrotCollector2.description());
		carrotCollector1.take(c2);
		System.out.println(carrotCollector2.description());
		
	
		try {
			carrotCollector1.giveTo(carrotCollector2);
		} catch (AlreadyCarryingException e) {
			System.out.println("*** exception : " + carrotCollector2 + " porte deja qque chose");
			//System.out.println(" * " + e.getMessage());
		}
		
		appleCollector1.take(p2);
		System.out.println(appleCollector1.description());
		try {
			appleCollector1.take(p1);
		} catch (AlreadyCarryingException e) {
			System.out.println("*** exception : " + appleCollector1 + " porte deja qque chose");
			//System.out.println(" * " + e.getMessage());
		}
	
		appleCollector1.drop();
		System.out.println(appleCollector1.description());
		appleCollector1.take(p1);
		System.out.println(appleCollector1.description());
     }
}
