package generics;

import scanner.*;
import java.util.*;

public class VegetableListChoser extends ListChoser {

    // methode chose
    // elle est similaire a celle de ListChoser simplement elle ne fonctionne
    // qu'avec des listes d'objets de type Legume (cf. interface Legume)
    // quel changement apporter a la methode de ListChoser  ?
	public <Vegetable> Vegetable chose(String ch,List<Vegetable> liste){
		final Scanner scanner = new Scanner(System.in);
		int size=liste.size();
		System.out.print(ch);
		int input = -1;
		while (input < 0 || input > size) {
			System.out.print("entrez un nombre entre 0 et "+ size +" !!");
			
				input = scanner.nextInt();
				if (input==0){
					System.out.println("aucun element ne correspond a votre saisie");
					input = -1;
				}
		}scanner.skip(".*");
		
					return liste.get(input-1);
				
	}
    public static void main(String[] args) {
		List<Carrot> lCarrots = new ArrayList<Carrot>();
		lCarrots.add(new Carrot(1));
		lCarrots.add(new Carrot(2));
		lCarrots.add(new Carrot(3));

		List<Apple> lApples = new ArrayList<Apple>();
		lApples.add(new Apple(1));
		lApples.add(new Apple(2));
		lApples.add(new Apple(3));

		VegetableListChoser lcl = new VegetableListChoser();

		Carrot chosenCarrot = lcl.chose("which carrot ? ", lCarrots);
		System.out.println("You have chosen : " + chosenCarrot);

		// NE COMPILE PAS
		// Apple chosenApple = lcl.chose("which apple ? ",lApples);


    }
}
