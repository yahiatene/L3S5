package generics;

public interface Vegetable {
	public String toString();
}
