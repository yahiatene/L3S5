import static org.junit.Assert.*;


import org.junit.Test;
import org.junit.*;
import generics.Carrot;
import generics.Apple;
import generics.Collector;
import generics.AlreadyCarryingException;

public class TesteCollector{
	
	@Test
	
	public final void testgetCarriedObject ()throws AlreadyCarryingException{
		Collector<Carrot> carrotCollector1 = new Collector<Carrot>("carrot-collector-1");
		Collector<Apple> appleCollector1 = new Collector<Apple>("apple-collector-1");
		Carrot c1 = new Carrot(1);
		assertEquals(carrotCollector1.getCarriedObject(),null);
		carrotCollector1.take(c1);
		assertEquals(carrotCollector1.getCarriedObject(),c1);
		//meme teste pour apple
		Apple a1 = new Apple(1);
		assertEquals(appleCollector1.getCarriedObject(),null);
		appleCollector1.take(a1);
		assertEquals(appleCollector1.getCarriedObject(),a1);
		
	}
	@Test

    public final void testTake() throws AlreadyCarryingException{

    
	Collector<Carrot> carrotCollector1 = new Collector<Carrot>("carrot-collector-1");
	Carrot c1 = new Carrot(1);
	Carrot c2 =new Carrot(2);

	carrotCollector1.take(c1);
	assertEquals(c1,carrotCollector1.getCarriedObject());
	
	 try {
		 carrotCollector1.take(c2);
		    Assert.fail("take devrait lancer une exception");
		  } catch (AlreadyCarryingException e) {
		    // affiche un message c'est le comportement attendu.
			  
		  }
	
	
}
	@Test
	public final void testDrop() throws AlreadyCarryingException{
		Collector<Carrot> carrotCollector1 = new Collector<Carrot>("carrot-collector-1");
		Collector<Apple> appleCollector1 = new Collector<Apple>("apple-collector-1");
		Carrot c1 = new Carrot(1);
		Apple a1 = new Apple(1);
		assertEquals(null,carrotCollector1.drop());
		carrotCollector1.take(c1);
		assertEquals(c1,carrotCollector1.getCarriedObject());
		carrotCollector1.drop();
		assertEquals(null,carrotCollector1.getCarriedObject());
		
		//meme teste pour apple
		assertEquals(null,appleCollector1.drop());
		
		appleCollector1.take(a1);
		assertEquals(a1,appleCollector1.getCarriedObject());
		appleCollector1.drop();
		assertEquals(null,appleCollector1.getCarriedObject());
	}
	@Test
	public final void testGiveTo() throws AlreadyCarryingException{
		Collector<Apple> appleCollector1 = new Collector<Apple>("apple-collector-1");
		Collector<Apple> appleCollector2 = new Collector<Apple>("apple-collector-2");
		Collector<Carrot> carrotCollector1 = new Collector<Carrot>("carrot-collector-1");
		Collector<Carrot> carrotCollector2 = new Collector<Carrot>("carrot-collector-2");
		Carrot c1 =new Carrot(1);
		carrotCollector1.take(c1);
		carrotCollector1.giveTo(carrotCollector2);
		assertEquals(carrotCollector1.getCarriedObject(),null);
		assertEquals(carrotCollector2.getCarriedObject(),c1);
		//meme teste pour apple
		Apple a1 =new Apple(1);
		appleCollector1.take(a1);
		appleCollector1.giveTo(appleCollector2);
		assertEquals(appleCollector1.getCarriedObject(),null);
		assertEquals(appleCollector2.getCarriedObject(),a1);
		
		
	}

}

 