package donjon;
public class Potion{
	
	private String type;
	
	public Potion(){
		
	}
}