package donjon;
public class Room{
	
	public Room(){
		
	}
}