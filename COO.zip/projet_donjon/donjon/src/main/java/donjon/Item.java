package donjon;
public class Item{
	
	private int valeur;
	
	public Item(){
		
	}
	
	public boolean use(Character p1){
		return true;
	}
}