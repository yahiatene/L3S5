package donjon;
public class Character{
	
	private int hp;
	private String gold;
	private int strength;
	private int id;
	
	public Character(){
		
	}
	
	public boolean attack(Character p1){
		return true;
	}
	
}