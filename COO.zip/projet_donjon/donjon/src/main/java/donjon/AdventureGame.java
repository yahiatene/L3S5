package donjon;
import java.util.*;

public class AdventureGame{
	
	private boolean end;
	private double probdoor;
	private String probend;
	
	public AdventureGame(){
		
	}
	
	public void init(){
		
	}
	
	public void turn(){
		
	}
	
	public void play(){
		
	}
}