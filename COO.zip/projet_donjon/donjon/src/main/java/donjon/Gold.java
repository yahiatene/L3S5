package donjon;
public class Gold{
	
}