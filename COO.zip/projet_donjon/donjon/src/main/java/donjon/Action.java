package donjon;

public class Action{
	
	public Action(){
		
	}
	
	public boolean act(){
		return true;
	}
}