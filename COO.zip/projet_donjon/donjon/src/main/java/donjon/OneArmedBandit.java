package donjon;
public class OneArmedBandit{
	
	private String cost;
	
	public OneArmedBandit(){
		
	}
}