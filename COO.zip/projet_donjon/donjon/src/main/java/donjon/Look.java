package donjon;
public class Look{
	
	private String r;
	
	public Look(){
		
	}
}