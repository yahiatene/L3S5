package donjon;
public class Use{
	
	private Character c1;
	private Item i;
	
	public Use(){
		
	}
}