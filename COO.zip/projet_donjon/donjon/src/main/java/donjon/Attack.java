package donjon;
public class Attack{
	
	private Character c1;
	private Character c2;
	
	public Attack(){
		
	}
	
}