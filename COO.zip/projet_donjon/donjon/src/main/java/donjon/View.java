package donjon;
public class View{
	
	public View(){
		
	}
	
	public void introduction(){
		
	}
	
	public void turn(){
		
	}
}