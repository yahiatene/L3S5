package donjon;
public class Move{
	
	private Room r;
	private int choiceid;
}