package adventure.action;

public class LookAction implements Action{

	public LookAction(){

	}


	public void madeBy(Player p){

	}


	public boolean isPossible(Player p){


	}

	public String choiceLabel(){

	}

	public String getDescription(){

	}



}
