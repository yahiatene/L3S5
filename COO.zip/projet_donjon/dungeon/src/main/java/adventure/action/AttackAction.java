package adventure.action;

public class AttackAction implements Action{

	int points;
	String label;

  /*
	*The constructor of AttackAction class
	*/
	public AttackAction(){
    points=10;
		label="middle";
	}


	public void madeBy(Player p){
		Player.points--;
	}


	public boolean isPossible(Player p){
   return this.points >= 0;

	}


		public String choiceLabel(){
			return this.label;
		}

	public String getDescription(){
		return "this character has attacked with "+points+"points in level "+label;
	}


}
