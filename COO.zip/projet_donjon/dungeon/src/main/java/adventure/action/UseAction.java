package adventure.action;
public class UseAction implements Action{

	public UseAction(){

	}


		public void madeBy(Player p){

		}


		public boolean isPossible(Player p){


		}


		public String choiceLabel(){

			}

		public String getDescription(){

		}
}
