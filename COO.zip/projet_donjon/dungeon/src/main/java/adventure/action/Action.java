package adventure.action;
import adventure.gameui.Choseable;
import adventure.entities.GameCharacter;

public interface Action implements Choseable{

public void madeBy(Player p);
public boolean isPossible(Player p);
public String getDescription();
}
