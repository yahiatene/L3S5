package adventure.entities;

public class Monster extends GameCharacter implements Choseable {


  public Monster(int strength,int life,int gold,String name){
    super();
  }

}
