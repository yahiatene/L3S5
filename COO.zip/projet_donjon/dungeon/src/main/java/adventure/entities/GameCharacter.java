package adventure.entities;
public class GameCharacter{

	private AdventureGame game;
	private int strength;
	private int life;
	private int gold;
	private String name;

	public GameCharacter(int strength,int life,int gold,String name){
		this.strength=strength;
		this.life=life;
		this.gold=gold;
		this.name=name;

	}

	public void setGame(AdventureGame){

	}

	public AdventureGame getGame(){
		return this.game;
	}


	public boolean isDead(){
		return this.life==0;
	}

	public int getStrength(){
		return this.strength;
	}

	public void changeStrength(int st){
		this.strength=st;
	}

	public int getLife(){
		return this.life;
	}

	public void changeLife(int lf){
		this.life=lf;
	}

	public int getGold(){
		return this.gold;
	}

	public void changeGold(int gld){
		this.gold=gld;
	}

	public void attack(GameCharacter gamer){
		if (!gamer.isDead()) {
			gamer.strength--;
		}else{
			System.out.println("This GameCharacter is dead !");
		}
	}

	public void die(){
		this.life=0;
	}
}
