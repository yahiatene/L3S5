package security;

public class StubbornUserTest {

	protected User createUser() {
		return  new StubbornUser("stubborn timoleon");
	}

}
