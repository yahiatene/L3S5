package generic;

import generic.content.Content;
import generic.content.Edible;

public class ContainerForEdible<C extends Content & Edible> extends Container<C> {

	public ContainerForEdible(int maxVolume) {
		super(maxVolume);
	}

}
