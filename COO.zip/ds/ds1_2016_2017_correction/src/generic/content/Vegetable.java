package generic.content;

public class Vegetable implements Content, Edible {

	@Override
	public int volume() {
		// TODO Auto-generated method stub
		return 0;
	}

}
