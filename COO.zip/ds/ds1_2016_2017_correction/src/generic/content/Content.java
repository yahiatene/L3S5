package generic.content;

public interface Content {
	public int volume();
}
