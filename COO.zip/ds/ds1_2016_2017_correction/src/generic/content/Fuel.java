package generic.content;

public class Fuel implements Content {

	public int volume() {
		return 0;
	}

}
