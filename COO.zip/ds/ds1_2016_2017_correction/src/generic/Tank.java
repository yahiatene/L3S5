package generic;

import generic.content.Fuel;

public class Tank extends Container<Fuel> {

	public Tank(int maxVolume) {
		super(maxVolume);
	}

}
