package generic;

import generic.content.Content;

public class Container<C extends Content> {

	private int maxVolume;
	private int currentVolume;

	public Container(int maxVolume) {
		this.maxVolume = maxVolume;
		this.currentVolume = 0;
	}

	public void add(C content) throws NotEnoughFreeSpaceException {
		if (this.maxVolume >= this.currentVolume + content.volume()) {
			this.currentVolume = this.currentVolume + content.volume();
		}
		else throw new NotEnoughFreeSpaceException();
	}

	public int getCurrentVolume() {
		return this.currentVolume;
	}

	public void fillFrom(Container<? extends C> other) throws NotEnoughFreeSpaceException {
		if (this.maxVolume >= this.currentVolume + other.getCurrentVolume()) {
			this.currentVolume = this.currentVolume + other.getCurrentVolume();
		}
		else throw new NotEnoughFreeSpaceException();
	}
	
}
