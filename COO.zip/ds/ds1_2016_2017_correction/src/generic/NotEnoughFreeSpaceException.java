package generic;

public class NotEnoughFreeSpaceException extends Exception {

}
