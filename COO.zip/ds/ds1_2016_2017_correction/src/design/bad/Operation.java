package design.bad;

public enum Operation {
	totalPrecipitation, maxTemperature, minTemperature;
}
