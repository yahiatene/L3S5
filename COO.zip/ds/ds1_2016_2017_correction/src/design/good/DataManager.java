package design.good;

import java.util.List;

import design.WeatherData;
import design.Logger;
import design.bad.Operation;

public abstract class DataManager {

	private Logger logger;

	public DataManager(Operation op) {
		this.logger = new Logger();
	}

	protected abstract float initProcess();
	protected abstract float processData(float result, WeatherData data);
	
	public float processData(List<WeatherData> datas) {
		this.logger.register(datas.size() + " data received");
		float result = this.initProcess();
		long start = System.currentTimeMillis();
		for (WeatherData data : datas) {
			result = this.processData(result,data);
		}
		long end = System.currentTimeMillis();
		this.logger.register(" data processed in " + (end - start) + "ms");
		return result;
	}

}
