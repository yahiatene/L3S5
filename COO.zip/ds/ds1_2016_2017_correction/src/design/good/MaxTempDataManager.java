package design.good;

import design.WeatherData;
import design.bad.Operation;

public class MaxTempDataManager extends DataManager {

	public MaxTempDataManager(Operation op) {
		super(op);
	}

	protected float initProcess() {
		return - 1000;
	}

	protected float processData(float result, WeatherData data) {
		return Math.max(result, data.getTemperature());
	}

}
