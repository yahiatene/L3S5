package design.good;

import design.WeatherData;
import design.bad.Operation;

public class MinTempDataManager extends DataManager {

	public MinTempDataManager(Operation op) {
		super(op);
	}

	protected float initProcess() {
		return + 1000;
	}

	protected float processData(float result, WeatherData data) {
		return Math.min(result, data.getTemperature());
	}

}
