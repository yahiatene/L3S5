package design.good;

import design.WeatherData;
import design.bad.Operation;

public class TotalPrecipitationDataManager extends DataManager {

	public TotalPrecipitationDataManager(Operation op) {
		super(op);
	}

	protected float initProcess() {
		return 0;
	}

	protected float processData(float result, WeatherData data) {
		return result + data.getPrecipitation();
	}

}
