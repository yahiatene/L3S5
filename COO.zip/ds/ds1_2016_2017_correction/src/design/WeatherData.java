package design;

public class WeatherData {

	private float precipitation;
	private float temperature;

	public WeatherData(float precipitation, float temp) {
		this.precipitation = precipitation;
		this.temperature = temp;
	}

	/**
	 * @return the precipitation
	 */
	public float getPrecipitation() {
		return this.precipitation;
	}

	/**
	 * @return the temperature
	 */
	public float getTemperature() {
		return this.temperature;
	}
}
