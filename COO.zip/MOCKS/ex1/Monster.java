package ex1;

import java.awt.Color;
import java.util.Random;

public class Monster {
	Color color;
	int department;
	
	public Monster() {
		Random r = new Random();
this.color = new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256));
		this.department = r.nextInt(100);
	}

	public int getPreferredDepartment() {
		return this.department;
	}

	public Color getEyeColor() {
		return this.color;
	}

}
