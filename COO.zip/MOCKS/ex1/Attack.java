package ex1;

public class Attack{

    public boolean isPossible(Room r){
        return r.containsMonsters();
    }
}
