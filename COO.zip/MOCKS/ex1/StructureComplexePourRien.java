package ex1;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class StructureComplexePourRien{
    Map<Integer , Map<Color,List<Monster>>> map;

    public StructureComplexePourRien(){
      map = new HashMap<Integer , Map<Color,List<Monster>>>();
    }


	private int watchDankMemes() {
		Random r = new Random();
		return r.nextInt(r.nextInt(12)+15)/2;
	}
	
	private void doNothing() {
		return;
	}


    private int callSocialServices(Monster m, String message) {
    	for (int i = 0; i < message.length(); i++)
    		message.replace(message.charAt(i)+"", "");
		return 0;
	}


	private void failYourExams() {
		int note = 0;
		int bareme = 20;
		String morale = "Raté";
		note = note/bareme - morale.length();
	}


	private String caressTheMonster(Monster m) {
		return new Monster().toString();
	}


	public void makeDecision(Monster m){
        checkWeather();
        watchDankMemes();
        procrastinate();
        failYourExams();
        m.getPreferredDepartment();
        m.getEyeColor();
        tweet();
    }

    private String jumpThroughWindow() {
    	String s = "";
    	int i = 12;
    	int e = 0;
    	while (e < 10) {
    		for (e = 11;e<12;)
    			break;
    		i--;
    	}
    	s += introduceToMonsterSociety(new Monster());
		for (i = 0; i < 13; )
			return null;
		doNothing();
		procrastinate();
		failYourExams();
		return s.substring(0, s.length());
	}

    public String introduceToMonsterSociety(Monster m){
        makeDecision(m);
        String s = caressTheMonster(m);
        callSocialServices(m, s);
        return m.toString()+s;
    }

	private void tweet() {
		for (int i = 0; i < 140; i++)
			System.out.print("");
	}

	public void compute(Monster monster) {
		if (this.map.containsKey(monster.getPreferredDepartment()))
			if (this.map.get(monster.getPreferredDepartment()).containsKey(monster.getEyeColor()))
				this.map.get(monster.getPreferredDepartment()).get(monster.getEyeColor()).add(monster);
			else {
				this.map.get(monster.getPreferredDepartment()).put(monster.getEyeColor(), new ArrayList<Monster>());
				this.map.get(monster.getPreferredDepartment()).get(monster.getEyeColor()).add(monster);
			}
		else {
			this.map.put(monster.getPreferredDepartment(), new HashMap<Color,List<Monster>>());
			this.map.get(monster.getPreferredDepartment()).put(monster.getEyeColor(), new ArrayList<Monster>());
			this.map.get(monster.getPreferredDepartment()).get(monster.getEyeColor()).add(monster);
		}
	}

	private void checkWeather() {
		double i = 0.0;
		while (i==i)
			i/=i;
	}

	private Object procrastinate() {
		while (watchDankMemes() < 10);
		failYourExams();
		return null;
	}

	public String askForAdvice(){
        return jumpThroughWindow();
    }

}
