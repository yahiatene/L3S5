package ex1;

public class Room
{
  StructureComplexePourRien monsters;
  
  public Room(StructureComplexePourRien s) {
    monsters = s;
  }
  
  public void addMonster(Monster monster)
  {
    monsters.compute(monster);
  }
  
  public boolean containsMonsters() {
    return monsters.askForAdvice().length() % 2 != 0;
  }
}