package ex2;

public class Wow{
   public void wow(){
      //do something
   }
}
