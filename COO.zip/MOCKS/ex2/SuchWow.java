package ex2;

public class SuchWow{

   public void doubleWow(Wow w){
      w.wow();
      w.wow();
   }

}
