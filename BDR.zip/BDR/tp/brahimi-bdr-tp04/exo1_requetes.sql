---AUTEUR1:BRAHIMI Youcef


---q1)

select aid,acoul from articles a1 where not exists(select aid,acoul from articles a2 where a1.aid != a2.aid and a1.acoul=a2.acoul);


---q2)

---not exists---
select anom from articles a1 where a1.acoul='rouge' and not exists(select anom from articles a2 where a1.anom=a2.anom and a2.acoul='vert');

--- not in---
select anom from articles where acoul='rouge' and anom not in (
select anom from articles where acoul='vert');

---all---
select anom from articles a1 where a1.acoul='rouge' and a1.anom <> all(select anom from articles a2 where a1.anom=a2.anom and a2.acoul='vert');



---q3)

select f.fid, f.fnom,f.fad, c.aid,c.prix from fournisseurs f , catalogue c
where f.fid=c.fid and c.prix>all(select avg(catalogue.prix) from catalogue where catalogue.aid=c.aid);


---q4)

select aid from articles natural join fournisseurs  natural join catalogue c1 where exists(select aid,anom from articles natural join fournisseurs natural join catalogue c2 where c1.fid!=c2.fid and c1.aid=c2.aid) group by aid;


---q5)

--- not in ---
select fid,fnom from fournisseurs where fournisseurs.fid not in(select fid from catalogue);


--- all ---
select fid,fnom from fournisseurs where fid <> all (select fid from catalogue);


---q6)

select c.aid, a.anom, a.acoul from catalogue c, articles a, fournisseurs f where f.fnom='kiventout' and c.fid=f.fid and a.aid=c.aid and not exists(select * from catalogue c2 where c2.fid<>c.fid and c2.aid=c.aid);


---q7)






---q8)

select f.fnom from fournisseurs f , catalogue c
where f.fid=c.fid and not exists(select c2.prix from catalogue c2 where c2.prix>c.prix);


---q9)

select a.anom , min(prix) , max(prix) from articles a natural join catalogue c
where exists(
select a2.anom from articles a2 natural join catalogue c2 where a2.anom=a.anom and c2.fid<>c.fid
)
group by a.anom




---q10)

select distinct f.fnom, a.anom from fournisseurs f, articles a ,catalogue c 
where c.fid=f.fid and c.aid=a.aid and exists(
select f2.fnom, a2.anom from fournisseurs f2, articles a2 ,catalogue c2 where
f2.fid=f.fid and c.fid=c2.fid and a2.anom=a.anom and c2.aid=a2.aid and a2.aid<>a.aid);


---q11)

---not exists---
select distinct a.anom from articles a,catalogue c where not exists(
select a2.anom from articles a2,catalogue c2 where a2.anom=a.anom and c2.aid=a2.aid and c2.fid<>c.fid);


---group by---


select a.anom from articles a natural join catalogue c
group by a.anom
having count(c.fid)=1



---q12)

---not exists---
select distinct c.aid from catalogue c where prix >='100' and not exists(
select c2.aid from catalogue c2 where c2.aid=c.aid and c2.fid<>c.fid and prix <'100');


---all---
select distinct c.aid from catalogue c where prix >='100' and c.aid <> all(
select c2.aid from catalogue c2 where c2.aid=c.aid and c2.fid<>c.fid and prix <'100');


---q13)
select distinct c.aid from catalogue c , fournisseurs f where c.fid=f.fid and f.fad like '%USA';


---q14)

select distinct c.fid,f.fnom from fournisseurs f natural join articles a natural join catalogue c where
a.acoul='rouge' and c.fid not in(select distinct c2.fid from fournisseurs f2 natural join articles a2 natural join catalogue c2 where a2.acoul<>'rouge');


---q15)



