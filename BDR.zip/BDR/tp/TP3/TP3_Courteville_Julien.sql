AUTEUR 1 : Courteville Julien
AUTEUR 2 : Dufour Simon

---Question 1
SELECT max(prix) FROM catalogue

---Question 2
SELECT max(prix), anom FROM catalogue NATURAL JOIN articles

---Question 3


--- Question 4
 SELECT anom AS ARTICLE, count(acoul) AS NB_COUL FROM articles GROUP BY anom

---Question 5
SELECT anom, max(prix), min(prix), count(fid) AS NB_FOURNISSEUR FROM catalogue NATURAL JOIN articles GROUP BY anom HAVING count(fid)>1 ORDER BY avg(prix) DESC

Question 6
SELECT acoul FROM articles GROUP BY acoul HAVING count(aid)=1

---Question 7
SELECT acoul AS COULEUR, avg(prix) AS PRIX_MOYEN FROM catalogue NATURAL JOIN articles WHERE anom!='Ferrari F430' GROUP BY acoul HAVING count(acoul)>1 ORDER BY avg(prix) DESC

---Question 8
SELECT anom, acoul, count(fid) AS NB_FOURNISSEURS FROM catalogue NATURAL JOIN articles GROUP BY anom, acoul

---Question 9
SELECT anom, count(fid) AS NB_FOURNISSEURS FROM articles NATURAL LEFT JOIN catalogue GROUP BY anom

---Question 10
SELECT fnom AS FOURNISSEUR, count(DISTINCT anom) AS NB_A FROM fournisseurs NATURAL JOIN catalogue NATURAL JOIN articles GROUP BY fnom HAVING count(anom)>1

---Question 11
Affichez les noms des fournisseurs offrant un même article en différentes couleurs. Indiquer de quel article il s’agit.
> SELECT fnom, anom FROM fournisseurs NATURAL JOIN catalogue NATURAL JOIN articles GROUP BY fnom, anom HAVING count(anom)>1

---Question 12
 SELECT anom FROM fournisseurs NATURAL JOIN catalogue NATURAL JOIN articles GROUP BY anom HAVING count(DISTINCT fid)=1


Question 13
Vous désirez produire un tableau similaire pour les couleurs des articles.
> SELECT substring(CAST(acoul as varchar) from 1 for 1) AS lettre, count(substring(CAST(acoul as varchar) from 1 for 1)) FROM articles GROUP BY substring(CAST(acoul as varchar) from 1 for 1)

---Question 14
---Testez, lisez la doc et expliquez les différences et les points communs entre cette première requête, avec ON :
SELECT * FROM articles JOIN catalogue ON articles.aid=catalogue.aid
et cette seconde, avec USING :
SELECT * FROM articles JOIN catalogue USING(aid)


---La premiere requête correspond à la requête
SELECT * FROM articles NATURAL JOIN catalogue
---Cependant, le mot clé ON permet de préciser quel colonne on souhaite joindre, ainsi, on obtient deux fois la colonne aid.

---La seconde requête utilise le mot clé USING. C'est un cas particulier de la clause ON. Cette requête fait donc la même chose que 
SELECT * FROM articles JOIN catalogue ON articles.aid=catalogue.aid
---mais elle supprime les colonnes superflut.
---En faite, on fait un NATURAL JOIN lorsque la liste des colonnes à joindre est implicite.
