--YAHIATENE Mohamed
--BENKHIDER Zinedine
--TP5_BDR
--Date:25/10/2017



--Q1:
select e.eid from avions a,certifications c,employes e where c.eid=e.eid and c.aid=a.aid group by e.eid having count(e.eid)>=2;

--Q2:
select e.enom from certifications c,employes e where c.eid=e.eid and not exists(select * from vols v where v.dep='CDG' and v.arr='NOU' and v.prix<e.salaire);

--Q3:
select dep,arr from vols natural join avions natural join employes natural join certifications where vols.distance<=avions.portee and employes.salaire>100000 group by dep,arr;

--avec exists:
select dep,arr from vols natural join avions where vols.distance<=avions.portee and exists(select distinct(enom) from employes where employes.salaire>100000) group by dep,arr;

--Q4:
--avec exists:
select distinct enom 
from employes e natural join certifications c natural join avions a 
where a.portee>1500 and not exists(select * from certifications c1, avions a1 where e.eid=c1.eid and c1.aid=a1.aid and a1.portee < 1500);

--avec group by et EVERY:
select enom from employes natural join certifications natural join avions group by enom having every(avions.portee>1500)=true;

--Q5:
select enom 
from employes e natural join certifications c natural join avions a 
where a.portee>1500 and not exists(select * from certifications c1, avions a1 where e.eid=c1.eid and c1.aid=a1.aid and a1.portee < 1500)group by enom having count(enom)>1;



--Q6:
select distinct enom
from employes e natural join certifications c natural join avions a 
where a.portee>1500 and not exists(select * from certifications c1, avions a1 where e.eid=c1.eid and c1.aid=a1.aid and a1.portee < 1500) group by enom having count(a.anom like 'Boeing%')>1;

--Q7:
select eid from employes where salaire=(select max(salaire) from employes where salaire<(select max(salaire) from employes));


--Q8:
select enom
from employes natural join certifications natural join avions 
where portee>2000 group by enom having every(anom not like 'Boeing%')=true;


--Q9:
select enom,salaire from employes e where enom not in(select enom from employes natural join certifications natural join avions) and e.salaire>(select avg(salaire) from employes natural join certifications natural join avions);

--Q10:
select avg(e.salaire)-avg(e1.salaire) as difference from employes e natural join certifications natural join avions ,employes e1;


--Q11:
select h_dep from vols where dep='Madison' and h_arr < '2016-04-12 18:00' and (arr='New York' or arr in(
select v.arr from vols v where v.dep='Madison' and v.arr in(select v1.dep from vols v1 where v1.arr='New York')));


--Q12:
-- On trouve pas l'aeroport Timbuktu dans la base de donnees fournit


