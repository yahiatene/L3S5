
schema([a,b,c,d,e,h]).

f([ [[a],[c]], [[a,c],[d]], [[e],[a,d]],[[e],[h]] ]).

g([ [[a],[c,d]],[[e],[a,h]] ]).



%% ?- ['dbd.pl'].
%% true.
%% ?- ['exo1.pl'].
%% true.

%% ?- schema(R), f(F1), g(F2), equiv(R,F1,F2).
%% R = [a, b, c, d, e, h],
%% F1 = [[[a], [c]], [[a, c], [d]], [[e], [a, d]], [[e], [h]]],
%% F2 = [[[a], [c, d]], [[e], [a, h]]] ;
%% false.

