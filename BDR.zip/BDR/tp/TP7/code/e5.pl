schema([a,b,c]).
fds([[[a],[b,c]], [[b],[a]]]).
