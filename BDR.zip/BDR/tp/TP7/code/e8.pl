schema([a,b,c,d]).

fds([[[a,b],[c]],[[b],[d]],[[b,c],[a]]]).
