r7([courseno,secno,offeringdept,credithours,courselevel,instructorssn,semester,year, dayshours,roomno,noofstudents]).

f7([ [[courseno],[offeringdept,credithours,courselevel]], [[courseno,secno,semester,year],[dayshours,roomno,noofstudents,instructorssn]], [[roomno,dayshours,semester,year],[instructorssn,courseno,secno]]]).
