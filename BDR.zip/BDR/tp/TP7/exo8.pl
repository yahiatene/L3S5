lots([propertyid,countyname,lotno,area,price,taxrate]).
f8([[[propertyid],[countyname,lotno,area,price,taxrate]], [[countyname,lotno],[propertyid,area,price,taxrate]], [[countyname],[taxrate]],[[area],[price]]]).

lots1ax([propertyis,area,lotno]).
lots1ay([area,countyname]).
lots1b([area,price]).
lots2([countyname,taxrate]).
