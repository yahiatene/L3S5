%% ?- emp_dept(R),p(F),mincover(R,F,MinF).
%% R = [ename, ssn, bdate, address, dnumber, dname, dmgrssn],
%% F = [[[ssn], [ename, bdate, address, dnumber]], [[dnumber], [dname, dmgrssn]]],
%% MinF = [[[dnumber], [dmgrssn, dname]], [[ssn], [address, bdate, dnumber, ename]]] 
