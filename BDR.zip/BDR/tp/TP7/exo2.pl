emp_dept([ename,ssn,bdate,address,dnumber,dname,dmgrssn]).

p([ [[ssn],[ename,bdate,address,dnumber]],[[dnumber],[dname,dmgrssn]] ]).


%% Calculate the closures {ssn} + and {dnumber}+.

%% ?- ['exo2.pl'].
%% true.

%% ?- emp_dept(R), p(F),xplus(R,F,[ssn],Xplus).
%% R = [ename, ssn, bdate, address, dnumber, dname, dmgrssn],
%% F = [[[ssn], [ename, bdate, address, dnumber]], [[dnumber], [dname, dmgrssn]]],
%% Xplus = [address, bdate, dmgrssn, dname, dnumber, ename, ssn].



%% ?- emp_dept(R), p(F),xplus(R,F,[dnumber],Xplus).
%% R = [ename, ssn, bdate, address, dnumber, dname, dmgrssn],
%% F = [[[ssn], [ename, bdate, address, dnumber]], [[dnumber], [dname, dmgrssn]]],
%% Xplus = [dmgrssn, dname, dnumber].

