--Auteurs-:YAHIATENE Mohamed
----------:BENKHIDER Zinedine


---Q1:
select aid,acoul from articles a1 where not exists(select aid,acoul from articles a2 where a1.aid != a2.aid and a1.acoul=a2.acoul);


---Q2:
---avec NOT EXISTS:
select anom from articles a1 where a1.acoul='rouge' and not exists(select anom from articles a2 where a1.anom=a2.anom and a2.acoul='vert');

---avec NOT IN:
select anom from articles a1 where a1.acoul='rouge' and a1.anom not in(select anom from articles a2 where a1.anom=a2.anom and a2.acoul='vert');


---avec ALL:
select anom from articles a1 where a1.acoul='rouge' and a1.anom <> all(select anom from articles a2 where a1.anom=a2.anom and a2.acoul='vert');


---Q3:
select fnom from fournisseurs natural join catalogue natural join articles group by fid having avg(prix)>=all(select avg(prix) from catalogue);


---Q4:
select aid,anom from articles natural join fournisseurs  natural join catalogue c1 where exists(select aid,anom from articles natural join fournisseurs natural join catalogue c2 where c1.fid!=c2.fid and c1.aid=c2.aid) group by aid

---Q5:
avec NOT IN:
select fid,fnom from fournisseurs where fid not in (select fid from catalogue);

---avec ALL:
select fid,fnom from fournisseurs where fid <> all (select fid from catalogue);


---Q6:
select a.anom,c.aid from articles a, catalogue c,fournisseurs f where f.fnom='kiventout' and c.fid = f.fid and a.aid=c.aid and not exists(select aid from catalogue c2 where c2.fid<>c.fid and c2.aid=c.aid);


---Q7:
---on l'a fait avec un groupage pour compter !!! on a reflichi a une autre methode mais sans succes!
select fnom,fid,count(aid) as NB_ARTICLES from fournisseurs natural join catalogue group by fid having count(aid)>12;


---Q8:
select f.fnom from fournisseurs f , catalogue c
where f.fid=c.fid and not exists(select c2.prix from catalogue c2 where c2.prix>c.prix);


---Q9:
select a.anom , min(prix) , max(prix) from articles a natural join catalogue c where exists(select a2.anom from articles a2 natural join catalogue c2 where a2.anom=a.anom and c2.fid<>c.fid)group by a.anom;


---Q10:
select distinct f.fnom, a.anom from fournisseurs f, articles a ,catalogue c 
where c.fid=f.fid and c.aid=a.aid and exists(
select f2.fnom, a2.anom from fournisseurs f2, articles a2 ,catalogue c2 where
f2.fid=f.fid and c.fid=c2.fid and a2.anom=a.anom and c2.aid=a2.aid and a2.aid<>a.aid);




---Q11:
---not exists:

select distinct a.anom from articles a,catalogue c where not exists(
select a2.anom from articles a2,catalogue c2 where a2.anom=a.anom and c2.aid=a2.aid and c2.fid<>c.fid);


---group by:

select a.anom from articles a natural join catalogue c
group by a.anom
having count(c.fid)=1;



---Q12:

---not exists:

select distinct c.aid from catalogue c where prix >='100' and not exists(
select c2.aid from catalogue c2 where c2.aid=c.aid and c2.fid<>c.fid and prix <'100');

---all:

select distinct c.aid from catalogue c where prix >='100' and c.aid <> all(
select c2.aid from catalogue c2 where c2.aid=c.aid and c2.fid<>c.fid and prix <'100');


---Q13:
select distinct c.aid from catalogue c , fournisseurs f where c.fid=f.fid and f.fad like '%USA';


---Q14:

select distinct c.fid,f.fnom from fournisseurs f natural join articles a natural join catalogue c where
a.acoul='rouge' and c.fid not in(select distinct c2.fid from fournisseurs f2 natural join articles a2 natural join catalogue c2 where a2.acoul<>'rouge');
