-- TP5: COMPAGNIE AERIENNE
-- correction
------------------------------------------------------



-- Q1---- 
SELECT C.eid, MAX (A.portee) 
FROM certifications C, avions A 
WHERE C.aid = A.aid
GROUP BY C.eid 
HAVING	(COUNT (*) >= 2);

--- alternative, group by 

select c.eid, a.portee
FROM certifications c natural join avions a
where 
-- ce pilote est certifié pour (au moins) un autre avion
exists (select * from certifications c2 where c2.eid = c.eid and c2.aid <> a.aid)
and 
not exists (
--- l'avion en haut a la portee maximale (relativement a ce pilote),
--- autrement dit, ce pilote n'est pas certifié pour un avion de portée supérieure
select * from certifications c2 natural join avions a2 where c2.eid = c.eid and a2.portee > a.portee
);

-----------------------------------------------------
-- Q2

   SELECT DISTINCT E.enom 
   FROM employes  E
   WHERE E.salaire <	 
 ( 
	SELECT MIN (V.prix) 
FROM Vols V
WHERE V.dep = 'CDG' 
AND  V.arr = 'NOU' 
);

---- alternative 1
select e.enom
from employes e
where e.salaire < ALL
(
	select prix from vols v
	where v.dep='CDG' and v.arr='NOU'
);

----- alternative 2
select e.enom
from employes e
where not exists
(
	select prix
	from vols v
	where v.prix<e.salaire and v.dep='CDG' and v.arr='NOU'
);



--- Q3
---Quelles routes (départ et destination) 
---peuvent \^etre volées par tous les pilotes
---gagnant plus de 100 000 euros?


select v.dep, v.arr,v.distance from vols v 
where v.distance <= ALL (
  select max (a.portee) from employes e, certifications c, avions a
  where c.eid=e.eid and c.aid=a.aid and e.salaire>=100000
  group by e.eid);



---- alternative

select v.dep, v.arr,v.distance
from vols v 
where not exists
-- il n'y a pas de pilote...
 (select e.eid
 from employes e,certifications c, avions a
 where c.eid=e.eid and c.aid=a.aid and e.salaire>=100000
 group by e.eid 
 having v.distance > max(a.portee)
 )
;

--- version la plus proche a TRC

select v.dep, v.arr,v.distance
from vols v
where not exists
(select * from employes e, certifications c
	where e.eid=c.eid and e.salaire >=100000
	and not exists (
	select * 
	from avions a, certifications c2
	where a.aid=c2.aid and c2.eid=e.eid and a.portee>=v.distance
	)
);


--- Q4
SELECT E.enom
FROM Employes E, Certifications C, Avions A 
WHERE C.aid = A.aid AND E.eid = C.eid 
GROUP BY E.eid,  E.enom
HAVING EVERY (A.portee > 1500) 
order by E.enom;


SELECT E.enom
FROM Employes E, Certifications C, Avions A 
WHERE C.aid = A.aid AND E.eid = C.eid 
GROUP BY E.eid,  E.enom
HAVING min(A.portee) > 1500 
order by E.enom;


select distinct e.enom
from employes e, certifications c
where c.eid=e.eid 
and not exists 
(select * from certifications c2, avions a2
where c2.eid=e.eid and  a2.aid=c2.aid and a2.portee<=1500
);




---Q5
SELECT E.enom
FROM Employes E, Certifications C, Avions A 
WHERE C.aid = A.aid AND E.eid = C.eid 
GROUP BY E.eid,  E.enom
HAVING EVERY (A.portee > 1500) AND COUNT (*) >= 2;

----- alternative
select distinct e.enom
from employes e, certifications c, avions a
where 
--- pilote d'un (premier) avion de portee >1500
e.eid=c.eid and c.aid=a.aid and a.portee > 1500
and exists (--- CE pilote est egalement pilote d'un SECOND avion de portee > 1500
		select * from certifications c2 natural join avions a2
		and a2.aid<>a.aid and c2.eid=e.eid 
		and a2.portee>1500
---		and exists (  -- si on voulait ajouter un troisieme avion...
---			select * 
---			from certifications c3 natural join avions a3
---			where a3.aid<>a.aid 
---			and c3.eid=e.eid 
---			and a3.portee>1500
---			)
			)	    
and not exists (
---- il est egalement pilote de TOUS les avions de portee >1500
      		select * from certifications c natural join avions a 
		where c.eid=e.eid 
		and a.portee<=1500
      );



---Q6

SELECT  E.enom
FROM Employes E, Certifications C, Avions A 
WHERE C.aid = A.aid AND E.eid = C.eid 
GROUP BY E.eid, E.enom
HAVING EVERY (A.portee > 1500) AND bool_or (A.anom like 'Boeing%');

---EVERY: equivalent a bool_and



-- Q7 
--- employe avec le salaire le deuxieme plus haut.

select E.enom, E.eid
from employes e
where 
salaire=
	(select max(salaire) 
	from employes 
	where salaire<>(select max(salaire) from employes)
);


--Q8 
-- Affichez les noms des pilotes qui peuvent piloter des avions d’une port ́ee sup ́erieure `a 2000km, 
--mais qui ne sont certifi ́es pour aucun Boeing.

-v1
select distinct E.eid, E.enom 
from employes E
where 
	E.eid in (
			select eid 
	      	    	from certifications c, avions a 
			where a.aid=c.aid and a.portee>2000)
and 
    E.eid not in 
       (
       select eid 
       from certifications c, avions a 
       where a.aid=c.aid and a.anom like 'Boeing%'
       )
;
-- 7 lignes

-----------------
select distinct E.eid, E.enom 
from employes E
where exists
	 (
			select * 
	      	    	from certifications c, avions a 
			where a.aid=c.aid and a.portee>2000 and c.eid=E.eid)
and not exists
       (
       select *
       from certifications c, avions a 
       where a.aid=c.aid and a.anom like 'Boeing%' and c.eid=E.eid
       )
;
-- 7 rows




-----------et en simple
-- 7 lignes

select distinct E.eid, E.enom 
from employes E, certifications c,avions A
where 
      e.eid=c.eid and c.aid=a.aid 
group by E.eid, E.enom
having   bool_and(a.anom not like 'Boeing%') and bool_or(a.portee>2000);


-- v3---- buggy!
---interesting to explain why. :)
select distinct e.eid, e.enom 
from employes e, certifications c
where  c.eid=e.eid  
and    c.aid not in 
       (
       select  a2.aid 
       from  avions a2 
       where a2.anom like 'Boeing%'
       )
and c.aid in
(select aid
from  avions 
where portee>2000)
;


--- same result as with 
-- having   bool_and(a.anom not like 'Boeing% and a.portee>2000);

--- Q9

---- BUG: dans la moyennes, les revenu des pilotes sont pris en compte aussi 
----souvent qu'ils ont des certifications (5x pour 5 certifications)
-----------
-- SELECT E.enom, E.salaire
-- FROM employes E
-- WHERE 
-- E.eid NOT IN      
--       (SELECT  C.eid FROM Certifications C) ---- les pilotes
-- AND 
-- E.salaire > 
-- 	 (SELECT AVG (E1.salaire)
-- 	 FROM employes E1, certifications c1
--          where e1.eid=c1.eid
-- )       
-- ;
---

SELECT E.enom, E.salaire
FROM employes E
WHERE 
E.eid NOT IN      
      (SELECT  C.eid FROM Certifications C) ---- les pilotes
AND 
E.salaire > 
	 (SELECT AVG (salaire)
	 FROM employes where eid in (select eid from certifications)
)       
;



--- Q10-----------------------------------

SELECT RevPilotes.avg - RevEmployes.avg as difference
FROM 
(
	SELECT AVG(E.salaire) AS avg
	FROM employes E
	WHERE E.eid in 
	      (SELECT DISTINCT C.eid FROM Certifications C)
) 
AS RevPilotes,
(
	SELECT AVG(E1.salaire) AS avg
	FROM employes E1
) 
AS RevEmployes;


-----------------------------

CREATE VIEW RevPilotes(avg) as 
	SELECT AVG(E.salaire) 
	FROM employes E
	WHERE E.eid in 
	      (SELECT DISTINCT C.eid FROM Certifications C);

CREATE VIEW RevEmployes(avg) as
SELECT AVG(E1.salaire) 
	FROM employes E1;

create R1.avg - R2.avg as difference
from RevPilotes as R1, RevEmployes as R2;


----Q11 ------ 
-- vol NY->Madison, max 2 escales, arrivee avant 18h.
-----

SELECT F.h_dep, F.vid
FROM
Vols F
WHERE F.vid IN 
( ( 
    SELECT F0.vid
    FROM Vols F0
    WHERE F0.dep = 'Madison' AND F0.arr = 'New York'
    AND extract(hour from  F0.h_arr) < 18 
      )
UNION
	(SELECT F0.vid
	FROM Vols F0, Vols F1
	WHERE F0.dep = 'Madison' AND F0.arr <> 'New York'
	AND F0.arr = F1.dep AND F1.arr = 'New York'
	AND F1.h_dep > F0.h_arr
	AND extract(hour from  F1.h_arr) < 18 )
UNION
	( SELECT F0.vid
	FROM Vols F0, Vols F1, Vols F2
	WHERE F0.dep = 'Madison'
	AND F0.arr = F1.dep
	AND F1.arr = F2.dep
	AND F2.arr = 'New York'
	AND F0.arr <> 'New York'
	AND F1.arr <> 'New York'
	AND F1.h_dep > F0.h_arr
	AND F2.h_dep > F1.h_arr
	AND extract(hour from  F2.h_arr) < 18 
	)
)
;


