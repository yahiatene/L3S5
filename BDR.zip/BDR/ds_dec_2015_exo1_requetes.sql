-- DS BDR 2015, Exo 1

--------
-- Q1.1
--- pour chaque âge d'étudiant, déterminez le niveau d'études le plus fréquent.
CREATE VIEW stat(age,niveau,nb) AS
select age,niveau, count(*)
from etudiants
group by age, niveau;

select age, niveau
from stat s
where nb = (select max(nb) from stat s2 where s2.age=s.age);

age |  niveau   
-----+-----------
  18 | Licence 1
  22 | Master 1
  17 | Licence 1
  19 | Licence 2
  21 | Master 1
  20 | Licence 3
(6 rows)
---
-- alternative avec meme resultat

select age,niveau
from etudiants as e
group by age,niveau
having count(*)>=ALL (
select count(*) from etudiants as e2 where e2.age=e.age group by niveau
);


--------
-- Q1.2
-- Trouver le nom de l'étudiant le plus jeune suivant un enseignement de I.Boulala le mercredi.

CREATE VIEW etud(eid,enom,age)
as (
select e_id, e_nom, age
from 
     etudiants natural join 
     participer natural join 
     cours natural join profs	    
where
prof_nom = 'I. Boulala' and horaire LIKE '%Me%'
);

select enom
from etud 
where age <= ALL (select age from etud);

--------
-- Q1.3
-- sans utiliser l'opérateur COUNT, trouver les noms de profs donnant cours dans l'ensemble des salles où ont lieu des enseignements.

 select prof_nom, prof_id
 from profs p
 where not exists (
      select * 
      from cours c1
      where not exists (
      	    select * 
	    from cours c2 
	    where c1.salle=c2.salle and c2.prof_id = p.prof_id
)
);


--- "le prof tel qu'il n'existe pas de salle d'enseignement ou il n'enseigne pas"
- tester sur la base complete (pas seulement l'extrait sur le sujet).

- le resultat attendu est vide. raison:

- il y a 8 salles differentes utilisees pour des cours.
   select count(distinct salle) from cours;

- le prof enseignant dans le max de salles le fait dans 6 
  select prof_id, count(distinct salle) from cours group by prof_id;


-------
-- Q1.4
-- Pour chaque prof ayant uniquement enseigné en salle R128, affichez le nom de cet enseignant et le nombre total de cours qu'il a enseigné.

select prof_nom, count(*)
from profs natural join cours
group by prof_id, prof_nom
having EVERY(salle='R128');

---Q1.5
q15(ENOM):- etudiants(EID,ENOM,_,_,_),
cours(EID,C1,H,_,_),participer(EID,C1),
cours(EID,C2,H,_,_),participer(EID,C2),
C1\=C2.
q15(X).
--0Q1.6
project[titre](
project[c_id,titre](cours)
MINUS
project[c_id,titre](
select[age<=19](cours JOIN participer JOIN etudiants))
)
--- Q1.7
soit version avec "pour tous"
soit version disant "les cours tel qu’il n’existe pas
d’etudiants de plus de 19 ans qui ne suivent pas ce cours"


{t| exists c in cours: c[titre]=t[titre] and
forall e in etudiants: e[age]>19 implies 
(exists p in participer:
e[eid]=p[eid] and c[c_id]=p[c_id]
 )
}
