schema([a,b,c,d,e]).

fds([[[a,b],[c]],[[c,d],[e]],[[d,e],[b]]]).


%*********************************************************

% [a,b] n'est pas une clé candidate
 
% ?- schema(R), fds(F), candkey(R,F,[a,b]).
% false.

% [a,b,d] est une clé candidate

% ?- schema(R), fds(F), candkey(R,F,[a,b,d]).
% R = [a, b, c, d, e],
% F = [[[a, b], [c]], [[c, d], [e]], [[d, e], [b]]]
