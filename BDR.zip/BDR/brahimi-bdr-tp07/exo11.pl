schema([a,b,c,d,e,f,g,h,i,j]).

fds([[[a,b],[c]],[[a],[d,e]],[[b],[f]],[[f],[g,h]],[[d],[i,j]]]).

fds1([[[a,b],[c]],[[b,d],[e,f]],[[b],[f]],[[f],[g,h]],[[d],[i,j]]]).


%***********************************************************************


% ?- schema(R), fds(F), bcnf(R,F,D).
% Scheme to decompose = [a,b,c,d,e,f,g,h,i,j] Offending FD: [a]-->[d,e,i,j]
% Scheme to decompose = [a,b,c,f,g,h] Offending FD: [a,c,f]-->[g,h]
% Scheme to decompose = [a,b,c,f] Offending FD: [b]-->[f]
% Final Result is:
% [a,b,c]
% [a,d,e,i,j]
% [a,c,f,g,h]
% [b,f]

% R = [a, b, c, d, e, f, g, h, i|...],
% F = [[[a, b], [c]], [[a], [d, e]], [[b], [f]], [[f], [g, h]], [[d], [i, j]]],
% D = [[a, b, c], [a, d, e, i, j], [a, c, f, g, h], [b, f]] .


%*****************************************************************

% ?- schema(R), fds(G), bcnf(G,F,D).
% Final Result is:
% [[[a,b],[c]],[[a],[d,e]],[[b],[f]],[[f],[g,h]],[[d],[i,j]]]

% R = [a, b, c, d, e, f, g, h, i|...],
% G = [[[a, b], [c]], [[a], [d, e]], [[b], [f]], [[f], [g, h]], [[d], [i, j]]],
% D = [[[[a, b], [c]], [[a], [d, e]], [[b], [f]], [[f], [g, h]], [[d], [i|...]]]] .
