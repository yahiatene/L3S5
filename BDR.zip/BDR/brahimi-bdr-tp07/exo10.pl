schema([a,b,c,d,e,f,g,h,i,j]).

fds([[[a,b],[c]],[[b,d],[e,f]],[[b],[f]],[[f],[g,h]],[[d],[i,j]]]).

%**************************************************************************


% clé candidate:

% ?- schema(G), fds(F), candkey(G,F,K).
% G = [a, b, c, d, e, f, g, h, i|...],
% F = [[[a, b], [c]], [[b, d], [e, f]], [[b], [f]], [[f], [g, h]], [[d], [i, j]]],
% K = [a, b, d]



% mincover:

% ?- schema(G),fds(F),mincover(G,F,MinG).
% G = [a, b, c, d, e, f, g, h, i|...],
% F = [[[a, b], [c]], [[b, d], [e, f]], [[b], [f]], [[f], [g, h]], [[d], [i, j]]],
% MinG = [[[a, b], [c]], [[b], [f]], [[b, d], [e]], [[d], [i, j]], [[f], [g, h]]] .



% 3NF:

% ?- schema(G), fds(F), threenf(G,F,G3NF).
% G = [a, b, c, d, e, f, g, h, i|...],
% F = [[[a, b], [c]], [[b, d], [e, f]], [[b], [f]], [[f], [g, h]], [[d], [i, j]]],
% G3NF = [[a, b, c], [b, f], [b, d, e], [d, i, j], [f, g, h], [a, b, d]] .






