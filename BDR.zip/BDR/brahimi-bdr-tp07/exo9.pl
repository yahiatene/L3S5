schema([a,b,c,d,e,f,g,h,i,j]).

fds([[[a,b],[c]],[[a],[d,e]],[[b],[f]],[[f],[g,h]],[[d],[i,j]]]).

%***************************************************************



% clé candidate:

% ?- schema(R), fds(F), candkey(R,F,K).
% R = [a, b, c, d, e, f, g, h, i|...],
% F = [[[a, b], [c]], [[a], [d, e]], [[b], [f]], [[f], [g, h]], [[d], [i, j]]],
% K = [a, b]



% mincover:

% ?- schema(R),fds(F),mincover(R,F,MinF).
% R = [a, b, c, d, e, f, g, h, i|...],
% F = [[[a, b], [c]], [[a], [d, e]], [[b], [f]], [[f], [g, h]], [[d], [i, j]]],
% MinF = [[[a], [d, e]], [[a, b], [c]], [[b], [f]], [[d], [i, j]], [[f], [g, h]]]



% 3NF:

% ?- schema(R), fds(F), threenf(R,F,R3NF).
% R = [a, b, c, d, e, f, g, h, i|...],
% F = [[[a, b], [c]], [[a], [d, e]], [[b], [f]], [[f], [g, h]], [[d], [i, j]]],
% R3NF = [[a, d, e], [a, b, c], [b, f], [d, i, j], [f, g, h]]




