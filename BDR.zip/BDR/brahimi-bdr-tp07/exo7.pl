schema([courseno,secno,offeringdept,credithours,courselevel,instructorssn,semester,year, Dayshours,roomno,noofstudents]).

fds([[[courseno],[offeringdept,credithours,courselevel]],[[courseno,secno,semester,year],[dayshours,roomno,noofstudents,instructorssn]],[[roomno,dayshours,semester,year],[instructorssn,courseno,secno]]]).


%*************************************************************

% elle n'a pas de clé candidate.

%  ?- schema(R), fds(F), candkey(R,F,K).
% false.


% 3NF:

?-  schema(R), fds(F), threenf(R,F,R3NF).
% R = [courseno, secno, offeringdept, credithours, courselevel, instructorssn, semester, year, courselevel|...],
% F = [[[courseno], [offeringdept, credithours, courselevel]], [[courseno, secno, semester, year], [dayshours, roomno, noofstudents, instructorssn]], [[roomno, dayshours, semester, year], [instructorssn,courseno, secno]]],
% R3NF = [[courseno, courselevel, credithours, offeringdept], [courseno, secno, semester, year, dayshours, noofstudents, roomno], [roomno, dayshours, semester, year, courseno, instructorssn|...]]

