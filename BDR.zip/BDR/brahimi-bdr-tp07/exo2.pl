schema([ename,ssn,bdate,address,dnumber,dname,dmgrssn]).

fds([[[ssn],[ename, bdate, address, dnumber]],[[dnumber],[dname, dmgrssn]]]).


%*****************************************************
% the closures {ssn}

% ?- schema(EMP_DEPT),fds(G),xplus(EMP_DEPT,G,[ssn],Xplus).
% EMP_DEPT = [ename, ssn, bdate, address, dnumber, dname, dmgrssn],
% G = [[[ssn], [ename, bdate, address, dnumber]], [[dnumber], [dname, dmgrssn]]],
% Xplus = [address, bdate, dmgrssn, dname, dnumber, ename, ssn].


% the closures {ssn}

% ?- schema(EMP_DEPT),fds(G),xplus(EMP_DEPT,G,[dnumber],Xplus).
% EMP_DEPT = [ename, ssn, bdate, address, dnumber, dname, dmgrssn],
% G = [[[ssn], [ename, bdate, address, dnumber]], [[dnumber], [dname, dmgrssn]]],
% Xplus = [dmgrssn, dname, dnumber].


