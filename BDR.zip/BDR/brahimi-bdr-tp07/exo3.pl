schema([ename,ssn,bdate,address,dnumber,dname,dmgrssn]).

fds([[[ssn],[ename, bdate, address, dnumber]],[[dnumber],[dname, dmgrssn]]]).

%*************************************************************
% oui G est le mincover car G= MinG.


% ?- schema(R),fds(G),mincover(R,G,MinG).
% R = [ename, ssn, bdate, address, dnumber, dname, dmgrssn],
% G = [[[ssn], [ename, bdate, address, dnumber]], [[dnumber], [dname, dmgrssn]]],
% MinG = [[[dnumber], [dmgrssn, dname]], [[ssn], [address, bdate, dnumber, ename]]]
