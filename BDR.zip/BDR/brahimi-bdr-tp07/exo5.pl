schema([a,b,c,d,e,f,g,h,i,j]).

fds([[[a,b],[c]],[[b,d],[e,f]],[[b],[f]],[[f],[g,h]],[[d],[i,j]]]).


%**************************************************************


% La cle:

% ?- schema(R), fds(F), candkey(R,F,K).
% R = [a, b, c, d, e, f, g, h, i|...],
% F = [[[a, b], [c]], [[b, d], [e, f]], [[b], [f]], [[f], [g, h]], [[d], [i, j]]],
% K = [a, b, d] .


% 3NF:

% ?- schema(R), fds(F), threenf(R,F,R3NF).
% R = [a, b, c, d, e, f, g, h, i|...],
% F = [[[a, b], [c]], [[b, d], [e, f]], [[b], [f]], [[f], [g, h]], [[d], [i, j]]],
% R3NF = [[a, b, c], [b, f], [b, d, e], [d, i, j], [f, g, h], [a, b, d]]
