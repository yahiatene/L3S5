schema([a,b,c,d,e]).


fds([[[a,b],[c]],[[c,d],[e]],[[d,e],[b]]]).




%***************************************************

% clé candidate:


% ?- schema(R), fds(F), candkey(R,F,K).
% R = [a, b, c, d, e],
% F = [[[a, b], [c]], [[c, d], [e]], [[d, e], [b]]],
% K = [a, d, e]



% 3NF:

% ?- schema(R), fds(F), threenf(R,F,R3NF).
% R = [a, b, c, d, e],
% F = [[[a, b], [c]], [[c, d], [e]], [[d, e], [b]]],
% R3NF = [[a, b, c], [c, d, e], [d, e, b], [a, d, e]]


% BCNF:

% ?- schema(R), fds(F), bcnf(R,F,D).
% Scheme to decompose = [a,b,c,d,e] Offending FD: [a,b]-->[c]
% Scheme to decompose = [a,b,d,e] Offending FD: [d,e]-->[b]
% Final Result is:
% [a,d,e]
% [a,b,c]
% [d,e,b]

% R = [a, b, c, d, e],
% F = [[[a, b], [c]], [[c, d], [e]], [[d, e], [b]]],
% D = [[a, d, e], [a, b, c], [d, e, b]]
