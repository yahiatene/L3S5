schema([m,y,p,mp,c]).

fds([[[m],[mp]],[[m,y],[p]],[[mp],[c]]]).

decomp([[m,y,p],[m,mp,c]]).
decomp1([m,y,p]).
decomp2([m,mp,c]).



%************************************ IV ****************************

% [m] n'est pas une clé candidate

% ?- schema(R), fds(F), candkey(R,F,[m]).
% false.

% [m,y] est une clé candidate

% ?- schema(R), fds(F), candkey(R,F,[m,y]).
% R = [m, y, p, mp, c],
% F = [[[m], [mp]], [[m, y], [p]], [[mp], [c]]] .

% [m,c] n'est pas une clé candidate

% ?- schema(R), fds(F), candkey(R,F,[m,c]).
% false.

%********************************* V **********************************

% is3NF:

% ?- schema(R), fds(F), is3NF(R,F).
% false.


%isbcnf

% ?- schema(R), fds(F), bcnf(R,F,D).
% Scheme to decompose = [m,y,p,mp,c] Offending FD: [m]-->[c,mp]
% Final Result is:
% [m,y,p]
% [m,c,mp]

% R = [m, y, p, mp, c],
% F = [[[m], [mp]], [[m, y], [p]], [[mp], [c]]],
% D = [[m, y, p], [m, c, mp]] .


%************************ VI *********************


% ?- schema(R),fds(R),decomp1(D1),decomp2(D2),ljd(R,F,D1,D2).
% false.