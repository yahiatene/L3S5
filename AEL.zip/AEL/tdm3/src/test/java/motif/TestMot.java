package motif;
import motif.Mot;

import static org.junit.Assert.*;

import org.junit.Test;


public class TestMot {

	@Test
	public void testIndiceMotifKMP() {
		Mot mot=new Mot("bacbababaabcbab");
		Mot motif=new Mot("cb");
		assertEquals(mot.indiceMotifKMP(motif),2);
		Mot motif2=new Mot("abcd");
		assertEquals(mot.indiceMotifKMP(motif2),-1);
		Mot motif3=new Mot("");
		assertEquals(mot.indiceMotifKMP(motif3),0);
		Mot motif5=new Mot("bacbababaabcbab");
		assertEquals(mot.indiceMotifKMP(motif5),-1);
		
	}

}
