# RENDU DU TDM2:

# -YAHIATENE MOHAMED
# -SENECHAL AXEL


-Le Makefile fonctionne comme demandé.
-On n'a pas réussis à continuer la suite des exercices,on s'est arretés à la question 1 de l'exercice 2.
