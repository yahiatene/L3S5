# Rendu du tdm8 en AEL
# YAHIATENE Moahmed
# BENKHIDER Zinedine

* le travail demandé est fait.

* exemple d'execution de testARD:
***
mot ? > ab
OK
mot ? > ab2
OK
mot ? > ababaaaaa
OK
mot ? > fddggfd
Erreur : variable S, token f: no rule
mot ? > (ab)2ab
OK
mot ? > 
***
