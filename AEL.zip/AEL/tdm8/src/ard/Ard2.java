package ard;



import condenses_lex.TokenType;

import condenses_lex.*;

public class Ard2 extends AbstractArd2 {

	public Ard2(Tokenizer in) {
		super(in);
	}

	private void S() throws SyntaxExceptionex2, ParserException {
		switch (current.getType()) {
		case LETTRE:
		case OUVRANTE:
			E();
			R();
			S();
			break;
		case FERMANTE:
		case EOD:
			break;
		default:
			throw new SyntaxExceptionex2(ErrorType.NO_RULE,current);
		}
	}

	private void E() throws SyntaxExceptionex2, ParserException {
		switch (current.getType()) {
		case LETTRE:
			eat(TokenType.LETTRE);
			break;
		case OUVRANTE:
			eat(TokenType.OUVRANTE);
			S();
			eat(TokenType.FERMANTE);
			break;
		default:
			throw new SyntaxExceptionex2(ErrorType.NO_RULE,current);
		}
	}

	private void R() throws SyntaxExceptionex2, ParserException {
		switch (current.getType()) {
		case ENTIER:
			eat(TokenType.ENTIER);
			break;
		case LETTRE:
		case OUVRANTE:
		case FERMANTE:
		case EOD:
			break;
		default:
			throw new SyntaxExceptionex2(ErrorType.NO_RULE,current);
		}
	}

	@Override
	protected void axiom() throws SyntaxExceptionex2, ParserException {
	  S();	
	}
	

}
