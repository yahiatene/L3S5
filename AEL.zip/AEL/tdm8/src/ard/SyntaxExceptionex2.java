package ard;


import ard.ErrorType;
import condenses_lex.Yytoken;

@SuppressWarnings("serial")
public class SyntaxExceptionex2 extends Exception {

	public SyntaxExceptionex2() {
	}
	
	static protected String prepareMessage(ErrorType error, Yytoken current, Yytoken expected){
		switch (error){
		case NO_RULE :
			return "variable "+ Thread.currentThread().getStackTrace()[4].getMethodName() + ", token " + current+ ": no rule";
		case UNMATCHING_CHAR :
			return "found : " + current + ", expected : " + expected;
		default :
			return null;
		}
	}
	static protected String prepareMessage(ErrorType error, Yytoken current){
		return prepareMessage(error,current,null);
	}
	
	public SyntaxExceptionex2(ErrorType error, Yytoken current) {
		this (prepareMessage(error,current)); 
	}
	public SyntaxExceptionex2(ErrorType error, Yytoken current, Yytoken expected) {
		this (prepareMessage(error,current,expected)); 
	}

	public SyntaxExceptionex2(String message) {
		super(message);
	}

	public SyntaxExceptionex2(Throwable cause) {
		super(cause);
	}

	public SyntaxExceptionex2(String message, Throwable cause) {
		super(message, cause);
	}

	public SyntaxExceptionex2(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
