package ard;

import java.io.Reader;

public class AnalyseSimple extends Ard{
	public AnalyseSimple(Reader in) {
		super(in);
	
	}
	private void S() throws SyntaxException, ParserException {
		switch (current) {
		case '(':
			E();
			R();
			S();
			break;
		
		case 'a':
			E();
			R();
			S();
			break;
		case 'b':
			E();
			R();
			S();
			break;
		case 'c':
			E();
			R();
			S();
			break;
		case END_MARKER:
			break;
		case ')':
			break;
	
			
		default:
			// erreur
//			String myName = Thread.currentThread().getStackTrace()[1].getMethodName();
//			throw new ParserException("No rule for variable "+ myName + " token " + current+ "	."); 
			throw new SyntaxException(ErrorType.NO_RULE,current);
		}
	}

	private void R() throws SyntaxException, ParserException {
		
		switch (current) {
		case '0':
			C();
			break;
		case '1':
			C();
			break;
		case '2':
			C();
			break;
		case '3':
			C();
			break;
		case '4':
			C();
			break;
		case '5':
			C();
			break;
		case '6':
			C();
			break;
		case '7':
			C();
			break;
		case '8':
			C();
			break;
		case '9':
			C();
			break;
		case 'a':
			break;
		case 'b':	
			break;
		case 'c':
			break;
		case '(':
			break;
		case ')':
			break;
		case END_MARKER:
			break;
			
		default:
			throw new SyntaxException(ErrorType.NO_RULE,current);
		}
	}

	private void C() throws SyntaxException, ParserException {

		switch (current) {
		
		case '0':
			eat('0');
			break;
		case '1':
			eat('1');
			break;
		case '2':
		
			eat('2');
			break;
		case '3':
			
			eat('3');
			break;
		case '4':
			
			eat('4');
			break;
		case '5':
		
			eat('5');
			break;
		case '6':
		
			eat('6');
			break;
		case '7':
			// B -> bB
			eat('7');
			break;
		case '8':
			
			eat('8');
			break;
		case '9':
			
			eat('9');
			break;
		
		default:
			throw new SyntaxException(ErrorType.NO_RULE,current);
		}
	}

	private void L() throws SyntaxException, ParserException {
		switch (current) {
		case 'a':
			eat('a');
			break;
		case 'b':
			eat('b');
			break;
		case 'c':
			eat('c');
			break;
		default:
			throw new SyntaxException(ErrorType.NO_RULE,current);
		}
	}
	private void E() throws SyntaxException, ParserException {
		switch (current) {
		case 'a':
			L();
			break;
		case 'b':
			L();
			break;
		case 'c':
			L();
			break;
		case '(':
			eat('(');
			S();
			eat(')');
			break;	
		default:
			throw new SyntaxException(ErrorType.NO_RULE,current);
		}
	}
	
	protected void axiom() throws SyntaxException, ParserException {
		S();
		
	}

}
