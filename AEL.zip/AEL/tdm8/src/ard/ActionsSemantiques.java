package ard;



import java.io.Reader;
import java.io.StringReader;
import java.util.Scanner;

public class ActionsSemantiques extends Ard {
	String e="";
	String c="";
	String k = "";
	String g = "";
	public ActionsSemantiques(Reader in) {
		super(in);
		
	}
	private String S() throws SyntaxException, ParserException {
		switch(current){
		case 'a':
		case 'b':
		case 'c':
		case '(':
			String e =E();
			int r =R();
			String s =S();
			String retour="";
			if(e!=null){
				if(r==-1){
					retour=retour+e;
				}
				else{
					for(int i=0;i<r;i++){
						retour=retour+e;
					}
				}
			}
			if(s!=null){
				retour=retour+s;
			}
			return retour;
		case ')':
		case END_MARKER:
			return null;
		default:
			throw new SyntaxException(ErrorType.NO_RULE,current);
		}
	}
	
	private String E() throws SyntaxException, ParserException {
		switch(current){
		case 'a':
		case 'b':
		case 'c':
			return L();
		case '(':
			eat('(');
			String s=S();
			eat(')');
			return s;
		default:
			throw new SyntaxException(ErrorType.NO_RULE,current);
		}
	}
	
	private int R() throws SyntaxException, ParserException {
		switch(current){
		case 'a':
		case 'b':
		case 'c':
		case '(':
		case ')':
		case END_MARKER:
			return -1;
		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			return C();
		default:
			throw new SyntaxException(ErrorType.NO_RULE,current);
		}
	}
	
	private String L() throws SyntaxException, ParserException {
		switch(current){
		case 'a':
			eat('a');
			return "a";
		case 'b':
			eat('b');
			return "b";
		case 'c':
			eat('c');
			return "c";
		default:
			throw new SyntaxException(ErrorType.NO_RULE,current);
		}
	}
	
	private int C() throws SyntaxException, ParserException {
		switch(current){
		case '0':
			eat('0');
			return 0;
		case '1':
			eat('1');
			return 1;
		case '2':
			eat('2');
			return 2;
		case '3':
			eat('3');
			return 3;
		case '4':
			eat('4');
			return 4;
		case '5':
			eat('5');
			return 5;
		case '6':
			eat('6');
			return 6;
		case '7':
			eat('7');
			return 7;
		case '8':
			eat('8');
			return 8;
		case '9':
			eat('9');
			return 9;
		default:
			throw new SyntaxException(ErrorType.NO_RULE,current);
		}
	}
	protected void axiom() throws SyntaxException, ParserException {
		S();
		
	}
	public static void main(String[] args) throws SyntaxException, ParserException {
		Scanner input = new Scanner(System.in);
		System.out.print("mot ? > ");
		while (input.hasNextLine()) {
			String word = input.nextLine();
			String s;
			ActionsSemantiques parser = new ActionsSemantiques(new StringReader(word));
			try {
				s=parser.S();
				System.out.println(s);
			} catch (SyntaxException e) {
				System.out.println("Erreur : " + e.getMessage());
				
			}
			System.out.print("mot ? > ");
		}
		input.close();
	}

}

