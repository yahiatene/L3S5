package automata;

import java.util.Set;



/**
 * 
 * Implémentation d'un automate non déterministe.
 * Version incomplète.
 * 
 * @author Bruno.Bogaert (at) univ-lille1.fr
 *
 */
public class NDAutomatonIncomplete extends AbstractNDAutomaton implements Recognizer, AutomatonBuilder {

	/**
	 * Fake implementation : always return false.
	 */
	public boolean accept(String word) {
		if( word==""){
			if(this.alphabet.contains(' ')){
				return true;
			}
			else{
				return false;
			}
			}
		char[] chars = word.toCharArray();
	
		Set<State> r=getTransitionSet(this.initialStates , chars[0]);
			for (int i=1;i<chars.length;i++){
				 r=getTransitionSet(r , chars[i]);
			}
			java.util.Iterator<State> it= this.acceptingStates.iterator();
			while (it.hasNext()) 
			{
			  State s = it.next();
			  if(r.contains(s)){
				  return true;
			  }
			}
			return false;
			
		
	}

	public Set<State> getTransitionSet(Set<State> fromSet, char letter) {
		Set<State> stateSet=new PrintSet<State>();
		java.util.Iterator<State> it= fromSet.iterator();
		while (it.hasNext()) 
		{
		  State s = it.next();
		  stateSet.addAll(getTransitionSet(s, letter));
		}
		return stateSet;
	}
	


}
