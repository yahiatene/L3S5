package postfixees;
public class FinLigne{

  public FinLigne(){
    return 1;
  }
}
