package postfixees;
public class Espace{

  public Espace(){
    return 1;
  }
}
