yahiatene@a12p19:~/Bureau/AEL/tdm2_fichiers$ egrep 'nez' Cyrano.txt --color
Vous...vous avez un nez...heu...un nez...très grand.
En variant le ton, par exemple, tenez:
Agressif : " Moi, monsieur, si j'avais un tel nez,
Truculent : "çà, monsieur, lorsque vous pétunez,
La vapeur du tabac vous sort-elle du nez
Emphatique : " Aucun vent ne peux, nez magistral
Campagnard : " Hé, ardé! C'est-y un nez? Nanain!
" Le voilà donc ce nez qui des traits de son maître




yahiatene@a12p19:~/Bureau/AEL/tdm2_fichiers$ egrep '\(*\)' Cyrano.txt --color
(De Guiche)
(Le Vicomte)
(Cyrano)
(Le Vicomte)
(Cyrano)
(Le Vicomte)
(Cyrano)



4)egrep '[\:[:space:]\"[:space:][:upper:]] ' Cyrano.txt --color=auto
#a refaire


