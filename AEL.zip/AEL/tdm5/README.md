# Rendu du tdm5 en AEL
# YAHIATENE Moahmed
# BENKHIDER Zinedine


* Le travail demandé est fait et testé. 
* On a pas reussi à tester la méthode de déterminisation.
