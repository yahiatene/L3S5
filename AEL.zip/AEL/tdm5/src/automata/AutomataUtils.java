package automata;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
/**
 * 
 * @author Bruno.Bogaert (at) univ-lille.fr
 *
 */
public class AutomataUtils {

	/**
	 * Extends automaton a, so that it accepts also this word. 
	 * Created states are prefixed by 'q_'  
	 * @param word : word to be accepted
	 * @param a : target automaton
	 */
	public static void addSingleton(String word, AutomatonBuilder a) {
		addSingleton(word, a, "q");
	}

	/**
	 * Extends automaton a so that it accepts also this word.
	 * Created states are prefixed by namePrefix followed by '_' 
	 * @param word : word to be accepted
	 * @param a : target automaton
	 * @param namePrefix : prefix to use for state names.
	 */
	public static void addSingleton(String word, AutomatonBuilder a, String namePrefix) {
		char[] chars = word.toCharArray();
		State si=a.addNewState(namePrefix+"epsilone");
		a.setInitial(si);
		State s =null;
		for (int i=0;i<chars.length;i++){
			s=a.addNewState(namePrefix+word.substring(0, i+1));
			
			a.addTransition(si,chars[i],s);
			si=s;
		}
		a.setAccepting(s);
		
	}

	/**
	 * Extends automaton a so that it accepts also this finite language
	 * created states are prefixed by namePrefix followed by '_'  
	 * @param finiteLanguage : set of words to be accepted
	 * @param a : target automaton
	 */
	public static void addFiniteSet(Iterable<String> finiteLanguage, AutomatonBuilder a) {
		Iterator<String> it=finiteLanguage.iterator();
		while(it.hasNext()){
			String word=it.next();
			addSingleton( word,  a);
		}
	}

	/**
	 * Extends automaton a so that it accepts also language denoted by exp
	 * created states are prefixed by namePrefix followed by '_'  
	 * @param exp : flat regular expression (only letters and *)
	 * @param a : target automaton
	 */
	public static void addFlatExp(String exp, AutomatonBuilder a) {
		addFlatExp(exp, a, "q");
	}
	
	/**
	 * Extends automaton a so that it accepts also language denoted by exp
	 * created states are prefixed by namePrefix followed by '_'  
	 * @param exp : flat regular expression (only letters and *)
	 * @param a : target automaton
	 * @param namePrefix : prefix to use for state names.
	 */
	public static void addFlatExp(String exp, AutomatonBuilder a, String namePrefix) {
		char[] chars = exp.toCharArray();
		State si=a.addNewState(namePrefix+"epsilone");
		a.setInitial(si);
		State s ;
		State s1=null;
		for (int i=0;i<chars.length-1;i++){
			if (chars[i]!='*'){
			if (chars[i+1]=='*'){
				a.addTransition(si,chars[i],si);
			}
			else{
			s=a.addNewState(namePrefix+exp.substring(0, i+1));
			a.addTransition(si,chars[i],s);
			si=s;}
		}
		}
		if (chars[chars.length-1]!='*'){
			s1=a.addNewState(namePrefix+exp.substring(0, chars.length));
			a.addTransition(si,chars[chars.length-1],s1);
		}
		a.setAccepting(s1);
		
	}

	/**
	 * Transpose automaton
	 * Note : mirror is cleared before the operation. 
	 * 
	 * @param original : automaton to be transposed
	 * @param mirror : receive the transposed automaton 
	 */
	public static void transpose(Automaton original, AutomatonBuilder mirror) {
		Set<State> s3;
		java.util.Iterator<State> it= original.getStates().iterator();
		Iterator<Character> it1;
		while (it.hasNext()) {
			State s2 = it.next();

			if( original.getAcceptingStates().contains(s2)){
				mirror.addNewState();
				mirror.setInitial(s2.getName());
				
			}
			 if (original.getInitialStates().contains(s2)){
				 mirror.addNewState();
				mirror.setAccepting(s2.getName());
			}
			 
		it1= original.usedAlphabet().iterator();
		 while (it1.hasNext()){
		 Character c = it1.next();  
		 s3=original.getTransitionSet(s2, c);
		 
		 java.util.Iterator<State> it2= s3.iterator();
		 while (it2.hasNext()){
			 State s4= it2.next();
			 mirror.addTransition(s4.getName(), c, s2.getName());
			 
		 }
		  }
		}
		
		
		
	}

	/**
	 * Determinization of nfa automaton. 
	 * Note : dfa is cleared before the operation.
	 * @param nfa : non deterministic automaton (to be determinize)
	 * @param dfa : receive determinization result
	 */
	public static void determinize(Automaton nfa, AutomatonBuilder dfa) {
		// For each computed state set from nfa, a corresponding state has to be created in dfa
		// map represents relationship  between nfa state set (key) and created dfa state (value) 
		Map<Set<State>, State> map = new HashMap<Set<State>, State>();
				
		// stack todo contains state sets whose transitions have not yet been computed
		Stack<Set<State>> todo = new Stack<Set<State>>(); 
		
		dfa.clear();

		Set<State> startSet = nfa.getInitialStates();

		// create matching state in DFA
		State start = dfa.addNewState(startSet.toString()); // state creation
		map.put(startSet, start);  // record relationship in map

		dfa.setAccepting(start); // start is the unique initial state of dfa

		
		todo.push(startSet); // put it in todo list.
		State s2=null;
		while (! todo.isEmpty()) {
			Set<State> fromSet = todo.pop(); // pick a state from todo list
			Iterator<Character> it= nfa.usedAlphabet().iterator();
			
			while (it.hasNext()) {
				char c = it.next();
				Set<State> s=nfa.getTransitionSet(fromSet, c);
				if (!nfa.getStates().containsAll(s)){
				s2=dfa.addNewState(s.toString());
					map.put(s,s2 );
					todo.add(s);
					}
			    dfa.addTransition(start, c, s2);
			    start=s2;
				
				}
			
			
		}
		for (Set<State> qSet : map.keySet()) {	// foreach computed state set
			if(qSet.containsAll(dfa.getAcceptingStates())){
				Iterator<State> it1=qSet.iterator();
				
				while (it1.hasNext()) {
					State s= it1.next();
				dfa.setAccepting(s);
			}
		
		}
	}
	
}}
