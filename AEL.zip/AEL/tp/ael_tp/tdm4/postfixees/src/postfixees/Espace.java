package postfixees;
public class Espace implements Yytoken{
 
  public Espace(String image){
    
  }
public String image(){
 return " ";
}
 public String nom(){
 return "espace";
}
  
}
