package postfixees;
import java.io.*;

import java.util.*;

class TestPF {
  public static void main(String arg[]) throws IOException, AriteException {
      // créer un Yylex qui va prendre ses entrées dans le fichier
      // de nom arg[0]
    Yylex yy = new Yylex(new BufferedReader(new FileReader(arg[0]))) ;
    Yytoken token ;
      // la fin de fichier est codée par un token null
    
    Stack<Integer> pile = new Stack<Integer>();
	int j=0;
    while ((token = yy.yylex()) != null){
        if (token instanceof Valeur) {
            Valeur v = (Valeur) token;
            pile.push(v.value());
	    

        } else if (token instanceof Operateur){
            Operateur op = (Operateur) token;
            int[] args = new int[op.arite()];
	
            for (int i=0; i<args.length; i++)
                args[i] = pile.pop();
            pile.push(op.evaluate(args));

        }
	  else if (token instanceof Opp){
            Operateur op = (Operateur) token;
            int[] args = new int[op.arite()];
            pile.push(op.evaluate(args));

        }
        else if(token instanceof Espace){
          
         }
	else if(token instanceof FinLigne){
	j++;
	 System.out.println("result ligne "+j+": "+pile.pop());
       }
      
	
    }


    
  }
}
