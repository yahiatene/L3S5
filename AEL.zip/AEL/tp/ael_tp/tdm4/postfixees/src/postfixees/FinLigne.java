package postfixees;
public class FinLigne implements Yytoken{
  
  public FinLigne(String image){
    
  }
public String image(){
return "";
}
 public String nom(){
return "";
}
  
}
