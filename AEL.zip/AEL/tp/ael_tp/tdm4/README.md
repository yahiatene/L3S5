# Rendu du tdm4 en AEL
# YAHIATENE Moahmed
# BENKHIDER Zinedine

* On a reussit la question 5.

### Commandes:

* génération de l’analyseur : java -jar ../jflex-1.6.1.jar src/postfixees/postfixees.lex
* compilation java : javac -cp src -d bin src/postfixees/TestPF.java
* exécution de l’analyseur sur le fichier de test : java -cp bin postfixees.TestPF testPost.txt
