# Rendu du tdm7 en AEL
# YAHIATENE Moahmed
# BENKHIDER Zinedine

* on a fait un test sur l'automate de td4 exo4 et on a constaté que ça donne le bon resultat.

* commande pour avoir un graphe au format **pdf** a partir du **.dot** :
**dot -Tps automate-test.dot -o exo4.pdf**
