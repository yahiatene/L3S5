package automata;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
/**
 * 
 * @author Bruno.Bogaert (at) univ-lille.fr
 *
 */
public class AutomataUtils {

	/**
	 * Extends automaton a, so that it accepts also this word. 
	 * Created states are prefixed by 'q_'  
	 * @param word : word to be accepted
	 * @param a : target automaton
	 */
	public static void addSingleton(String word, AutomatonBuilder a) {
		addSingleton(word, a, "q");
	}

	/**
	 * Extends automaton a so that it accepts also this word.
	 * Created states are prefixed by namePrefix followed by '_' 
	 * @param word : word to be accepted
	 * @param a : target automaton
	 * @param namePrefix : prefix to use for state names.
	 */
	public static void addSingleton(String word, AutomatonBuilder a, String namePrefix) {
		char[] chars = word.toCharArray();
		
		State si=a.addNewState(namePrefix+"epsilone");
		a.setInitial(si);
		State s = null;
		for (int i=0;i<chars.length;i++){
			s=a.addNewState(namePrefix+word.substring(0, i+1));
			
			a.addTransition(si,chars[i],s);
			si=s;
		}
		a.setAccepting(s);
		Collection<State> d=new HashSet<State>();
		
	}

	/**
	 * Extends automaton a so that it accepts also this finite language
	 * created states are prefixed by namePrefix followed by '_'  
	 * @param finiteLanguage : set of words to be accepted
	 * @param a : target automaton
	 */
	public static void addFiniteSet(Iterable<String> finiteLanguage, AutomatonBuilder a) {
		Iterator<String> it=finiteLanguage.iterator();
		while(it.hasNext()){
			String word=it.next();
			addSingleton( word,  a);
		}
	}

	/**
	 * Extends automaton a so that it accepts also language denoted by exp
	 * created states are prefixed by namePrefix followed by '_'  
	 * @param exp : flat regular expression (only letters and *)
	 * @param a : target automaton
	 */
	public static void addFlatExp(String exp, AutomatonBuilder a) {
		addFlatExp(exp, a, "q");
	}
	
	/**
	 * Extends automaton a so that it accepts also language denoted by exp
	 * created states are prefixed by namePrefix followed by '_'  
	 * @param exp : flat regular expression (only letters and *)
	 * @param a : target automaton
	 * @param namePrefix : prefix to use for state names.
	 */
	public static void addFlatExp(String exp, AutomatonBuilder a, String namePrefix) {
		
	}

	/**
	 * Transpose automaton
	 * Note : mirror is cleared before the operation. 
	 * 
	 * @param original : automaton to be transposed
	 * @param mirror : receive the transposed automaton 
	 */
	public static void transpose(Automaton original, AutomatonBuilder mirror) {
		Set<State> s3;
		java.util.Iterator<State> it= original.getStates().iterator();
		Iterator<Character> it1;
	    ArrayList<String> listOfState=new ArrayList<String>();
		while (it.hasNext()) {
			State s2 = it.next();
			
			
			if( original.getAcceptingStates().contains(s2)){
				if (!listOfState.contains(s2.getName())){
				if(s2.getName().length()==2){
				mirror.addNewState();}
				else{
					mirror.addNewState(s2.getName());
				}
				}
				mirror.setInitial(s2.getName());
				
				listOfState.add(s2.getName());
			}
			else if (original.getInitialStates().contains(s2)){
				if (!listOfState.contains(s2.getName())){
				if(s2.getName().length()==2){
					mirror.addNewState();}
					else{
						mirror.addNewState(s2.getName());
					}}
				mirror.setAccepting(s2.getName());
				listOfState.add(s2.getName());
				
			}
			
			 
		it1= original.usedAlphabet().iterator();
		  while (it1.hasNext()){
		 Character c = it1.next(); 
		 
		 s3=original.getTransitionSet(s2, c);
		
		 java.util.Iterator<State> it2= s3.iterator();
		 while (it2.hasNext()){
			 
			 State s4= it2.next();
			
			
			 if (!listOfState.contains(s4.getName())){
				 
				
				mirror.addNewState(s4.getName());
						 
						
				
						
				 
				 listOfState.add(s4.getName());
				 }
			 mirror.addTransition(s4.getName(), c, s2.getName());
			 
		 }
		  }
		}
		
		
		
	}
	
	public static ArrayList<String> toArrayString(Set<State> d){
		Object[] s = d.toArray();
		ArrayList<String> as=new ArrayList<String>();
		
		for(int i=0;i<s.length;i++){
			as.add(((State) s[i]).getName());
		}
		return as;
	}
	
	public static boolean containe(String words,ArrayList<String> arr){
		for(int i=0;i<words.length();i++){
			if(arr.contains(words.substring(0,i))){
				return true;
			}
		}
		return false;
	}
	public static void minimisation(Automaton nfa, AutomatonBuilder dest){
		AutomatonBuilder a= new NDAutomatonIncomplete();
		AutomatonBuilder b= new NDAutomatonIncomplete();
		AutomatonBuilder c= new NDAutomatonIncomplete();
		AutomataUtils.transpose( nfa, a) ;
		
		AutomataUtils.determinize(a,b );
		
		AutomataUtils.transpose( b, c) ;
		AutomataUtils.determinize(c,dest );
		
		
	}
	public static void createAhoCorasick(String[] words, AutomatonBuilder dest){
		State s = null;
		State si=dest.addNewState("root");
		State sroot=si;
		dest.setInitial(si);
		char[] chars;
		for(int i=0;i<words.length;i++){
			chars = words[i].toCharArray();
		if(AutomataUtils.containe(words[i],AutomataUtils.toArrayString(dest.getStates()))){
		  int max=-1;
		  for(int z=1;z<words[i].length()+1;z++){
			if (AutomataUtils.toArrayString(dest.getStates()).contains(words[i].substring(0,z))){
				max=z;
			}
			}
			if (max!=-1){
				String k=words[i].substring(0, max);
				for (int j=max;j<chars.length;j++){
						s=dest.addNewState(words[i].substring(0,j+1));
						dest.addTransition(k,chars[j],s.getName());
						k=s.getName();}
				dest.setAccepting(s);
			}}
			else{
			for (int j=0;j<chars.length;j++){
					s=dest.addNewState(words[i].substring(0,j+1));
					dest.addTransition(si,chars[j],s);
					si=s;
					
				}
			dest.setAccepting(s);
			si=sroot;
			}
			}
			
			
		}
	
			
		
	/**
	 * Determinization of nfa automaton. 
	 * Note : dfa is cleared before the operation.
	 * @param nfa : non deterministic automaton (to be determinize)
	 * @param dfa : receive determinization result
	 */
	public static void determinize(Automaton nfa, AutomatonBuilder dfa) {
		// For each computed state set from nfa, a corresponding state has to be created in dfa
		// map represents relationship  between nfa state set (key) and created dfa state (value) 
		Map<Set<State>, State> map = new HashMap<Set<State>, State>();
				
		// stack todo contains state sets whose transitions have not yet been computed
		Stack<Set<State>> todo = new Stack<Set<State>>(); 
		
		dfa.clear();

		Set<State> startSet = nfa.getInitialStates();
        
		// create matching state in DFA
		State start = dfa.addNewState(startSet.toString()); // state creation
		map.put(startSet, start);  // record relationship in map

		dfa.setInitial(start); // start is the unique initial state of dfa
    
		todo.push(startSet); // put it in todo list.
	
			
		ArrayList<String> listOfState=new ArrayList<String>();
		listOfState.add(startSet.toString());	 
		State s2=null;
		String d;
	
		while (!todo.isEmpty()) {
			Set<State> fromSet = todo.pop(); // pick a state from todo list
			Iterator<Character> it= nfa.usedAlphabet().iterator();
			d=fromSet.toString();
			while (it.hasNext()) {
				char c = it.next();
				
				Set<State> s=nfa.getTransitionSet(fromSet, c);
				
				
				if (!listOfState.contains(s.toString())){
					
				   s2=dfa.addNewState(s.toString());
				  
				   listOfState.add(s.toString());
				   map.put(s,s2);
				   todo.add(s);
				   					}
				dfa.addTransition(d, c, s.toString());
				}
		}
		
		for (Set<State> qSet : map.keySet()) {	
			Iterator<State> it2= nfa.getAcceptingStates().iterator();
		    
			while (it2.hasNext()) {
			 State de=it2.next();
				if (qSet.contains(de)){
			dfa.setAccepting(qSet.toString());
			}
			}
		
	}
		
	}
	
}
