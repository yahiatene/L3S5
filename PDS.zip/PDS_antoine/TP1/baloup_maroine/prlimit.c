#include <limits.h>
#include <stdio.h>

int main(int argc, char** argv) {
	
	printf("Path max : %i, Name max : %i\n", PATH_MAX, NAME_MAX);
	return 0;
}
