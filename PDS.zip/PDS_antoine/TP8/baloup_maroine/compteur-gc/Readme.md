TP8 Compteur-gc
===============

Par Maxime Maroine et Marc Baloup

## Précisions

- aleazard affiche en sortie d'erreur la progression de la génération
  (pour les gros génomes) : 1 point = 1%
  
- Lors de l'utilisation de gnuplot, l'image est généré en deux temps :
	- La sauvegarde d'une image au format PNG
	- Si l'ordinateur le permet : l'affichage de ce même graphique dans
	  une fenêtre interactive.

