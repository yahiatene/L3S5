TP8 tri-rapide
==============



Par Maxime Maroine et Marc Baloup





tric.c et tric.h rendu synchronisé (protégé par des mutex)


TP non terminé, mais on a commencé à coder.

Voir la fin de `rapide.c` et `tric.[ch]`
