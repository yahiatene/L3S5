TP8 Thread
==========

Par Gamelin Kevin et Oudjail Veis

Licence 3 Informatique, Université Lille 1

2015-2016

## Aleazard (mtcompteur_gc)

- Creation du fichier contenant un genome généré de façon aleatoire
  ./aleazard [nombre de caractéres representant (Adénine, Guanine, Cytosine et Thymine)] > [fichier.txt]

- Compteur d'elements de type Guanine et Thymine
  ./compteur_gc [fichier.txt]

### Commande possible
  make
  make test
  - Cette commande lancer un test qui va generer un graphque en 3 dimensions en format PNG
  Si vous possedez un logiciel de consultation de graphe interactive, veuillez decommenter les deux dernieres lignes du run.gnu
