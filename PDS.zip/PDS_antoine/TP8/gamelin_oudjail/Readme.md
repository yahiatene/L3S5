TP8 Thread
==========

Par Gamelin Kevin et Oudjail Veis

Licence 3 Informatique, Université Lille 1

2015-2016

## Aleazard (mtcompteur_gc)

- Creation du fichier contenant un genome généré de façon aleatoire
  ./aleazard [nombre de caractéres representant (Adénine, Guanine, Cytosine et Thymine)] > [fichier.txt]

- Compteur d'elements de type Guanine et Thymine
  ./compteur_gc [fichier.txt]

## Quick Sort
