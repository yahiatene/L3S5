TP3 : mtail
=====


Par Marc Baloup

Licence 3 Informatique, Université Lille 1

2015-2016




mtail_stupide.c
------
Version "stupide". Compte le nombre `total` de `\n` dans le fichier.
Retourne au début du fichier et lis à partir de `total - n` lignes
`n` étant le nombre de ligne demandé.



mtail.c
------
Utilise un buffer circulaire.

