var group___sighandler =
[
    [ "lock_signal", "group___sighandler.html#gaf57b49bbe63afb81b5cbf55e9add1947", null ],
    [ "sigaction_wrapper", "group___sighandler.html#ga897310bf5d40244e5da806fae0dee397", null ],
    [ "sigchld_handler", "group___sighandler.html#ga7ec144a9a628442e52b80210bc8364ad", null ],
    [ "sigint_handler", "group___sighandler.html#ga258e3b580e688a0cf46e4258525aeaf1", null ],
    [ "sigquit_handler", "group___sighandler.html#ga368a774e2b304a3de55f58168563967d", null ],
    [ "sigtstp_handler", "group___sighandler.html#ga809b7c47b9e4abc05325a4b3d33f59a5", null ],
    [ "unlock_signal", "group___sighandler.html#ga54d7cd6d673e2bcc401f961e18ed3270", null ]
];