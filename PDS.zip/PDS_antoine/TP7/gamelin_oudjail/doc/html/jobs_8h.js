var jobs_8h =
[
    [ "job_t", "structjob__t.html", "structjob__t" ],
    [ "jstate", "jobs_8h.html#a10b96f189deffad575d53eef520a3ba8", [
      [ "UNDEF", "jobs_8h.html#a10b96f189deffad575d53eef520a3ba8a632fa39438c1676b435ec43e6a0f9647", null ],
      [ "BG", "jobs_8h.html#a10b96f189deffad575d53eef520a3ba8a23e80b20c0b0f0cd521f26c28f8bcef4", null ],
      [ "FG", "jobs_8h.html#a10b96f189deffad575d53eef520a3ba8adedb927cc06e82b0a51c3712b71fe9f4", null ],
      [ "ST", "jobs_8h.html#a10b96f189deffad575d53eef520a3ba8a200bf26d1a70596904b82da10880c2f1", null ]
    ] ],
    [ "jobs_addjob", "jobs_8h.html#a09796fb93bd0de39b7c39dee00a0a85b", null ],
    [ "jobs_clearjob", "jobs_8h.html#ac69855e20d8ce55ec69bca742e460c7f", null ],
    [ "jobs_deletejob", "jobs_8h.html#a44078c0e559d566dcbf7d60f76e96c5f", null ],
    [ "jobs_fgpid", "jobs_8h.html#a02cc8fbd6b64aae9ce422b3f229d5f8d", null ],
    [ "jobs_getjobjid", "jobs_8h.html#ac5e9acf666fa618c0a312485a9a0d73c", null ],
    [ "jobs_getjobpid", "jobs_8h.html#abac563aa23403acbabc30e02aba783a5", null ],
    [ "jobs_getstoppedjob", "jobs_8h.html#abe9f3fef33956b1cbc8aa721bdbadccb", null ],
    [ "jobs_initjobs", "jobs_8h.html#aed8090f7e3c895734c15c7050f9f8588", null ],
    [ "jobs_listjobs", "jobs_8h.html#a1d6940d5da8683af28933cfe401ca5c7", null ],
    [ "jobs_maxjid", "jobs_8h.html#a21c0bf707724f93e170c21e52b2a3cab", null ],
    [ "jobs_pid2jid", "jobs_8h.html#ad951d0573e6600ff0d1c83813059681d", null ],
    [ "send_signal_to_job", "jobs_8h.html#a876ff3dc43390145f9ac07f7fe4ff7ae", null ]
];