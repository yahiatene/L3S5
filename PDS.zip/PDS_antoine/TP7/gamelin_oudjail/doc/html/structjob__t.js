var structjob__t =
[
    [ "jb_cmdline", "structjob__t.html#af10055dc942d27ceae15c85513aae3f3", null ],
    [ "jb_jid", "structjob__t.html#a92658a57dc4aaedcb04db49117b4f724", null ],
    [ "jb_pid", "structjob__t.html#a82fe3c0cecc3c72f11036d28a9679832", null ],
    [ "jb_state", "structjob__t.html#a749b836667db3e8ff7c09fd16a80abbe", null ]
];