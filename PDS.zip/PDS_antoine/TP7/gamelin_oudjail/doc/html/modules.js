var modules =
[
    [ "section, process communication", "group___pipe.html", "group___pipe" ],
    [ ", gestionnaire des signaux systeme", "group___sighandler.html", "group___sighandler" ]
];