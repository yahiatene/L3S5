var sighandlers_8c =
[
    [ "lock_signal", "sighandlers_8c.html#af57b49bbe63afb81b5cbf55e9add1947", null ],
    [ "sigaction_wrapper", "sighandlers_8c.html#a897310bf5d40244e5da806fae0dee397", null ],
    [ "sigchld_handler", "sighandlers_8c.html#a7ec144a9a628442e52b80210bc8364ad", null ],
    [ "sigint_handler", "sighandlers_8c.html#a258e3b580e688a0cf46e4258525aeaf1", null ],
    [ "sigtstp_handler", "sighandlers_8c.html#a809b7c47b9e4abc05325a4b3d33f59a5", null ],
    [ "unlock_signal", "sighandlers_8c.html#a54d7cd6d673e2bcc401f961e18ed3270", null ]
];