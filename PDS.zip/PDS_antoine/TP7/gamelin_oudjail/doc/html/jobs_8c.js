var jobs_8c =
[
    [ "MAXJOBS", "jobs_8c.html#abe340a6b1ce6ec59c9cbf50fdeaacb1d", null ],
    [ "jobs_addjob", "jobs_8c.html#a09796fb93bd0de39b7c39dee00a0a85b", null ],
    [ "jobs_clearjob", "jobs_8c.html#ac69855e20d8ce55ec69bca742e460c7f", null ],
    [ "jobs_deletejob", "jobs_8c.html#a44078c0e559d566dcbf7d60f76e96c5f", null ],
    [ "jobs_fgpid", "jobs_8c.html#a02cc8fbd6b64aae9ce422b3f229d5f8d", null ],
    [ "jobs_getjobjid", "jobs_8c.html#a0efe5a7a1f8910af08fb05912a2029ea", null ],
    [ "jobs_getjobpid", "jobs_8c.html#a6b6da169b18379ed6024a5c1b7db4fcb", null ],
    [ "jobs_getstoppedjob", "jobs_8c.html#a73e20e47805b1af05616f314d46b27c6", null ],
    [ "jobs_initjobs", "jobs_8c.html#aed8090f7e3c895734c15c7050f9f8588", null ],
    [ "jobs_listjobs", "jobs_8c.html#a1d6940d5da8683af28933cfe401ca5c7", null ],
    [ "jobs_maxjid", "jobs_8c.html#a21c0bf707724f93e170c21e52b2a3cab", null ],
    [ "jobs_pid2jid", "jobs_8c.html#ad951d0573e6600ff0d1c83813059681d", null ],
    [ "send_signal_to_job", "jobs_8c.html#ac9d7319ff9bbde5503b4448f05b29eff", null ],
    [ "nextjid", "jobs_8c.html#a9ba591aa9c5f5e2356f413184d877324", null ]
];