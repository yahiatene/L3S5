var searchData=
[
  ['jobs_5faddjob',['jobs_addjob',['../jobs_8h.html#a09796fb93bd0de39b7c39dee00a0a85b',1,'jobs.c']]],
  ['jobs_5fclearjob',['jobs_clearjob',['../jobs_8h.html#ac69855e20d8ce55ec69bca742e460c7f',1,'jobs.c']]],
  ['jobs_5fdeletejob',['jobs_deletejob',['../jobs_8h.html#a44078c0e559d566dcbf7d60f76e96c5f',1,'jobs.c']]],
  ['jobs_5ffgpid',['jobs_fgpid',['../jobs_8h.html#a02cc8fbd6b64aae9ce422b3f229d5f8d',1,'jobs.c']]],
  ['jobs_5fgetjobjid',['jobs_getjobjid',['../jobs_8h.html#ac5e9acf666fa618c0a312485a9a0d73c',1,'jobs.c']]],
  ['jobs_5fgetjobpid',['jobs_getjobpid',['../jobs_8h.html#abac563aa23403acbabc30e02aba783a5',1,'jobs.c']]],
  ['jobs_5fgetstoppedjob',['jobs_getstoppedjob',['../jobs_8h.html#abe9f3fef33956b1cbc8aa721bdbadccb',1,'jobs.c']]],
  ['jobs_5finitjobs',['jobs_initjobs',['../jobs_8h.html#aed8090f7e3c895734c15c7050f9f8588',1,'jobs.c']]],
  ['jobs_5flistjobs',['jobs_listjobs',['../jobs_8h.html#a1d6940d5da8683af28933cfe401ca5c7',1,'jobs.c']]],
  ['jobs_5fmaxjid',['jobs_maxjid',['../jobs_8h.html#a21c0bf707724f93e170c21e52b2a3cab',1,'jobs.c']]],
  ['jobs_5fpid2jid',['jobs_pid2jid',['../jobs_8h.html#ad951d0573e6600ff0d1c83813059681d',1,'jobs.c']]]
];
