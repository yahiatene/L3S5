var searchData=
[
  ['jstate',['jstate',['../jobs_8h.html#a10b96f189deffad575d53eef520a3ba8',1,'jobs.h']]]
];
