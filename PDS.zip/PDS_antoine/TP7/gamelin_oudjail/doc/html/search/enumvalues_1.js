var searchData=
[
  ['fg',['FG',['../jobs_8h.html#a10b96f189deffad575d53eef520a3ba8adedb927cc06e82b0a51c3712b71fe9f4',1,'jobs.h']]]
];
