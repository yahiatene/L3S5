var searchData=
[
  ['norm',['NORM',['../common_8h.html#ae1fc77c1a1666773a25dc88a72da4b2b',1,'common.h']]]
];
