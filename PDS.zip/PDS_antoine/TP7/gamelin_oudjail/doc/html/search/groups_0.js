var searchData=
[
  ['section_2c_20process_20communication',['section, process communication',['../group___pipe.html',1,'']]]
];
