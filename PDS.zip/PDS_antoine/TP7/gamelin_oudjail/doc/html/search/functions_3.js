var searchData=
[
  ['send_5fsignal_5fto_5fjob',['send_signal_to_job',['../jobs_8h.html#a876ff3dc43390145f9ac07f7fe4ff7ae',1,'jobs.c']]],
  ['send_5fverbose_5fmessage',['send_verbose_message',['../common_8h.html#aad19de906e3dfa4bdba3e97b4c1cda5b',1,'common.c']]],
  ['sigaction_5fwrapper',['sigaction_wrapper',['../group___sighandler.html#ga897310bf5d40244e5da806fae0dee397',1,'sigaction_wrapper(int signum, handler_t *handler):&#160;sighandlers.c'],['../group___sighandler.html#ga897310bf5d40244e5da806fae0dee397',1,'sigaction_wrapper(int signum, handler_t *handler):&#160;sighandlers.c']]],
  ['sigchld_5fhandler',['sigchld_handler',['../group___sighandler.html#ga7ec144a9a628442e52b80210bc8364ad',1,'sigchld_handler(int sig):&#160;sighandlers.c'],['../group___sighandler.html#ga7ec144a9a628442e52b80210bc8364ad',1,'sigchld_handler(int sig):&#160;sighandlers.c']]],
  ['sigint_5fhandler',['sigint_handler',['../group___sighandler.html#ga258e3b580e688a0cf46e4258525aeaf1',1,'sigint_handler(int sig):&#160;sighandlers.c'],['../group___sighandler.html#ga258e3b580e688a0cf46e4258525aeaf1',1,'sigint_handler(int sig):&#160;sighandlers.c']]],
  ['sigquit_5fhandler',['sigquit_handler',['../group___sighandler.html#ga368a774e2b304a3de55f58168563967d',1,'sighandlers.h']]],
  ['sigtstp_5fhandler',['sigtstp_handler',['../group___sighandler.html#ga809b7c47b9e4abc05325a4b3d33f59a5',1,'sigtstp_handler(int sig):&#160;sighandlers.c'],['../group___sighandler.html#ga809b7c47b9e4abc05325a4b3d33f59a5',1,'sigtstp_handler(int sig):&#160;sighandlers.c']]]
];
