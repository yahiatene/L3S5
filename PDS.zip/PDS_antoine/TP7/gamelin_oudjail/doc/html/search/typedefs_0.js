var searchData=
[
  ['handler_5ft',['handler_t',['../sighandlers_8h.html#acefb2ae1d743b3e28bdcd190cd1060f5',1,'sighandlers.h']]]
];
