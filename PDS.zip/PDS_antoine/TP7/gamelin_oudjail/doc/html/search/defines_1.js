var searchData=
[
  ['bold',['BOLD',['../common_8h.html#a26cdbb1a00213c810caccf21cd33a631',1,'common.h']]]
];
