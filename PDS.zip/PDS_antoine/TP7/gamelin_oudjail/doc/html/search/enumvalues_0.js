var searchData=
[
  ['bg',['BG',['../jobs_8h.html#a10b96f189deffad575d53eef520a3ba8a23e80b20c0b0f0cd521f26c28f8bcef4',1,'jobs.h']]]
];
