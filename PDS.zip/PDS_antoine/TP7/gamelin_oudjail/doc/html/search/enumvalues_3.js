var searchData=
[
  ['undef',['UNDEF',['../jobs_8h.html#a10b96f189deffad575d53eef520a3ba8a632fa39438c1676b435ec43e6a0f9647',1,'jobs.h']]]
];
