var searchData=
[
  ['jb_5fcmdline',['jb_cmdline',['../structjob__t.html#af10055dc942d27ceae15c85513aae3f3',1,'job_t']]],
  ['jb_5fjid',['jb_jid',['../structjob__t.html#a92658a57dc4aaedcb04db49117b4f724',1,'job_t']]],
  ['jb_5fstate',['jb_state',['../structjob__t.html#a749b836667db3e8ff7c09fd16a80abbe',1,'job_t']]]
];
