var indexSectionsWithContent =
{
  0: "abcdjlmnpsuvw",
  1: "j",
  2: "cjps",
  3: "djlsuw",
  4: "jpv",
  5: "j",
  6: "abmn",
  7: "s",
  8: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "defines",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Macros",
  7: "Modules",
  8: "Pages"
};

