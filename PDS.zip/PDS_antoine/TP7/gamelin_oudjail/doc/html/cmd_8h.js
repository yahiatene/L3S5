var cmd_8h =
[
    [ "do_bg", "cmd_8h.html#a5227a9c8f5b785dd27022b08aa96def4", null ],
    [ "do_cd", "cmd_8h.html#a2ad3c4bf90154b27778fe722cdb9f20f", null ],
    [ "do_exit", "cmd_8h.html#a463731ba182e97401aa91f8258c3ce3b", null ],
    [ "do_fg", "cmd_8h.html#ad800d8985af259150fe0426abf06c52b", null ],
    [ "do_help", "cmd_8h.html#a82ccff470e09e8da8a6c92961643c943", null ],
    [ "do_jobs", "cmd_8h.html#ad839e67b11eeece6a0bbb8964e54110d", null ],
    [ "do_kill", "cmd_8h.html#a96fcd8d94bc25ded28d0801af2d4b73b", null ],
    [ "do_stop", "cmd_8h.html#a4fd74fc0e0aacf24ba3d1d1325e709f8", null ],
    [ "waitfg", "cmd_8h.html#a6d41e68c6d9855500b96b1f467d8fcd5", null ]
];