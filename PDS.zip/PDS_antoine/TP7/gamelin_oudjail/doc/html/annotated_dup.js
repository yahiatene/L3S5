var annotated_dup =
[
    [ "job_t", "structjob__t.html", "structjob__t" ]
];