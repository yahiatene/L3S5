PT7 mshell
==========

Par Maxime Maroine et Marc Baloup

## Éléments qui fonctionnement

- Les traitements de signaux (Ctrl+C, Ctrl+Z, SIGCHLD)
- Les commandes kill, jobs, bg, fg, stop et exit
- Les pipes, peu importes la quantité

## Tests du mshell

Voir le fichier `exemples.txt`
