#! /bin/bash
echo "---------- Exécution de la commande do ----------"

echo "-- ./do true ------------------------------------"
./do true; echo "exit $? (attendu : 0)"

echo "-- ./do false -----------------------------------"
./do false; echo "exit $? (attendu : 1)"

echo "-- ./do false false -----------------------------"
./do false false; echo "exit $? (attendu : 1)"

echo "-- ./do false true ------------------------------"
./do false true; echo "exit $? (attendu : 1)"

echo "-- ./do true true -------------------------------"
./do true true; echo "exit $? (attendu : 0)"

./do -o true true || echo "Erreur : or true true a renvoyé false"
./do -o false false || echo "Erreur : or false false a renvoyé true"
