#ifndef _MAKEARGV_H_
#define _MAKEARGV_H_

extern char **makeargv(const char *s);
extern void freeargv(char **argv);

#endif
