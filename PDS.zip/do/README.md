#   `do`
# YAHIATENE Mohamed
# MERESSE Antoine

Ce répertoire correspond à l’exercice
« [Exécutions de commandes](http://www.fil.univ-lille1.fr/~hym/e/pds/tp/tdps-exec.html#do) : `do` ».



* la commande 'do' s'execute comme demandé.
* les commandes possibles:
* make
* make clean
* ./do
