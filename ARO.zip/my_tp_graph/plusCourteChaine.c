#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe.h"

/* Couleurs */
typedef enum {ROUGE=0, BLEU=1, VERT=2} tCouleur;
typedef tCouleur tTabCouleurs[MAX_SOMMETS];

void plusCourteChaine(tGraphe graphe,tNomSommet nomSommet){
  int d[MAX_SOMMETS];
  tNumeroSommet pred[MAX_SOMMETS];
  tTabCouleurs tab={};
  tFileSommets file = fileSommetsAlloue();
  tNomSommet nomSommet1;
  tNumeroSommet x,y;

  for (int i=0;i<grapheNbSommets(graphe);i++){
  tab[i]=BLEU;
  }
  d[numDep]=0;
  tNumeroSommet numDep= grapheChercheSommetParNom(graphe, nomSommet);
  tab[numDep]=VERT;
  fileSommetsEnfile(file, numDep);

  while (!fileSommetsEstVide(file)){
    x = fileSommetsDefile(file);
    int nbvx=grapheNbVoisinsSommet(graphe,x);
    for (int i = 0; i < nbvx; i++){
      y=grapheVoisinSommetNumero(graphe, x, i);
      if(tab[y]==BLEU){
        tab[y]=VERT;
        fileSommetsEnfile(file,y);
        d[y]=d[x]+1;
        pred[y]=x;
      }
    }
    tab[x]=ROUGE;
  }
  fileSommetsLibere (file);
}


int main(int argc, char *argv[]) {

  if (argc<2) {
    halt("Usage : %s FichierGraphe\n", argv[0]);
  }

  tGraphe graphe;
  graphe = grapheAlloue();
  grapheChargeFichier(graphe,argv[1]);
  plusCourteChaine(graphe,argv[2]);
  grapheLibere(graphe);
  exit(EXIT_SUCCESS);
}
