#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "graphe.h"


void accesDonnes(char * fichier){
  
  tNumeroSommet i;
  tGraphe graphe;
  graphe = grapheAlloue();
  grapheChargeFichier(graphe,  fichier);
  int nbSommets =  grapheNbSommets(graphe);
  tNomSommet 	nomSommet;
  int max=0;

  printf("les sommets qui n'ont pas de voisins : \n");
  for (i = 0; i < nbSommets; i++) {
    if (grapheNbVoisinsSommet	(graphe,i)==0) {
      grapheRecupNomSommet(graphe,i,nomSommet);

      printf("%s\n",nomSommet);
    }
  }

  for (i = 0; i < nbSommets; i++) {
    int nb=grapheNbVoisinsSommet(graphe, i);
    if (nb>max){
      max=nb;
    }
  }

printf("les sommets qui ont le plus de voisins : \n");
  for (i = 0; i < nbSommets; i++){
    if (grapheNbVoisinsSommet	(graphe,i)==max){
      grapheRecupNomSommet(graphe,i,nomSommet);
      printf("%s\n",nomSommet);
    }

  }

grapheLibere(graphe);
}



int main(int argc, char *argv[]) {

  if (argc<2) {
    halt("Usage : %s FichierGraphe\n", argv[0]);
  }

  accesDonnes(argv[1]);

  exit(EXIT_SUCCESS);
}
