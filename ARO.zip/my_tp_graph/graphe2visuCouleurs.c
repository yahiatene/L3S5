#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe.h"
#include "sys/wait.h"

/* Couleurs */
typedef enum {ROUGE=0, BLEU=1, VERT=2} tCouleur;
typedef tCouleur tTabCouleurs[MAX_SOMMETS];

char *toString(int x){
  char *res;
  switch (x) {
    case 0:
      res="red";
      return res;
      break;
   case 1:
   res="blue";
    return res ;
    break;

  case 2:
    res="green";
    return res;
    break;
  default:
        perror("couleur n'exite pas");
        exit(0);
  }
}

void graphe2visuCouleurs(tGraphe graphe, char *outfile,tTabCouleurs tabCouleurs){
  FILE *fic;
  char commande[80];
  char dotfile[80]; /* le fichier dot pour créer le ps */
  int ret;

  tNumeroSommet g;
  tNomSommet origine,destination,sommet;

  int nbSommets= grapheNbSommets(graphe);
  /* on va créer un fichier pour graphviz, dans le fichier "outfile".dot */
  strcpy(dotfile, outfile);
  strcat(dotfile, ".dot");
  fic = fopen(dotfile, "w");
  if (fic==NULL)
  halt ("Ouverture du fichier %s en écriture impossible\n", dotfile);

  if (grapheEstOriente(graphe)==1){
  fprintf(fic, "digraph {\n");
  }
  else{
    fprintf(fic, "graph {\n");
  }

  for (int j=0;j<nbSommets;j++){
    grapheRecupNomSommet (graphe,j,sommet);
    fprintf(fic," %s [color= %s] ;\n", sommet,toString(tabCouleurs[j]));
  }

  for (int i=0;i<nbSommets;i++){
    grapheRecupNomSommet (graphe,i,origine);
    int nbvi=grapheNbVoisinsSommet(graphe,i);
    if(nbvi>0){
      for (int j=0;j<nbvi;j++){
        g= grapheVoisinSommetNumero ( graphe, i,j);
        grapheRecupNomSommet (graphe,g,destination);
        if(i<g){
if (grapheEstOriente(graphe)==1){

fprintf(fic," %s -> %s ;\n", origine, destination );}

else{
fprintf(fic," %s -- %s ;\n", origine, destination );
}
}
      }
    }
  }


  fprintf(fic,"\n}");
  fclose(fic);
  sprintf(commande, "dot -Tps %s -o %s", dotfile, outfile);
  ret = system(commande);
  if (WEXITSTATUS(ret))
  halt("La commande suivante a échoué\n%s\n", commande);
}
