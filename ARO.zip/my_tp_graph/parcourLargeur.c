#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe2visuCouleurs.c"
#include "graphe.h"


void parcourLargeur(char* fichier,tNomSommet nomSommet){
  tGraphe graphe;
  graphe = grapheAlloue();
  grapheChargeFichier(graphe,fichier);


  tFileSommets file = fileSommetsAlloue();
  tTabCouleurs tab={};

  tNomSommet nomSommet1;
  tNumeroSommet x,y;

  tNumeroSommet numDep= grapheChercheSommetParNom(graphe, nomSommet);
  tab[numDep]=VERT;/*colorer le sommet de depart en VERT*/
  fileSommetsEnfile(file, numDep);
  printf("le sommet de depart est : %s\n",nomSommet);

  for (int i=0;i<grapheNbSommets(graphe);i++){
  tab[i]=BLEU;
  }

  while (!fileSommetsEstVide(file)) {
    x = fileSommetsDefile(file);
    grapheRecupNomSommet(graphe,x,nomSommet1);
    printf("sortie de la file  :%s\n",nomSommet1);

    int nbvx=grapheNbVoisinsSommet(graphe,x);
    for (int i = 0; i < nbvx; i++) {
      y=grapheVoisinSommetNumero(graphe, x, i);
      if(tab[y]==BLEU){
        tab[y]=VERT;
        fileSommetsEnfile(file,y);
      }
      tab[x]=ROUGE;
      graphe2visuCouleurs(graphe, nomSommet1,tab);
    }
  }
  fileSommetsLibere (file);
  grapheLibere(graphe);
}


int main(int argc, char *argv[]) {

  if (argc<3) {
    halt("Usage : %s FichierGraphe\n", argv[0]);
  }

  parcourLargeur(argv[1],argv[2]);

  exit(EXIT_SUCCESS);
}
