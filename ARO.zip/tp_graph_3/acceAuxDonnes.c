#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "graphe.h"
void affichageSommets(char * nomFichier){
  
  tNomSommet nomSommet;
  tGraphe graphe;
  graphe = grapheAlloue();
  grapheChargeFichier(graphe,nomFichier);
  int nbSommet= grapheNbSommets (graphe);
  for (int i=0;i<nbSommet;i++){
   int k=grapheNbVoisinsSommet (graphe, i);
    if(k==0){
      grapheRecupNomSommet (graphe,i,nomSommet);
      printf("le nom du sommet qui n a pas de voisins est : %s \n",nomSommet);
    }
}
   int max=0;
   for (int i=0;i<nbSommet;i++){
    int nb=grapheNbVoisinsSommet(graphe, i);
      if (nb>max){
        max=nb;
      }
  }
  for (int i=0;i<nbSommet;i++){
   int nb1=grapheNbVoisinsSommet (graphe, i);
   if (nb1==max){
     grapheRecupNomSommet(graphe,i,nomSommet);
     printf("le nom du sommet qui a le plus de voisins est : %s \n",nomSommet);
   }
 }
grapheLibere(graphe);
}
int main(int argc, char *argv[]){
  


  if (argc<2) {
    halt("Usage : %s FichierGraphe\n", argv[0]);
  }
  
  
  affichageSommets(argv[1]);

  
  exit(EXIT_SUCCESS);



}
