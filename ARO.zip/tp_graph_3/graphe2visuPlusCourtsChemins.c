#include<stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe.h"
#include "sys/wait.h"
void graphe2visuPlusCourtsChemins(tGraphe graphe, char *outfile,tNumeroSommet depart, tNumeroSommet pred[MAX_SOMMETS){




}
