##Q7:
digraph est l'abreviation de graph orienté (directed graph)
