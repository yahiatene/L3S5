#include<stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe.h"
#include "sys/wait.h"
void plus_courte_chaine(tGraphe graphe,tNumeroSommet s){
  int d[MAX_SOMMETS];

  tNumeroSommet pred[MAX_SOMMETS];
  tTabCouleurs tab;
tNumeroSommet x;
  for (int j=0;j<grapheNbSommets (graphe);j++){
    tab[j]=BLEU;
  }
  tab[s]=VERT;
  d[s]=0;
  tFileSommets file=fileSommetsAlloue();
  fileSommetsEnfile(file, s);
  while(fileSommetsEstVide(file)==0){
    x =fileSommetsDefile(file);
  
    for(int i=0;i<grapheNbVoisinsSommet (graphe, x);i++){
      if(tab[ grapheVoisinSommetNumero(graphe, x,i)]==BLEU){

        tab[grapheVoisinSommetNumero(graphe, x, i)]=VERT;
        fileSommetsEnfile(file,grapheVoisinSommetNumero(graphe, x, i));
        d[grapheVoisinSommetNumero(graphe, x,i)]=d[x]+1;

        pred[grapheVoisinSommetNumero(graphe, x,i)]=x;
    }
  }
tab[x]=ROUGE;

}

fileSommetsLibere(file);
for(int k=0;k<grapheNbSommets (graphe);k++){
  if (grapheNbVoisinsSommet (graphe, k)>0){
  printf("la longueur entre s et %d est: %d\n",k,d[k] );}}

}
int main(int argc, char *argv[]){

  if (argc<2) {
    halt("Usage : %s FichierGraphe\n", argv[0]);
  }
  tGraphe graphe;
  graphe = grapheAlloue();
  grapheChargeFichier(graphe,argv[1]);
  plus_courte_chaine(graphe, 2);

  exit(EXIT_SUCCESS);

}
