#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe.h"
#include "graphe2visuCouleurs.c"
// $ gcc -Wall -g -std=c99 parcours_largeur.c graphe.c -o parcours_largeur
// $ ./parcours_largeur <fichier_graphe> <nomSommet>

void parcours_largeur(char * graphfile, tNomSommet nomSommet){

tFileSommets file=fileSommetsAlloue();

tGraphe graphe;
tNomSommet nomSommett;

tTabCouleurs tab={};
graphe = grapheAlloue();
grapheChargeFichier(graphe,graphfile);

for (int i=0;i<grapheNbSommets (graphe);i++){
  tab[i]=BLEU;

}

tNumeroSommet numerosomet= grapheChercheSommetParNom(graphe, nomSommet);
tab[numerosomet]=VERT;

   fileSommetsEnfile(file, numerosomet);
   while( fileSommetsEstVide(file)==0){
     tNumeroSommet x=fileSommetsDefile(file);
     grapheRecupNomSommet(graphe,x,nomSommett);
     printf("le nom du sommet  : %s \n",nomSommett);
     for(int i=0;i<grapheNbVoisinsSommet (graphe, x);i++){

      if(tab[ grapheVoisinSommetNumero(graphe, x,i)]==BLEU){

        tab[grapheVoisinSommetNumero(graphe, x, i)]=VERT;
	
        fileSommetsEnfile(file,grapheVoisinSommetNumero(graphe, x, i));
      }
       tab[x]=ROUGE;
	graphe2visuCouleurs(graphe, strcat(nomSommett,".ps"),tab);

}

	}

fileSommetsLibere(file);




}



int main(int argc, char *argv[]){

  if (argc<3) {
    halt("Usage : %s FichierGraphe\n", argv[0]);
  }

  parcours_largeur(argv[1],argv[2]);
  exit(EXIT_SUCCESS);

}
