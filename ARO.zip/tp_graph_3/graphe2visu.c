#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe.h"
#include "sys/wait.h"
/* Nécessaire pour la macro WEXITSTATUS */

void graphe2visu(tGraphe graphe, char *outfile) {
FILE *fic;
char commande[80];
char dotfile[80]; /* le fichier dot pour créer le ps */
int ret;
tNumeroSommet g;
tNomSommet origine;
tNomSommet destination;
/* on va créer un fichier pour graphviz, dans le fichier "outfile".dot */
strcpy(dotfile, outfile);
strcat(dotfile, ".dot");

fic = fopen(dotfile, "w");
if (fic==NULL)
halt ("Ouverture du fichier %s en écriture impossible\n", dotfile);
int nbSommet= grapheNbSommets (graphe);
fprintf(fic, "digraph {\n");
  for (int i=0;i<nbSommet;i++){
	grapheRecupNomSommet (graphe,i,origine);
	if(grapheNbSuccesseursSommet (graphe,i)>0){
	for (int j=0;j<grapheNbSuccesseursSommet(graphe,i);j++){
	g= grapheSuccesseurSommetNumero ( graphe,  i, j);
	grapheRecupNomSommet (graphe,g,destination);
	fprintf(fic," %s -> %s ;\n", origine, destination );}
	}
    }
fprintf(fic,"\n}");
fclose(fic);

sprintf(commande, "dot -Tps %s -o %s", dotfile, outfile);

ret = system(commande);
if (WEXITSTATUS(ret))
halt("La commande suivante a échoué\n%s\n", commande);

}


int main(int argc, char *argv[]){

  if (argc<2) {
    halt("Usage : %s FichierGraphe\n", argv[0]);
  }

  tGraphe graphe;
  graphe = grapheAlloue();
  grapheChargeFichier(graphe,argv[1]);
  graphe2visu(graphe, "visu.ps");
  exit(EXIT_SUCCESS);



}
