void plus_courte_chaine(tGraphe graphe,tNumeroSommet s,tNumeroSommet pred[MAX_SOMMETS]);
