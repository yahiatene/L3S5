#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe.h"
#include "sys/wait.h"
#include "plus_courte_chaine.h"
/* Nécessaire pour la macro WEXITSTATUS */

void graphe2visuPlusCourtsChemins(tGraphe graphe, char *outfile,tNumeroSommet depart, tNumeroSommet pred[MAX_SOMMETS]){
  FILE *fic;
  char commande[80];
  char dotfile[80]; /* le fichier dot pour créer le ps */
  tNumeroSommet g;
  tNomSommet origine,sommet,destination,nomSommetDepart;
  /* on va créer un fichier pour graphviz, dans le fichier "outfile".dot */
strcpy(dotfile, outfile);
printf("d");
strcat(dotfile, ".dot");

fic = fopen(dotfile, "w");
if (fic==NULL)
halt ("Ouverture du fichier %s en écriture impossible\n", dotfile);
int nbSommet= grapheNbSommets (graphe);
fprintf(fic, "digraph {\n");
grapheRecupNomSommet (graphe,depart,nomSommetDepart);
for (int j=0;j<nbSommet;j++){
grapheRecupNomSommet (graphe,j,sommet);

if(j!=depart){
fprintf(fic," %s [color= %s] ;\n", sommet,"black");}
else{
  fprintf(fic," %s [color= %s] ;\n", sommet,"blue");
}
}
for (int i=0;i<nbSommet;i++){
grapheRecupNomSommet (graphe,i,origine);

if(grapheNbVoisinsSommet(graphe,i)>0){
for (int j=0;j<grapheNbVoisinsSommet(graphe,i);j++){
g= grapheVoisinSommetNumero( graphe,  i, j);
grapheRecupNomSommet (graphe,g,destination);
if(i<g){
if(pred[g]==i){
if (grapheEstOriente(graphe)){
fprintf(fic," %s -> %s [color= %s];\n", origine, destination,"blue");}
else{
  fprintf(fic," %s -- %s [color= %s];\n", origine, destination,"blue");
}
}
else{
  if (grapheEstOriente(graphe)){
  fprintf(fic," %s -> %s [color= %s];\n", origine, destination,"black");}
  else{
    fprintf(fic," %s -- %s [color= %s];\n", origine, destination,"black");
  }
}
}}}}

fprintf(fic,"\n}");
fclose(fic);
sprintf(commande, "dot -Tps %s -o %s", dotfile, outfile);
ret = system(commande);
if (WEXITSTATUS(ret))
halt("La commande suivante a échoué\n%s\n", commande);
}


int main(int argc, char *argv[]){

if (argc<2) {
halt("Usage : %s FichierGraphe\n", argv[0]);
}

tGraphe graphe;
tNumeroSommet pred[MAX_SOMMETS];
graphe = grapheAlloue();

grapheChargeFichier(graphe,argv[1]);
plus_courte_chaine(graphe,0,pred);
graphe2visuPlusCourtsChemins(graphe,"visu.ps",0,pred);
exit(EXIT_SUCCESS);



}
