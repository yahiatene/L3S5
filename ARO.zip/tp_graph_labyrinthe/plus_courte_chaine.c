#include<stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe.h"
#include "sys/wait.h"
#include "plus_courte_chaine.h"
void plus_courte_chaine(tGraphe graphe,tNumeroSommet s,tNumeroSommet pred[MAX_SOMMETS]){
  int d[MAX_SOMMETS];
  tTabCouleurs tab;
  tNumeroSommet x;
  for (int j=0;j<grapheNbSommets (graphe);j++){
    tab[j]=BLEU;
  }
  tab[s]=VERT;
  d[s]=0;
  tFileSommets file=fileSommetsAlloue();
  fileSommetsEnfile(file, s);
  while(fileSommetsEstVide(file)==0){
    x =fileSommetsDefile(file);

    for(int i=0;i<grapheNbVoisinsSommet (graphe, x);i++){
      if(tab[ grapheVoisinSommetNumero(graphe, x,i)]==BLEU){

        tab[grapheVoisinSommetNumero(graphe, x, i)]=VERT;
        fileSommetsEnfile(file,grapheVoisinSommetNumero(graphe, x, i));
        d[grapheVoisinSommetNumero(graphe, x,i)]=d[x]+1;

        pred[grapheVoisinSommetNumero(graphe, x,i)]=x;
    }
  }
tab[x]=ROUGE;

}

fileSommetsLibere(file);
}
