#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe.h"
tNumeroSommet a_un_voisin_bleu(tGraphe graphe,tNumeroSommet x,tTabCouleurs tab){
  for(int i=0;i<grapheNbVoisinsSommet (graphe, x);i++){

   if(tab[grapheVoisinSommetNumero(graphe,x,i)]==BLEU ){
     return grapheVoisinSommetNumero(graphe,x,i);
   }
}
return -1;}
void parcours_en_profondeur_labyrinth(char * graphfile, tNomSommet nomSommet){
tNumeroSommet aff;
tPileSommets pile=pileSommetsAlloue();
tGraphe graphe;
int res;
tNomSommet nomSommett;
tTabCouleurs tab={};
graphe = grapheAlloue();
grapheChargeFichier(graphe,graphfile);
for (int i=0;i<grapheNbSommets (graphe);i++){
  tab[i]=BLEU;


}
tNumeroSommet numerosomet= grapheChercheSommetParNom(graphe, nomSommet);
tab[numerosomet]=VERT;
   pileSommetsEmpile(pile, numerosomet);

   while(pileSommetsEstVide(pile)==0){
     tNumeroSommet x=pileSommetsTete(pile);




      res=a_un_voisin_bleu(graphe,x, tab);
      if(res!=-1){

        tab[res]=VERT;

        pileSommetsEmpile(pile,res);

      }
      else{
       tab[x]=ROUGE;
       pileSommetsDepile(pile);

       grapheRecupNomSommet(graphe,x,nomSommett);
       if(nomSommett=="sortie"){
         while (pileSommetsEstVide(pile)==0){
        aff=pileSommetsDepile(pile);
         grapheRecupNomSommet(graphe,aff,nomSommett);
         printf("le nom du sommet  : %s \n",nomSommett);
       }

}
}}



pileSommetsLibere(pile);
}
int main(int argc, char *argv[]){

  if (argc<3) {
    halt("Usage : %s FichierGraphe\n", argv[0]);
  }

  parcours_en_profondeur(argv[1],argv[2]);
  exit(EXIT_SUCCESS);

}
