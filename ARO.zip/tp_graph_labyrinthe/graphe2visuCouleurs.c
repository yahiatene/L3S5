#include<stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphe.h"
#include "sys/wait.h"
char *toString(int x){
  char *res;
  switch (x) {
    case 0:
      res="ROUGE";
      return res;
      break;
   case 1:
   res="BLEU";
    return res ;
    break;

  case 2:
    res="VERT";
    return res;
    break;
  default:
        perror("couleur n'exite pas");
        exit(0);
}}
void graphe2visuCouleurs(tGraphe graphe, char *outfile,tTabCouleurs tabCouleurs) {

FILE *fic;
char commande[80];
char dotfile[80]; /* le fichier dot pour créer le ps */
int ret;
tNumeroSommet g;
tNomSommet origine,sommet;
tNomSommet destination;
/* on va créer un fichier pour graphviz, dans le fichier "outfile".dot */
strcpy(dotfile, outfile);
strcat(dotfile, ".dot");

fic = fopen(dotfile, "w");
if (fic==NULL)
halt ("Ouverture du fichier %s en écriture impossible\n", dotfile);
int nbSommet= grapheNbSommets (graphe);
fprintf(fic, "digraph {\n");

for (int j=0;j<nbSommet;j++){
grapheRecupNomSommet (graphe,j,sommet);
fprintf(fic," %s [color= %s] ;\n", sommet,toString( tabCouleurs[j]));}

  for (int i=0;i<nbSommet;i++){
	grapheRecupNomSommet (graphe,i,origine);

	if(grapheNbSuccesseursSommet (graphe,i)>0){

	for (int j=0;j<grapheNbSuccesseursSommet(graphe,i);j++){
	g= grapheSuccesseurSommetNumero ( graphe,  i, j);
	grapheRecupNomSommet (graphe,g,destination);
	fprintf(fic," %s -> %s ;\n", origine, destination);
}
	}
    }
fprintf(fic,"\n}");
fclose(fic);

sprintf(commande, "dot -Tps %s -o %s", dotfile, outfile);

ret = system(commande);
if (WEXITSTATUS(ret))
halt("La commande suivante a échoué\n%s\n", commande);

}


int main(int argc, char *argv[]){

  if (argc<2) {
    halt("Usage : %s FichierGraphe\n", argv[0]);
  }

  tGraphe graphe;
  graphe = grapheAlloue();
  grapheChargeFichier(graphe,argv[1]);
  tCouleur a=1,b=2,c=0;


  tTabCouleurs tabCouleurs={c,a,a,b};
  graphe2visuCouleurs(graphe, "visu.ps",tabCouleurs);
  exit(EXIT_SUCCESS);



}
